import "./static/css/app.css";
import "./static/css/custom.css";
import { Login, SignUp } from "./components/Auth/Auth";
import { createBrowserRouter, RouterProvider, Navigate } from "react-router-dom";
import { Home } from "./components/landingpage/Home";
import { DashboardAdmin } from "./components/admin/Dashboard";
import { ChatsAdmin } from "./components/admin/Chats";
import { FAQsAdmin } from "./components/admin/FAQs";
import { UsersAdmin } from "./components/admin/Users";
import { AboutUs } from "./components/landingpage/AboutUs";
import { ContactUs } from "./components/landingpage/ContactUs";
import { Pricing } from "./components/landingpage/ahsan/Pricing";
import { Error404 } from './components/errors/Error404';
import { LandingPage } from './components/landingpage/LandingPage';
import { AdminDashboard } from "./components/admin/AdminDashboard";
import { UserDashboard } from "./components/User/UserDashboard";
import { ProfileUser } from "./components/User/Profile";
import { ChatUser } from "./components/User/Chat";
import { MeasurementsUser } from "./components/User/Measurements";
import { SavedUser } from "./components/User/Saved";
import { ChangePassword } from "./components/Auth/PasswordChange";
import useAuthService from "./components/services/ApiService";
import { LoadingScreen } from "./components/elements/LoadingScreen";
import { UserProvider } from "./components/User/UserContext";
import { useEffect, useState } from "react";
import { useContext } from "react";

function App() {
  const api = useAuthService();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [adminUser, setAdminUser] = useState(false);
  const [regularUser, setRegularUser] = useState(false);

  useEffect(() => {
    setIsLoggedIn(api.isLoggedIn);
    setAdminUser(api.adminUser);
    setRegularUser(api.regularUser);
  }, [api.adminUser, api.regularUser]);

  const routes = [
    {
      path: "/",
      element: <LandingPage />,
      children: [
        { path: "/", element: <Home /> },
        { path: "aboutus", element: <AboutUs /> },
        { path: "contactus", element: <ContactUs /> },
        { path: "pricing", element: <Pricing /> },
      ],
    },
    {
      path: "/login",
      element: !isLoggedIn ? <Login /> : <Navigate to={adminUser ? "/admin/dashboard" : "/user/profile"} />,
    },
    {
      path: "/signup",
      element: !isLoggedIn ? <SignUp /> : <Navigate to={adminUser ? "/admin/dashboard" : "/user/profile"} />,
    },
    {
      path: "/logout",
      element: <Logout />,
    },
    {
      path: "/change-password",
      element: isLoggedIn ? <ChangePassword /> : <Navigate to="/login" />,
    },
    {
      path: "/admin",
      element: isLoggedIn && adminUser ? <AdminDashboard /> : <Navigate to="/error" />,
      children: [
        { path: "dashboard", element: <DashboardAdmin /> },
        { path: "chats", element: <ChatsAdmin /> },
        { path: "faqs", element: <FAQsAdmin /> },
        { path: "users", element: <UsersAdmin /> },
      ],
    },
    {
      path: "/user",
      element: isLoggedIn && regularUser ? (
        <UserProvider>
          <UserDashboard />
        </UserProvider>
      ) : (
        <Navigate to="/login" />
      ),
      children: [
        { path: "profile", element: <ProfileUser /> },
        { path: "chat", element: <ChatUser /> },
        { path: "measurements", element: <MeasurementsUser /> },
        { path: "saved", element: <SavedUser /> },
      ],
    },
    {
      path: "/error",
      element: <Error404 />,
    },
    {
      path: "*",
      element: <Error404 />,
    },
  ];

  const router = createBrowserRouter(routes, {
    initialEntries: ["/boopy/"],
    initialIndex: 0,
    basename: "/boopy",
  });

  return (
    <>
      <RouterProvider router={router} />
    </>
  );
}

const Logout = () => {
  const api = useAuthService();
  useEffect(() => {
    api.logout();
  }, []);

  return <Navigate to="/login" />;
};

export default App;
