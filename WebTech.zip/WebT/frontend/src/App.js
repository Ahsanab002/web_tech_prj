import "./static/css/app.css";
import "./static/css/custom.css";
import { Login, SignUp } from "./components/Auth/Auth";
import {
  createBrowserRouter,
  RouterProvider,
  Navigate,
} from "react-router-dom";
import { Home } from "./components/landingpage/Home";
import { DashboardAdmin } from "./components/admin/Dashboard";
import { ChatsAdmin } from "./components/admin/Chats";
import { FAQsAdmin } from "./components/admin/FAQs";
import { UsersAdmin } from "./components/admin/Users";
import { AboutUs } from "./components/landingpage/AboutUs";
import { ContactUs } from "./components/landingpage/ContactUs";
import { Pricing } from "./components/landingpage/ahsan/Pricing";
import { Error404 } from "./components/errors/Error404";
import { LandingPage } from "./components/landingpage/LandingPage";
import { AdminDashboard } from "./components/admin/AdminDashboard";
import { UserDashboard } from "./components/User/UserDashboard";
import { ProfileUser } from "./components/User/Profile";
import { ChatUser } from "./components/User/Chat";
// import { FaqModal } from "./components/admin/FAQs";
import { ChangePassword } from "./components/Auth/PasswordChange";
import useAuthService from "./components/services/ApiService";
import { LoadingScreen } from "./components/elements/LoadingScreen";
import { UserProvider } from "./components/User/UserContext";
import { useEffect, useState } from "react";
import { useContext } from "react";
import { RouterProviderG } from "./components/services/ApiService";
// import Chatroom from './components/elements/chatroom';
import 'leaflet/dist/leaflet.css';
// import { ServiceCenterMap } from "./components/landingpage/ContactUs";

import {
  AdminRoute,
  ProtectedRoute,
  UserRoute,
} from "./components/services/RoutingServices";
import { RouterContext } from "./components/services/ApiService";
import ProjectManagement from "./components/User/ProjectManagement";
import DashboardOverview from "./components/User/DashboardOverview";

function App() {
  const api = useAuthService();
  const { isLoggedIn, adminUser, regularUser } = useContext(RouterContext);

  const routes = [
    {
      path: "/",
      element: <LandingPage />,
      children: [
        { path: "/", element: <Home /> },
        { path: "aboutus", element: <AboutUs /> },
        { path: "contactus", element: <ContactUs /> },
        { path: "pricing", element: <Pricing /> },
      ],
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: "/signup",
      element: <SignUp />,
    },
    {
      path: "/logout",
      element: <Logout />,
    },
    {
      path: "/change-password",
      element: (
        <ProtectedRoute>
          <ChangePassword />
        </ProtectedRoute>
      ),
    },
    {
      path: "/admin",
      element: (
        <AdminRoute>
          <AdminDashboard />
        </AdminRoute>
      ),
      children: [
        { path: "dashboard", element: <DashboardAdmin /> },
        { path: "chats", element: <ChatsAdmin /> },
        { path: "faqs", element: <FAQsAdmin /> },
        { path: "users", element: <UsersAdmin /> },
      ],
    },
    {
      path: "/user",
      element: (
        <UserRoute>
          <UserProvider>
            <UserDashboard />
          </UserProvider>
        </UserRoute>
      ),
      children: [
        { path: "profile", element: <ProfileUser /> },
        { path: "chat", element: <ChatUser /> },
        { path: "project-management", element: <ProjectManagement /> },
        
        { path: "dashboard-overview", element: <DashboardOverview /> },
      ],
    },
    {
      path: "/error",
      element: <Error404 />,
    },
    {
      path: "*",
      element: <Navigate to="/error" />, // Any unknown route should redirect to error page
    },
  ];

  const router = createBrowserRouter(routes, {
    initialEntries: ["/ImmersiX/"],
    initialIndex: 0,
    basename: "/ImmersiX",
  });

  return (
    <>
      <RouterProviderG>
        <RouterProvider router={router} />
      </RouterProviderG>
    </>
  );
}

const Logout = () => {
  return <Navigate to="/login" />;
};

export default App;
