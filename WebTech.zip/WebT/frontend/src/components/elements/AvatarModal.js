// src/components/AvatarModal.js
import React, { useEffect, useState } from "react";
import { avatars } from "../../static/images/avater/avatar";
const AvatarModal = ({ isOpen, onClose, onSave, gender }) => {
  const [selectedAvatar, setSelectedAvatar] = useState(null);

  const handleAvatarClick = (avatar) => {
    setSelectedAvatar(avatar);
  };

  const handleSaveClick = () => {
    if (selectedAvatar) {
      onSave(selectedAvatar);
    }
    onClose();
  };
  useEffect(() => {
    console.log("AvatarModal:", avatars);
  }, []);

  if (!isOpen) return null;

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        position: "fixed",
        top: 0,
        left: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        zIndex: 1000,
      }}
    >
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="card p-4 rounded-lg" style={{maxHeight: "75vh"}}>
          <h2 className="text-lg font-medium mb-4">Choose an Avatar</h2>
          <div className="grid grid-cols-4 gap-4 overflow-auto">
          {Object.values(avatars[gender]).map((avatar, index) => (
              <img
                key={index}
                src={avatar.src}
                alt={`avatar-${index}`}
                className={`cursor-pointer h-32 w-32 rounded ${
                  selectedAvatar === avatar ? "border-4 border-indigo-500" : ""
                }`}
                onClick={() => handleAvatarClick(avatar)}
              />
            ))}
          </div>
          
            <div class="flex justify-end space-x-2 mt-4">
              <button 
                onClick={onClose}
              class="btn bg-slate-150 font-medium text-slate-800 hover:bg-slate-200 focus:bg-slate-200 active:bg-slate-200/80 dark:bg-navy-500 dark:text-navy-50 dark:hover:bg-navy-450 dark:focus:bg-navy-450 dark:active:bg-navy-450/90">
                <span>Cancel</span>
              </button>
              <button
              onClick={handleSaveClick}
               class="btn bg-primary font-medium text-white hover:bg-primary-focus focus:bg-primary-focus active:bg-primary-focus/90 dark:bg-accent dark:hover:bg-accent-focus dark:focus:bg-accent-focus dark:active:bg-accent/90">
                <span>Save</span>
              </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AvatarModal;
