import React, { useContext, useEffect, useState } from 'react';
import { UserChatContext } from '../User/User_chat_context';
import { AdminChatContext } from '../admin/Admin_chat_context';



const Chatroom = ({ avatar, userName, userId, messages }) => {
  //const Chatroom = ({ avatar, userName, userId, messages }) => 
    {
    const [newMessage, setNewMessage] = useState('');
  
    const sendMessage = async () => {
      const response = await fetch('/api/chat/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sender: userId,
          message: newMessage,
        }),
      });
      if (response.ok) {
        setNewMessage(''); // Clear input after sending
        // Optionally, fetch messages again to update the list
      }
    };
  
    return (
      <div className="flex flex-col h-full">
        {/* ...existing code... */}
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type your message..."
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    );
  };
    
  return (
    <div className="flex flex-col h-full">
      <div className="relative z-10 flex h-[61px] w-full shrink-0 items-center justify-between border-b border-slate-150 bg-white px-4 shadow-sm transition-[padding,width] duration-[.25s] dark:border-navy-700 dark:bg-navy-800 rounded-t-2xl">
        <div className="flex items-center space-x-5">
          <div className="flex items-center space-x-4 font-inter">
            <div className="avatar">
              <img className="rounded-full" src={avatar} alt="avatar" />
            </div>
            <div>
              <p className="font-medium text-slate-700 line-clamp-1 dark:text-navy-100">{userName}</p>
              <p className="mt-0.5 text-xs">{userId}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grow overflow-y-auto px-[calc(var(--margin-x)-.5rem)] py-5 transition-all duration-[.25s] scrollbar-sm">
        {messages.map((message, index) => (
          <div key={index} className="my-2 p-2 border-b border-slate-200 dark:border-navy-600">
            <p className="text-slate-700 dark:text-navy-100">{message}</p>
          </div>
        ))}
      </div>

      <div className="relative flex h-12 w-full shrink-0 items-center justify-between border-t border-slate-150 bg-white px-4 transition-[padding,width] duration-[.25s] dark:border-navy-600 dark:bg-navy-800 rounded-b-2xl">
        <div className="-ml-1.5 flex flex-1 space-x-2">
          <button className="btn h-9 w-9 shrink-0 rounded-full p-0 text-slate-500 hover:bg-slate-300/20 focus:bg-slate-300/20 active:bg-slate-300/25 dark:text-navy-200 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5.5 w-5.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"></path>
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

// export Chatroom;


// AdminPanel.js


const AdminPanel = () => {
    const { messages, setMessages } = useContext(AdminChatContext);
    const { setMessages: setUserMessages } = useContext(UserChatContext);
    const [unreadMessages, setUnreadMessages] = useState(0); // Add state for unread messages
  
    useEffect(() => {
      // Fetch unread message count
      fetchUnreadMessages();
    }, []);
  
    const fetchUnreadMessages = async () => {
      try {
        const response = await fetch('/api/unread_messages');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setUnreadMessages(data.unread_count); // Set unread messages count
      } catch (error) {
        console.error("Error fetching unread messages:", error);
      }
    };
    
  
    const openChatWithUser = (userId) => {
      // Load chat messages
      fetch(`/api/chat/${userId}`)
        .then((res) => res.json())
        .then((data) => {
          setMessages(data);
        });
    };
  
    return (
      <div className="admin-panel">
        <div className="user-list">
          {/* Display user list with last message and unread count */}
        </div>
        <div className="chat-room">
          {/* Display messages */}
        </div>
      </div>
    );
  };
  
  export default AdminPanel;


const ChatRoom = () => {
    const { messages, setMessages } = useContext(UserChatContext);
    
  
    useEffect(() => {
      // Fetch last 50 messages
      fetch('/api/chat/admin')
        .then((res) => res.json())
        .then((data) => {
          setMessages(data);
        });
    }, []);
  
    return (
      <div className="chat-room">
        {messages.map((message, index) => (
          <div key={index} className={message.sender === 'admin' ? 'admin-message' : 'user-message'}>
            {message.message}
          </div>
        ))}
      </div>
    );
  };
  
//   export default ChatRoom;

