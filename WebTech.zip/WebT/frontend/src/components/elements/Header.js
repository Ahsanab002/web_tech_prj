import React from 'react'
import { DarkModeBtn } from "./DarkModeBtn";
import SettingBtn from './SettingBtn';
import NotificationBtn from './NotificationBtn';

export const Header = ({notifications, markNotificationRead}) => {
  return (
    <nav className="header">
      <div className="header-container relative flex w-full bg-white dark:bg-navy-700 print:hidden sm:flex-col">
        <div className="flex w-full items-center justify-between sm:h-16">
          <div className="hidden items-center space-x-2 sm:flex">
          </div>

          <div className="-mr-1.5 flex items-center space-x-2">
            <DarkModeBtn />
            <NotificationBtn notifications={notifications} markNotificationRead={markNotificationRead} />
            <SettingBtn />
            </div>
        </div>
      </div>
    </nav>
  )
}
