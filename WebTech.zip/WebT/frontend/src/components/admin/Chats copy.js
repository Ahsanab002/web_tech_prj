// import React, { useState, useEffect } from 'react';
// // import io from 'socket.io-client';  // Import Socket.io client
// import avatar from './avatar.png';
// import { ChatRow } from './components/ChatRow';

// // Establish WebSocket connection
// // const socket = io('ws://localhost:8000/ws/chat/admin_ahsan/'); 

// const token = localStorage.getItem('user');
// console.log("WebSocket Token:", token);  // Ensure this gets the correct token
// const socket = new WebSocket(`ws://localhost:8000/ws/chat/admin_ahsan/`, [], {
//   headers: {
//       'Authorization': `Token ${token}`
//   }
// });



// // const socket = io('http://127.0.0.1:8000', {
// //   transports: ['websocket']
// // });// Replace with your backend WebSocket URL

// export const ChatsAdmin = () => {
//   const winheight = window.innerHeight - 125;

//   // States to manage message input and chat history
//   const [message, setMessage] = useState('');  // Input message
//   const [messages, setMessages] = useState([]);  // Chat history

//   // // On component mount, set up WebSocket listeners
//   // useEffect(() => {
//   //   // Listen for 'messageResponse' events from the backend
//   //   socket.on('messageResponse', (data) => {
//   //     setMessages((prevMessages) => [...prevMessages, data]);  // Append received message to chat history
//   //   });

//   //   // Cleanup on unmount
//   //   return () => socket.disconnect();
//   // }, []);

//   // // Send message to the backend via WebSocket
//   // const sendMessage = () => {
//   //   if (message.trim()) {
//   //     socket.emit('send_message', message);  // Emit message to backend
//   //     setMessage('');  // Clear input field
//   //   }
//   // };

//   return (
//     <>
//       <div className="w-full pt-8">
//         <div className="flex items-center justify-between w-full space-x-8 px-4" style={{ height: winheight + 'px' }}>
//           {/* Left Sidebar: Users List */}
//           <div className="w-3/12 flex flex-col w-full h-full box-shadow-lg rounded-2xl card">
//             <div className='w-full px-2 py-3'>
//               <div className="px-4">
//                 <label className="relative hidden sm:flex bg-indigo-500 rounded-full">
//                   <input
//                     className="form-input peer h-9 w-full rounded-full border border-slate-300 px-3 py-2 pl-9 text-xs+ placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent bg-lightmode dark:bg-darkmode"
//                     placeholder="Search users..."
//                     type="text"
//                   />
//                   <span className="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
//                     <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 transition-colors duration-200" fill="currentColor" viewBox="0 0 24 24">
//                       <path d="M3.316 13.781l.73-.171-.73.171zm0-5.457l.73.171-.73-.171zm15.473 0l.73-.171-.73.171zm0 5.457l.73.171-.73-.171zm-5.008 5.008l-.171-.73.171.73zm-5.457 0l-.171.73.171-.73zm0-15.473l-.171-.73.171.73zm5.457 0l.171-.73-.171.73zM20.47 21.53a.75.75 0 101.06-1.06l-1.06 1.06zM4.046 13.61a11.198 11.198 0 010-5.115l-1.46-.342a12.698 12.698 0 000 5.8l1.46-.343zm14.013-5.115a11.196 11.196 0 010 5.115l1.46.342a12.698 12.698 0 000-5.8l-1.46.343zm-4.45 9.564a11.196 11.196 0 01-5.114 0l-.342 1.46c1.907.448 3.892.448 5.8 0l-.343-1.46zM8.496 4.046a11.198 11.198 0 015.115 0l.342-1.46a12.698 12.698 0 00-5.8 0l.343 1.46zm0 14.013a5.97 5.97 0 01-4.45-4.45l-1.46.343a7.47 7.47 0 005.568 5.568l.342-1.46zm5.457 1.46a7.47 7.47 0 005.568-5.567l-1.46-.342a5.97 5.97 0 01-4.45 4.45l.342 1.46zM13.61 4.046a5.97 5.97 0 014.45 4.45l1.46-.343a7.47 7.47 0 00-5.568-5.567l-.342 1.46zm-5.457-1.46a7.47 7.47 0 00-5.567 5.567l1.46.342a5.97 5.97 0 014.45-4.45l-.343-1.46zm8.652 15.28l3.665 3.664 1.06-1.06-3.665-3.665-1.06 1.06z"></path>
//                     </svg>
//                   </span>
//                   <button className="btn h-8 w-10 rounded-full p-0 mr-2 hover:bg-slate-300/20 focus:bg-slate-300/20 active:bg-slate-300/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25" type='submit'>
//                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" stroke="white" fill="none" viewBox="0 0 24 24">
//                       <circle cx="10.2" cy="10.2" r="7.2" strokeWidth="1.5"></circle>
//                       <path strokeWidth="1.5" strokeLinecap="round" d="M21 21l-3.6-3.6"></path>
//                     </svg>
//                   </button>
//                 </label>
//               </div>
//               <div className='my-2 overflow-y-auto pb-2' style={{ height: winheight - 60 + 'px' }}>
//                 <ChatRow />
//                 {/* Repeat ChatRow for other users */}
//               </div>
//             </div>
//           </div>

//           {/* Chat Window */}
//           <div className="flex border-indigo-500 box-shadow-lg w-9/12 ml-2 rounded-2xl card" style={{ height: winheight + 'px' }}>
//             {/* Chat Header */}
//             <div className="relative z-10 flex h-[61px] w-full shrink-0 items-center justify-between border-b border-slate-150 bg-white px-4 shadow-sm transition-[padding,width] duration-[.25s] dark:border-navy-700 dark:bg-navy-800 rounded-t-2xl">
//               <div className="flex items-center space-x-5">
//                 <div className="flex items-center space-x-4 font-inter">
//                   <div className="avatar">
//                     <img className="rounded-full" src={avatar} alt="avatar" />
//                   </div>
//                   <div>
//                     <p className="font-medium text-slate-700 line-clamp-1 dark:text-navy-100">Alfredo Elliott</p>
//                     <p className="mt-0.5 text-xs">alfredoelliott</p>
//                   </div>
//                 </div>
//               </div>
//               <div className="flex items-center">
//                 <span className="badge rounded-fullbg-info/10 text-info dark:bg-info/15">Free</span>
//               </div>
//             </div>

//             {/* Chat Messages */}
//             <div className="grow overflow-y-auto px-[calc(var(--margin-x)-.5rem)] py-5 transition-all duration-[.25s] scrollbar-sm">
//               {messages.map((msg, index) => (
//                 <div key={index} className="message-row">{msg}</div>  // Display received messages
//               ))}
//             </div>

//             {/* Chat Input */}
//             <div className="relative flex h-12 w-full shrink-0 items-center justify-between border-t border-slate-150 bg-white px-4 transition-[padding,width] duration-[.25s] dark:border-navy-600 dark:bg-navy-800 rounded-b-2xl">
//               <div className="-ml-1.5 flex flex-1 space-x-2">
//                 <button className="btn h-9 w-9 shrink-0 rounded-full p-0 text-slate-500 hover:bg-slate-300/20 focus:bg-slate-300/20 active:bg-slate-300/25 dark:text-navy-200 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5.5 w-5.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
//                     <path strokeLinecap="round" strokeLinejoin="round" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"></path>
//                   </svg>
//                 </button>
//                 <input
//                   type="text"
//                   className="form-input h-9 w-full bg-transparent placeholder:text-slate-400/70"
//                   placeholder="Write the message"
//                   value={message}
//                   // onChange={(e) => setMessage(e.target.value)}  // Update input state
//                 />
//               </div>
//               <div className="-mr-1.5 flex">
//                 <button 
//                 // onClick={sendMessage} 
//                 className="btn h-9 w-9 shrink-0 rounded-full p-0 text-primary hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:text-accent-light dark:hover:bg-accent-light/20 dark:focus:bg-accent-light/20 dark:active:bg-accent-light/25">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5.5 w-5.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
//                     <path strokeLinecap="round" strokeLinejoin="round" d="m9.813 5.146 9.027 3.99c4.05 1.79 4.05 4.718 0 6.508l-9.027 3.99c-6.074 2.686-8.553.485-5.515-4.876l.917-1.613c.232-.41.232-1.09 0-1.5l-.917-1.623C1.26 4.66 3.749 2.46 9.813 5.146ZM6.094 12.389h7.341"></path>
//                   </svg>
//                 </button>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };
