import React from "react";
import rating0 from "../../../static/images/ratings/0.png";
import rating1 from "../../../static/images/ratings/1.png";
import rating2 from "../../../static/images/ratings/2.png";
import rating3 from "../../../static/images/ratings/3.png";
import rating4 from "../../../static/images/ratings/4.png";
import rating5 from "../../../static/images/ratings/5.png";

import m1 from '../../../static/images/avater/male/m1.png'
import m2 from '../../../static/images/avater/male/m2.png'
import m3 from '../../../static/images/avater/male/m3.png'
import m4 from '../../../static/images/avater/male/m4.png'
import m5 from '../../../static/images/avater/male/m5.png'
import m6 from '../../../static/images/avater/male/m6.png'
import m7 from '../../../static/images/avater/male/m7.png'
import m8 from '../../../static/images/avater/male/m8.png'
import m9 from '../../../static/images/avater/male/m9.png'
import m10 from '../../../static/images/avater/male/m10.png'
import m11 from '../../../static/images/avater/male/m11.png'
import m12 from '../../../static/images/avater/male/m12.png'

import f1 from '../../../static/images/avater/female/f1.png'
import f2 from '../../../static/images/avater/female/f2.png'
import f3 from '../../../static/images/avater/female/f3.png'
import f4 from '../../../static/images/avater/female/f4.png'
import f5 from '../../../static/images/avater/female/f5.png'
import f6 from '../../../static/images/avater/female/f6.png'
import f7 from '../../../static/images/avater/female/f7.png'
import f8 from '../../../static/images/avater/female/f8.png'
import f9 from '../../../static/images/avater/female/f9.png'
import f10 from '../../../static/images/avater/female/f10.png'
import f11 from '../../../static/images/avater/female/f11.png'
import f12 from '../../../static/images/avater/female/f12.png'

const avaters = {
    'm1': m1,
    'm2': m2,
    'm3': m3,
    'm4': m4,
    'm5': m5,
    'm6': m6,
    'm7': m7,
    'm8': m8,
    'm9': m9,
    'm10': m10,
    'm11': m11,
    'm12': m12,
    'f1': f1,
    'f2': f2,
    'f3': f3,
    'f4': f4,
    'f5': f5,
    'f6': f6,
    'f7': f7,
    'f8': f8,
    'f9': f9,
    'f10': f10,
    'f11': f11,
    'f12': f12,
}

const ratingImages = {
    0: rating0,
    1: rating1,
    2: rating2,
    3: rating3,
    4: rating4,
    5: rating5,
}

export function UserCards ({ users }) {
    return (
        <>
        {users.length === 0 &&
                <div className="text-center flex flex-col justify-center text-4xl font-semibold h-50">
                    No Users Found
                </div>
            }
        <div className="grid grid-cols-4 gap-4">
            {users.map(user => <UserCard user={user} key={user.id} />)}
        </div>
        </>
    )
};

function UserCard ({ user }) {
  return (
    <div className="card shadow drop-shadow-sm">
      <div className="h-16 rounded-t-lg bg-primary dark:bg-accent bg-indigo-500 relative">
        <div className="flex flex-col justify-center h-full right-0 absolute mr-3">
          <button className="btn h-7 w-7 rounded-full bg-primary/10 p-0 text-primary hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:bg-accent-light/10 dark:text-accent-light dark:hover:bg-accent-light/20 dark:focus:bg-accent-light/20 dark:active:bg-accent-light/25">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g>
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 13.5997 2.37562 15.1116 3.04346 16.4525C3.22094 16.8088 3.28001 17.2161 3.17712 17.6006L2.58151 19.8267C2.32295 20.793 3.20701 21.677 4.17335 21.4185L6.39939 20.8229C6.78393 20.72 7.19121 20.7791 7.54753 20.9565C8.88837 21.6244 10.4003 22 12 22ZM8 13.25C7.58579 13.25 7.25 13.5858 7.25 14C7.25 14.4142 7.58579 14.75 8 14.75H13.5C13.9142 14.75 14.25 14.4142 14.25 14C14.25 13.5858 13.9142 13.25 13.5 13.25H8ZM7.25 10.5C7.25 10.0858 7.58579 9.75 8 9.75H16C16.4142 9.75 16.75 10.0858 16.75 10.5C16.75 10.9142 16.4142 11.25 16 11.25H8C7.58579 11.25 7.25 10.9142 7.25 10.5Z"
                  fill="white"
                ></path>
              </g>
            </svg>
          </button>
        </div>
      </div>
      <div className="px-4 py-2 sm:px-5">
        <div className="flex justify-between space-x-4">
          <div className="avatar -mt-12 h-20 w-20">
            <img
              className="rounded-full border-2 border-white dark:border-navy-700"
              src={avaters[user.avater]}
              alt="avatar"
            />
            <div className="whitespace-nowrap leading-normal flex flex-col justify-center pb-2 ml-3 text-lg font-medium text-slate-700 dark:text-navy-100">
              <p className="text-white">{user.name}</p>
              <p className="text-xs">{user.username}</p>
            </div>
          </div>
        </div>
        <div className="flex space-x-4 pt-2">
          <div className="w-7/12">
            <img src={ratingImages[user.rating]}
             className="h-auto w-full my-2" 
             alt="rating" />
            <p className="text-xs">Last Rated on {user.last_rating}</p>
          </div>
          <div className="w-5/12 h-full text-xs">
          <p>
              <span className="font-medium">Plan :</span> <span
                className={"badge rounded-full" + (user.plan_type === 'premium' ? 'bg-secondary/10 text-secondary dark:bg-secondary-light/15 dark:text-secondary-light' : 'bg-info/10 text-info dark:bg-info/15')}
                // className="bg-secondary/10 text-secondary dark:bg-secondary-light/15 dark:text-secondary-light"
                >
                    {user.plan_type.charAt(0).toUpperCase() + user.plan_type.slice(1)}
                </span>
            </p>
            <p>
              <span className="font-medium">Stock Watch :</span> 2
            </p>
            <p>
              <span className="font-medium">Gender :</span> {user.gender}
            </p>
            <p>
              <div className="flex justify-end space-x-1">
                <button className="btn h-8 w-8 p-0 text-info hover:bg-info/20 focus:bg-info/20 active:bg-info/25">
                  <i className="fa fa-edit"></i>
                </button>
                <button className="btn h-8 w-8 p-0 text-error hover:bg-error/20 focus:bg-error/20 active:bg-error/25">
                  <i className="fa fa-trash-alt"></i>
                </button>
              </div>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
