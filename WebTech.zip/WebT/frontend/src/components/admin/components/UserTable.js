import React from 'react'
import m1 from '../../../static/images/avater/male/m1.png'
import m2 from '../../../static/images/avater/male/m2.png'
import m3 from '../../../static/images/avater/male/m3.png'
import m4 from '../../../static/images/avater/male/m4.png'
import m5 from '../../../static/images/avater/male/m5.png'
import m6 from '../../../static/images/avater/male/m6.png'
import m7 from '../../../static/images/avater/male/m7.png'
import m8 from '../../../static/images/avater/male/m8.png'
import m9 from '../../../static/images/avater/male/m9.png'
import m10 from '../../../static/images/avater/male/m10.png'
import m11 from '../../../static/images/avater/male/m11.png'
import m12 from '../../../static/images/avater/male/m12.png'

import f1 from '../../../static/images/avater/female/f1.png'
import f2 from '../../../static/images/avater/female/f2.png'
import f3 from '../../../static/images/avater/female/f3.png'
import f4 from '../../../static/images/avater/female/f4.png'
import f5 from '../../../static/images/avater/female/f5.png'
import f6 from '../../../static/images/avater/female/f6.png'
import f7 from '../../../static/images/avater/female/f7.png'
import f8 from '../../../static/images/avater/female/f8.png'
import f9 from '../../../static/images/avater/female/f9.png'
import f10 from '../../../static/images/avater/female/f10.png'
import f11 from '../../../static/images/avater/female/f11.png'
import f12 from '../../../static/images/avater/female/f12.png'

const avaters = {
    'm1': m1,
    'm2': m2,
    'm3': m3,
    'm4': m4,
    'm5': m5,
    'm6': m6,
    'm7': m7,
    'm8': m8,
    'm9': m9,
    'm10': m10,
    'm11': m11,
    'm12': m12,
    'f1': f1,
    'f2': f2,
    'f3': f3,
    'f4': f4,
    'f5': f5,
    'f6': f6,
    'f7': f7,
    'f8': f8,
    'f9': f9,
    'f10': f10,
    'f11': f11,
    'f12': f12,
}

export function UserTable ({ users }) {
    return (
        <div className="overflow-x-auto">
            <table className="w-full text-left">
                <thead>
                    <tr>
                        <th className="whitespace-nowrap rounded-tl-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            #
                        </th>
                        <th className="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Avatar
                        </th>
                        <th className="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Name
                        </th>
                        <th className="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Usename
                        </th>
                        <th className="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Country
                        </th>
                        <th className="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Preferred Brands
                        </th>
                        <th className="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Plan Type
                        </th>
                        <th className="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.length === 0 ? <tr><td colSpan="8"><div className="text-center flex flex-col justify-center text-4xl font-semibold h-50">
                        No Users Found
                    </div></td></tr> :
                    users.map(user => <UserRow user={user} key={user.id} />)}
                </tbody>
            </table>
        </div>
    )
};

function UserRow ({user}) {
    return (
        <tr className="border-y border-transparent border-b-slate-200 dark:border-b-navy-500">
            <td className="whitespace-nowrap px-4 py-3 sm:px-5">
                {user.id+1}
                </td>
            <td className="whitespace-nowrap px-4 py-3 sm:px-5">
                <div className="avatar flex">
                    <img className="rounded-full"
                     src={avaters[user.avater]}
                      alt="avatar" />
                </div>
            </td>
            <td className="whitespace-nowrap px-4 py-3 font-medium text-slate-700 dark:text-navy-100 sm:px-5">
                {user.name}
            </td>
            <td className="whitespace-nowrap px-4 py-3 font-medium text-slate-700 dark:text-navy-100 sm:px-5">
                {user.username}
            </td>
            <td className="whitespace-nowrap px-4 py-3 sm:px-5">
                {user.country}
            </td>
            <td className="whitespace-nowrap px-4 py-3 sm:px-5">
                <div className="flex space-x-2">
                    <div className="badge rounded-full border border-info text-info">
                        Tailwind
                    </div>
                    <div className="badge rounded-full border border-success text-success">
                        Alpine
                    </div>
                </div>
            </td>
            <td className="whitespace-nowrap px-4 py-3 sm:px-5">
                <div
                className={"badge rounded-full" + (user.plan_type === 'premium' ? 'bg-secondary/10 text-secondary dark:bg-secondary-light/15 dark:text-secondary-light' : 'bg-info/10 text-info dark:bg-info/15')}
                // className="bg-secondary/10 text-secondary dark:bg-secondary-light/15 dark:text-secondary-light"
                >
                    {user.plan_type.charAt(0).toUpperCase() + user.plan_type.slice(1)}
                </div>
            </td>
            <td className="whitespace-nowrap px-4 py-3 sm:px-5">
                <div className="flex space-x-1">
                    <button className="btn h-8 w-8 p-0 text-info hover:bg-info/20 focus:bg-info/20 active:bg-info/25">
                        <i className="fa fa-edit"></i>
                    </button>
                    <button className="btn h-8 w-8 p-0 text-error hover:bg-error/20 focus:bg-error/20 active:bg-error/25">
                        <i className="fa fa-trash-alt"></i>
                    </button>
                </div>
            </td>
        </tr>
    )
}