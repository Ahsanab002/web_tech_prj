import React, { useState } from 'react';
import { Search, ChevronDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "../../components/admin/components/ui/Card.js";

const FAQItem = ({ question, answer, isOpen, onClick }) => (
  <div className="border rounded-lg mb-2">
    <button
      onClick={onClick}
      className="w-full p-4 flex justify-between items-center text-left hover:bg-gray-50 transition-colors"
    >
      <span className="font-medium">{question}</span>
      <ChevronDown 
        className={`transform transition-transform duration-200 ${
          isOpen ? 'rotate-180' : ''
        }`}
        size={20}
      />
    </button>
    <div
      className={`overflow-hidden transition-all duration-200 ${
        isOpen ? 'max-h-96 p-4 pt-0' : 'max-h-0'
      }`}
    >
      <p className="text-gray-600">{answer}</p>
    </div>
  </div>
);

export const FAQsAdmin = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [openItems, setOpenItems] = useState({});
  
  const faqs = [
    {
      id: '1',
      question: 'How do I reset my password?',
      answer: 'To reset your password, click on the "Forgot Password" link on the login page. You will receive an email with instructions to create a new password. Follow the link in the email to complete the process.',
      category: 'Account Management'
    },
    {
      id: '2',
      question: 'How can I export my data?',
      answer: 'You can export your data by navigating to Settings > Data Export. Select the date range and type of data you want to export, then click "Generate Report". The export will be available in CSV or Excel format.',
      category: 'Data Management'
    },
    {
      id: '3',
      question: 'Can I change my subscription plan?',
      answer: 'Yes, you can change your subscription plan at any time. Go to Billing > Subscription and select "Change Plan". Your billing will be prorated based on the time remaining in your current billing cycle.',
      category: 'Billing'
    },
    {
      id: '4',
      question: 'How do I add team members?',
      answer: 'To add team members, go to Team > Invite Members. Enter their email addresses and select their role permissions. They will receive an invitation email to join your organization.',
      category: 'Team Management'
    },
    {
      id: '5',
      question: 'What are the system requirements?',
      answer: 'Our platform works best on modern browsers like Chrome, Firefox, Safari, and Edge. We recommend keeping your browser updated to the latest version for optimal performance.',
      category: 'Technical'
    }
  ];

  const toggleItem = (id) => {
    setOpenItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // Filter FAQs based on search query
  const filteredFAQs = faqs.filter(faq =>
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Group FAQs by category
  const groupedFAQs = filteredFAQs.reduce((acc, faq) => {
    if (!acc[faq.category]) {
      acc[faq.category] = [];
    }
    acc[faq.category].push(faq);
    return acc;
  }, {});

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">Frequently Asked Questions</CardTitle>
        <div className="relative mt-4">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search FAQs..."
            className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </CardHeader>
      <CardContent>
        {Object.entries(groupedFAQs).map(([category, categoryFAQs]) => (
          <div key={category} className="mb-6">
            <h3 className="text-lg font-semibold mb-3 text-gray-700">{category}</h3>
            {categoryFAQs.map((faq) => (
              <FAQItem
                key={faq.id}
                question={faq.question}
                answer={faq.answer}
                isOpen={openItems[faq.id]}
                onClick={() => toggleItem(faq.id)}
              />
            ))}
          </div>
        ))}
        {filteredFAQs.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No FAQs found matching your search.
          </div>
        )}
      </CardContent>
    </Card>
  );
};
