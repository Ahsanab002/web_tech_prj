import React from "react";
import logo from "../../static/logo22.svg";
import avatar from "./avatar.png";
import { NavLink, Link } from "react-router-dom";

export const SidebarAdmin = () => {
  return (
    <div className="main-sidebar">
      <div className=" rounded-lg flex h-full w-full flex-col items-center border-r border-slate-150 bg-white dark:border-navy-700 dark:bg-navy-800">
        <div className="flex pt-4">
        <Link to="/" exact="true">
              <img
                className="h-8 w-8 transition-transform duration-500 ease-in-out hover:rotate-[360deg]"
                src={logo}
                alt="logo"
              />
            </Link>
        </div>

        <div id="admin_nav" className="flex grow flex-col space-y-4 pt-6">

          <NavLink exact="true"
            to="/admin/dashboard"
            className="flex h-11 w-11 items-center justify-center rounded-lg outline-none transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25"
          >
            <svg
              className="h-7 w-7"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M9.85714 3H4.14286C3.51167 3 3 3.51167 3 4.14286V9.85714C3 10.4883 3.51167 11 4.14286 11H9.85714C10.4883 11 11 10.4883 11 9.85714V4.14286C11 3.51167 10.4883 3 9.85714 3Z"
                fill="currentColor"
              ></path>
              <path
                d="M9.85714 12.8999H4.14286C3.51167 12.8999 3 13.4116 3 14.0428V19.757C3 20.3882 3.51167 20.8999 4.14286 20.8999H9.85714C10.4883 20.8999 11 20.3882 11 19.757V14.0428C11 13.4116 10.4883 12.8999 9.85714 12.8999Z"
                fill="currentColor"
                fillOpacity="0.3"
              ></path>
              <path
                d="M19.757 3H14.0428C13.4116 3 12.8999 3.51167 12.8999 4.14286V9.85714C12.8999 10.4883 13.4116 11 14.0428 11H19.757C20.3882 11 20.8999 10.4883 20.8999 9.85714V4.14286C20.8999 3.51167 20.3882 3 19.757 3Z"
                fill="currentColor"
                fillOpacity="0.3"
              ></path>
              <path
                d="M19.757 12.8999H14.0428C13.4116 12.8999 12.8999 13.4116 12.8999 14.0428V19.757C12.8999 20.3882 13.4116 20.8999 14.0428 20.8999H19.757C20.3882 20.8999 20.8999 20.3882 20.8999 19.757V14.0428C20.8999 13.4116 20.3882 12.8999 19.757 12.8999Z"
                fill="currentColor"
                fillOpacity="0.3"
              ></path>
            </svg>
          </NavLink>

          <NavLink exact="true"
            to="/admin/chats"
            className="flex h-11 w-11 items-center justify-center rounded-lg outline-none transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25"
          >
            <svg
              className="h-5 w-5"
              viewBox="0 0 512 512"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillOpacity="0.4"
                d="M499.884 479.3c-20.4-5-35.8-19.9-46.6-34.7 37.5-29.4 58.8-69.9 58.8-113 0-36-15-69.2-40.1-95.7-28.7 92.2-129.1 161-247.9 161-15.9 0-31.6-1.2-46.9-3.6-8.9 4.3-18.2 8.4-26.7 11.8 32.3 49.6 96.2 83.4 169.6 83.4 15 0 29.6-1.4 43.4-4.1 45.9 23.4 87.8 27.7 112.4 27.7 13.5 0 21.8-1.3 22.8-1.4 7.5-1.2 13.1-7.6 13.4-15.1.3-7.8-4.8-14.5-12.2-16.3z"
                fill="currentcolor"
              ></path>
              <path
                d="M224.084 0c-123.5 0-224 81.8-224 182.4 0 50.9 25.6 98.7 70.8 133.1-14.9 23.3-34.3 46.9-58.7 53-7.7 1.9-12.9 9.2-12.1 17.1s7.3 14 15.3 14.4c.4 0 1.7.1 4 .1 16.5 0 80.4-2.7 152.9-40.3 16.6 3.4 34 5 51.7 5 123.5 0 224-81.8 224-182.4S347.584 0 224.084 0z"
                fill="currentcolor"
              ></path>
            </svg>
          </NavLink>

          <NavLink exact="true"
            to="/admin/users"
            className="flex h-11 w-11 items-center justify-center rounded-lg outline-none transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25"
          >
            <svg
              className="h-7 w-7"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
              <g
                id="SVGRepo_tracerCarrier"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></g>
              <g id="SVGRepo_iconCarrier">
                <path
                  d="M15.5 7.5C15.5 9.433 13.933 11 12 11C10.067 11 8.5 9.433 8.5 7.5C8.5 5.567 10.067 4 12 4C13.933 4 15.5 5.567 15.5 7.5Z"
                  fill="currentColor"
                ></path>
                <path
                  opacity="0.4"
                  d="M19.5 7.5C19.5 8.88071 18.3807 10 17 10C15.6193 10 14.5 8.88071 14.5 7.5C14.5 6.11929 15.6193 5 17 5C18.3807 5 19.5 6.11929 19.5 7.5Z"
                  fill="currentColor"
                ></path>
                <path
                  opacity="0.4"
                  d="M4.5 7.5C4.5 8.88071 5.61929 10 7 10C8.38071 10 9.5 8.88071 9.5 7.5C9.5 6.11929 8.38071 5 7 5C5.61929 5 4.5 6.11929 4.5 7.5Z"
                  fill="currentColor"
                ></path>
                <path
                  d="M18 16.5C18 18.433 15.3137 20 12 20C8.68629 20 6 18.433 6 16.5C6 14.567 8.68629 13 12 13C15.3137 13 18 14.567 18 16.5Z"
                  fill="currentColor"
                ></path>
                <path
                  opacity="0.4"
                  d="M22 16.5C22 17.8807 20.2091 19 18 19C15.7909 19 14 17.8807 14 16.5C14 15.1193 15.7909 14 18 14C20.2091 14 22 15.1193 22 16.5Z"
                  fill="currentColor"
                ></path>
                <path
                  opacity="0.4"
                  d="M2 16.5C2 17.8807 3.79086 19 6 19C8.20914 19 10 17.8807 10 16.5C10 15.1193 8.20914 14 6 14C3.79086 14 2 15.1193 2 16.5Z"
                  fill="currentColor"
                ></path>
              </g>
            </svg>
          </NavLink>

          <NavLink exact="true"
            to="/admin/faqs"
            className="flex h-11 w-11 items-center justify-center rounded-lg outline-none transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25"
          >
            <svg
                className="h-7 w-7"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
              <g
                id="SVGRepo_tracerCarrier"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></g>
              <g id="SVGRepo_iconCarrier">
                <path
                  opacity="0.5"
                  d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z"
                  fill="currentcolor"
                ></path>
                <path
                  d="M12 7.75C11.3787 7.75 10.875 8.25368 10.875 8.875C10.875 9.28921 10.5392 9.625 10.125 9.625C9.71079 9.625 9.375 9.28921 9.375 8.875C9.375 7.42525 10.5503 6.25 12 6.25C13.4497 6.25 14.625 7.42525 14.625 8.875C14.625 9.58584 14.3415 10.232 13.883 10.704C13.7907 10.7989 13.7027 10.8869 13.6187 10.9708C13.4029 11.1864 13.2138 11.3753 13.0479 11.5885C12.8289 11.8699 12.75 12.0768 12.75 12.25V13C12.75 13.4142 12.4142 13.75 12 13.75C11.5858 13.75 11.25 13.4142 11.25 13V12.25C11.25 11.5948 11.555 11.0644 11.8642 10.6672C12.0929 10.3733 12.3804 10.0863 12.6138 9.85346C12.6842 9.78321 12.7496 9.71789 12.807 9.65877C13.0046 9.45543 13.125 9.18004 13.125 8.875C13.125 8.25368 12.6213 7.75 12 7.75Z"
                  fill="currentcolor"
                ></path>
                <path
                  d="M12 17C12.5523 17 13 16.5523 13 16C13 15.4477 12.5523 15 12 15C11.4477 15 11 15.4477 11 16C11 16.5523 11.4477 17 12 17Z"
                  fill="currentcolor"
                ></path>
              </g>
            </svg>
          </NavLink>

        </div>

        <div className="flex flex-col items-center space-y-3 py-3">
          <div
            x-data="usePopper({placement:'right-end',offset:12})"
            className="flex"
          >
            <button x-ref="popperRef" className="avatar h-12 w-12">
              <img
                className="rounded-full"
                src={avatar}
                alt="avatar"
              />
              <span className="absolute right-0 h-3.5 w-3.5 rounded-full border-2 border-white bg-success dark:border-navy-700"></span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
