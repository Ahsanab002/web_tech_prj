import React, { createContext, useState, useEffect } from 'react';

export const AdminChatContext = createContext();

const AdminChatProvider = ({ children }) => {
  const [adminMessages, setAdminMessages] = useState([]); // State to hold admin messages
  const [loading, setLoading] = useState(true); // State to manage loading status
  const [error, setError] = useState(null); // State to manage error status

  const fetchAdminMessages = async () => {
    try {
      const response = await fetch('/api/chat/admin');
      if (!response.ok) {
        throw new Error('Failed to fetch messages');
      }
      const data = await response.json();
      setAdminMessages(data); // Update admin messages state
    } catch (error) {
      setError(error.message); // Set error message on failure
    } finally {
      setLoading(false); // Set loading to false regardless of success or failure
    }
  };

  useEffect(() => {
    fetchAdminMessages(); // Fetch messages when component mounts
  }, []);

  return (
    <AdminChatContext.Provider value={{ adminMessages, loading, error, setAdminMessages }}>
      {children}
    </AdminChatContext.Provider>
  );
};

export default AdminChatProvider;
