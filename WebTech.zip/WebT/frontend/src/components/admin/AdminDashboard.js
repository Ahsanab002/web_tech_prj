import React, { useEffect } from 'react';
import { Header } from '../elements/Header';
import { SidebarAdmin } from './Sidebar';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';

export const AdminDashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (location.pathname === '/admin') {
      navigate('/admin/dashboard');
    }
  }, [location, navigate]);

  return (
    <>
      <Header />
      <SidebarAdmin />
      <main className='main-content pb-8'>
        <Outlet />
      </main>
    </>
  );
};
