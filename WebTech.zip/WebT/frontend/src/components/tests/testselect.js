import React from 'react';
import Select, { components } from 'react-select';
import { useState } from 'react';




// Your SVG Icon Component
const CustomIcon = () => (
    <button className="btn h-8 w-8 rounded-full p-0 hover:bg-slate-300/20 focus:bg-slate-300/20 active:bg-slate-300/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25 sm:h-9 sm:w-9">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24">
                <path fill="currentColor" d="M3 5.109C3 4.496 3.47 4 4.05 4h16.79c.58 0 1.049.496 1.049 1.109 0 .612-.47 1.108-1.05 1.108H4.05C3.47 6.217 3 5.721 3 5.11zM5.798 12.5c0-.612.47-1.109 1.05-1.109H18.04c.58 0 1.05.497 1.05 1.109s-.47 1.109-1.05 1.109H6.848c-.58 0-1.05-.497-1.05-1.109zM9.646 18.783c-.58 0-1.05.496-1.05 1.108 0 .613.47 1.109 1.05 1.109h5.597c.58 0 1.05-.496 1.05-1.109 0-.612-.47-1.108-1.05-1.108H9.646z"></path>
              </svg>
            </button>
);

// Custom Control Component
const CustomControl = ({ children, ...props }) => (
  <components.Control {...props}>
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <CustomIcon />
      {children}
    </div>
  </components.Control>
);

const options = [
    {value: 'Male', label: 'Male', name:'gender'},
    {value: 'Female', label: 'Female', name:'gender'},
    {value: 'free', label: 'Free', name:'plan_type'},
    {value: 'premium', label: 'Premium', name:'plan_type'},
    {value: 0, label: 'Rating 0', name:'rating'},
    {value: 1, label: 'Rating 1', name:'rating'},
    {value: 2, label: 'Rating 2', name:'rating'},
    {value: 3, label: 'Rating 3', name:'rating'},
    {value: 4, label: 'Rating 4', name:'rating'},
    {value: 5, label: 'Rating 5', name:'rating'},
  ]

export default function CustomSelect({handlefilteredUsers}) {
  const [selectedOptions, setSelectedOptions] = useState(null);

  return (
    <Select
      isMulti
      name='name'
      value={selectedOptions}
      onChange={(selectedOptions) => {
        setSelectedOptions(selectedOptions);
        handlefilteredUsers(selectedOptions)
      }}
      options={options}
      components={{ Control: CustomControl }}
    />
  );
}


// export default () => (
//   <Select
//     // isMulti
//     // name="filters"
//     // options={[
//     //   {value: 'Male', label: 'Male', name:'gender'},
//     //   {value: 'Female', label: 'Female', name:'gender'},
//     //   {value: 'free', label: 'Free', name:'plan_type'},
//     //   {value: 'premium', label: 'Premium', name:'plan_type'},
//     // ]}
//     // className="basic-multi-select"
//     // classNamePrefix="select"
//     // components={{ Control: CustomControl }}
//     // onChange={(e) => console.log(e)}
//     // styles={{
//     //   control: (base) => ({
//     //     ...base,
//     //     width: 'max-content',  // Control the width of the input
//     //     whiteSpace: 'nowrap',  // To display the text in a single line
//     //     height: '40px',        // Control the height of the input
//     //   }),
//     // }}
//   />
// );
