import React, { useState, useEffect, useContext } from 'react';
import { getProfiles, createProfile, updateProfile, deleteProfile } from '../services/api';
import AuthContext from '../context/AuthContext';

const Profile = () => {
    const [profiles, setProfiles] = useState([]);
    const [profileData, setProfileData] = useState({ bio: '', location: '', birth_date: '' });
    const { user } = useContext(AuthContext);

    useEffect(() => {
        fetchProfiles();
    }, []);

    const fetchProfiles = async () => {
        try {
            // const response = await getProfiles();
            setProfiles(response.data);
        } catch (error) {
            console.error('Error fetching profiles', error);
        }
    };

    const handleCreate = async (e) => {
        e.preventDefault();
        try {
            await createProfile(profileData);
            fetchProfiles();
        } catch (error) {
            console.error('Error creating profile', error);
        }
    };

    const handleUpdate = async (id) => {
        try {
            await updateProfile(id, profileData);
            fetchProfiles();
        } catch (error) {
            console.error('Error updating profile', error);
        }
    };

    const handleDelete = async (id) => {
        try {
            await deleteProfile(id);
            fetchProfiles();
        } catch (error) {
            console.error('Error deleting profile', error);
        }
    };

    return (
        <div>
            <h1>Profiles</h1>
            <form onSubmit={handleCreate}>
                <input type="text" placeholder="Bio" onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })} />
                <input type="text" placeholder="Location" onChange={(e) => setProfileData({ ...profileData, location: e.target.value })} />
                <input type="date" placeholder="Birth Date" onChange={(e) => setProfileData({ ...profileData, birth_date: e.target.value })} />
                <button type="submit">Create Profile</button>
            </form>
            <ul>
                {profiles.map(profile => (
                    <li key={profile.id}>
                        {profile.bio} - {profile.location} - {profile.birth_date}
                        <button onClick={() => handleUpdate(profile.id)}>Update</button>
                        <button onClick={() => handleDelete(profile.id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Profile;
