import React, { useState } from 'react';
import { Grid, Card, CardContent, Typography, TextField, Pagination } from '@mui/material';
import {users} from './usersarray';

// const users = [ /* array of user data */ ];

const MuiGridUsers = () => {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const itemsPerPage = 10;

  const handleSearch = (event) => {
    setSearch(event.target.value);
  };

  const handlePageChange = (event, value) => {
    setPage(value);
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(search.toLowerCase())
  );

  const displayedUsers = filteredUsers.slice(
    (page - 1) * itemsPerPage, 
    page * itemsPerPage
  );

  return (
    <div>
      <TextField label="Search" variant="outlined" fullWidth onChange={handleSearch} />
      <Grid container spacing={3}>
        {displayedUsers.map(user => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={user.id}>
            <Card>
              <CardContent>
                <Typography variant="h5">{user.name}</Typography>
                <Typography variant="body2">{user.email}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
      <Pagination 
        count={Math.ceil(filteredUsers.length / itemsPerPage)} 
        page={page} 
        onChange={handlePageChange} 
      />
    </div>
  );
};

export default MuiGridUsers;
