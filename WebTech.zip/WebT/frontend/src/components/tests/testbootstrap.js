import React, { useState } from 'react';
import { Card, Row, Col, Form, Pagination } from 'react-bootstrap';
import {users} from './usersarray';

// const users = [ /* array of user data */ ];

const BootstrapGridUsers = () => {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const itemsPerPage = 10;

  const handleSearch = (event) => {
    setSearch(event.target.value);
  };

  const handlePageChange = (number) => {
    setPage(number);
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(search.toLowerCase())
  );

  const displayedUsers = filteredUsers.slice(
    (page - 1) * itemsPerPage, 
    page * itemsPerPage
  );

  return (
    <div>
      <Form.Control 
        type="text" 
        placeholder="Search" 
        onChange={handleSearch} 
      />
      <Row>
        {displayedUsers.map(user => (
          <Col xs={12} sm={6} md={4} lg={3} key={user.id}>
            <Card>
              <Card.Body>
                <Card.Title>{user.name}</Card.Title>
                <Card.Text>{user.email}</Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
      <Pagination>
        {[...Array(Math.ceil(filteredUsers.length / itemsPerPage)).keys()].map(number => (
          <Pagination.Item 
            key={number + 1} 
            active={number + 1 === page} 
            onClick={() => handlePageChange(number + 1)}
          >
            {number + 1}
          </Pagination.Item>
        ))}
      </Pagination>
    </div>
  );
};

export default BootstrapGridUsers;
