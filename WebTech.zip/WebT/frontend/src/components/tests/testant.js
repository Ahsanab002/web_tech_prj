import React, { useState } from 'react';
import { Card, Row, Col, Input, Pagination } from 'antd';
import {users} from './usersarray';

const AntGridUsers = () => {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const itemsPerPage = 10;

  const handleSearch = (event) => {
    setSearch(event.target.value);
  };

  const handlePageChange = (page) => {
    setPage(page);
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(search.toLowerCase())
  );

  const displayedUsers = filteredUsers.slice(
    (page - 1) * itemsPerPage, 
    page * itemsPerPage
  );

  return (
    <div>
      <Input.Search 
        placeholder="Search" 
        onChange={handleSearch} 
      />
      <Row gutter={16}>
        {displayedUsers.map(user => (
          <Col xs={24} sm={12} md={8} lg={6} key={user.id}>
            <Card title={user.name}>
              <p>{user.email}</p>
            </Card>
          </Col>
        ))}
      </Row>
      <Pagination 
        current={page} 
        pageSize={itemsPerPage} 
        total={filteredUsers.length} 
        onChange={handlePageChange} 
      />
    </div>
  );
};

export default AntGridUsers;
