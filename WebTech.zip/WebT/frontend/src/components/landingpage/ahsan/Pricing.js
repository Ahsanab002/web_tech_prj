import React, { useState } from 'react';
import { Check } from 'lucide-react';

export const Pricing = () => {
  const [isAnnual, setIsAnnual] = useState(false);

  const pricingPlans = [
    {
      name: 'Basic',
      monthlyPrice: 99,
      annualPrice: 79,
      description: 'Perfect for small projects and individuals',
      features: [
        'Basic VR Modeling',
        'Simple 3D Models',
        'Standard GIS Maps',
        'Email Support',
        '5GB Storage',
        'Basic Analytics',
        '1 User'
      ],
      highlighted: false
    },
    {
      name: 'Professional',
      monthlyPrice: 199,
      annualPrice: 159,
      description: 'Ideal for growing businesses',
      features: [
        'Advanced VR Solutions',
        'Complex 3D Models',
        'Interactive GIS Maps',
        'Priority Support',
        '20GB Storage',
        'Advanced Analytics',
        '5 Users'
      ],
      highlighted: false
    },
    {
      name: 'Enterprise',
      monthlyPrice: 299,
      annualPrice: 239,
      description: 'For large scale operations',
      features: [
        'Enterprise VR Solutions',
        'Premium 3D Modeling',
        'Custom GIS Integration',
        '24/7 Support',
        'Unlimited Storage',
        'Custom Analytics',
        'Unlimited Users'
      ],
      highlighted: false
    }
  ];

  return (
    <div className="space-y-12 mt-24">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-5xl font-bold text-black mb-6">Simple, Transparent Pricing</h1>
        <p className="text-xl text-gray-700 mb-8">Choose the perfect plan for your needs</p>
        
        {/* Pricing Toggle */}
        {/* <div className="flex items-center justify-center space-x-4">
          <span className={`text-lg ${!isAnnual ? 'text-black font-semibold' : 'text-gray-500'}`}>
            Monthly
          </span>
          <button
            onClick={() => setIsAnnual(!isAnnual)}
            className="relative w-16 h-8 bg-gray-600 rounded-full p-1 transition-colors"
          >
            <div
              className={`absolute w-6 h-6 bg-white rounded-full transition-transform transform
                         ${isAnnual ? 'translate-x-8' : 'translate-x-0'}`}
            ></div>
          </button>
          <span className={`text-lg ${isAnnual ? 'text-black font-semibold' : 'text-gray-500'}`}>
            Annual (20% off)
          </span>
        </div> */}
      </div>

      {/* Pricing Cards */}
      <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
        {pricingPlans.map((plan) => (
          <div
            key={plan.name}
            className={`relative rounded-3xl overflow-hidden transition-all duration-300 transform hover:-translate-y-2
                      ${plan.highlighted ? 
                        'bg-gray-900 text-white scale-105' : 
                        'bg-white text-black'}`}
          >
            {plan.highlighted && (
              <div className="absolute top-0 right-0 bg-gray-400 text-black text-sm font-bold px-4 py-1 rounded-bl-lg">
                MOST POPULAR
              </div>
            )}
            
            <div className="p-8">
              <h3 className="text-2xl font-bold mb-2 text-black">{plan.name}</h3>
              <p className={`mb-6 ${plan.highlighted ? 'text-gray-400' : 'text-gray-600'}`}>
                {plan.description}
              </p>
              
              <div className="mb-6">
                <span className="text-5xl font-bold text-black">
                  ${isAnnual ? plan.annualPrice : plan.monthlyPrice}
                </span>
                <span className="text-lg text-gray-500">/month</span>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className={`w-5 h-5 mr-3 ${plan.highlighted ? 'text-gray-400' : 'text-black'}`} />
                    <span className={plan.highlighted ? 'text-gray-400' : 'text-black'}>{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                className={`w-full py-3 px-6 rounded-lg font-semibold transition-all 
                           ${plan.highlighted ? 'bg-white text-black hover:bg-gray-100' : 'bg-gray-600 text-white hover:bg-gray-700'}`}
              >
                Choose {plan.name}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Pricing;
