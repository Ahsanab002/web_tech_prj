// import React, { useState, useEffect } from "react";
// // import vectorImage1 from './Vector/3d-delivery-robot-working_23-2151150206-removebg.png';
// // import vectorImage2 from './Vector/man-with-shopping-car-business-finance_24877-53536-removebg-preview.png';
// // import vectorImage3 from './Vector/online-shopping-concept-with-characters_87771-4339-removebg-preview.png';

// export const AboutUs = () => {
//   const aboutText = "Welcome to Hero Host, a dynamic web hosting company based in South Africa, founded by Rudzani ('Sam') with a mission to deliver innovative digital solutions.";

//   return (
//     <>

//       <div className="main-content px-8 py-8">
//         <div className="about-section pb-8">
//           {/* About Us Section */}
//           <div className="flex items-center">
//             <div className="bg-blue-100 p-6 mb-20 max-w-3xl mx-auto">
//               <h2 className="text-6xl font-bold mt-2 mb-6 text-black">About Us</h2>
//               <p className="text-2xl mt-12 text-black">
//                 {aboutText}
//               </p>
//             </div>
//           </div>

//           {/* Vision Section */}
//           <div className="flex items-center">
//             <div className="bg-green-100 p-6 mb-20 max-w-3xl mx-auto">
//               <h3 className="text-6xl font-bold mb-6 text-black">Vision</h3>
//               <p className="text-2xl mt-12 mb-12 text-black">
//                 We aim to revolutionize the e-commerce landscape by developing a shopping assistant Chrome extension that leverages advanced technologies such as three.js to enhance user engagement and provide personalized shopping experiences.
//               </p>
//             </div>
//             <img src={""} alt="Vector Image" className="ml-8 w-1/2" />
//           </div>

//           <div className="flex items-center">
//             <div className="bg-yellow-100 p-6 mb-8 max-w-3xl mx-auto">
//               <h4 className="text-6xl font-bold mb-8 text-black">What We Offer</h4>
//               <ul className="list-disc pl-6 mt-4">
//                 <li className="text-2xl mt-2 text-black">Users can easily manage profiles and dashboards</li>
//                 <li className="text-2xl mt-2 text-black">Real-time recommendations using extension</li>
//                 <li className="text-2xl mt-2 text-black">Seamless user experience</li>
//                 <li className="text-2xl mt-2 text-black">Innovative Shopping AI Assistant</li>
//               </ul>
//             </div>
//             <img src={""} alt="Vector Image" className="ml-8 w-1/2" />
//           </div>

//           <p className="text-4xl mt-12 mb-4 max-w-3xl mx-auto text-black">
//             Ready to Transform your shopping experience?
//             Join Our Communtiy today!
//           </p>
//           <p className="text-4xl mt-12 mb-4 max-w-3xl mx-auto text-black">
//             Sign Up today
//           </p>
//           <p className="text-4xl mt-4 mb-4 max-w-3xl mx-auto text-black">
//            To start your journey towards hassle-free online shopping. Don't miss
//             out on exclusive offers and updates.
//           </p>
//           <button className="py-12 px-8 text-xl text-white bg-indigo-500 font-semibold rounded-md focus:outline-none hover:bg-indigo-600">
//               Sign Up Now
//             </button>
          
//         </div>
//       </div>
//     </>
//   );
// };

import React from "react";
import { Link } from "react-router-dom";

export const AboutUs = () => {
  return (
    <>
      <div
        style={{ height: "90vh" }}
        className="bg-indigo-500 text-white relative"
      >
        <div className="container mx-auto h-full">
          <div className="flex flex-col justify-center items-center h-full">
            <div className="grid grid-cols-12 gap-4">
              <div className="col-span-6 flex flex-col justify-center">
                <h1 className="text-4xl font-bold leading-normal">
                  Welcome to ImmerSix
                </h1>
                <p className="text-lg leading-loose">
                  Your ultimate companion in the online shopping world. We
                  enhance your shopping experience with smart, AI-driven
                  solutions for a perfect fit every time.
                </p>
              </div>
              <div className="col-span-6 flex flex-col justify-center items-center">
                <img
                  src=""
                  alt="About Us Image"
                  width="400px"
                  className="drop-shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 w-full bg-lightmode dark:bg-darkmode">
          {/* <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 96">
            <path
              fill="#6366F1"
              fillOpacity="1"
              d="M0,32L48,42.7C96,53,192,75,288,85.3C384,96,480,96,576,80C672,64,768,32,864,21.3C960,11,1056,21,1152,37.3C1248,53,1344,75,1392,85.3L1440,96L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"
            />
          </svg> */}
        </div>
      </div>
      <div className="container mx-auto leading-loose h-1/2vh flex flex-col justify-center">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100 mt-8 leading-loose text-center underline-center dark:underline-center relative">
          Who We Are
        </h1>
        <div className="my-10">
          <p className="text-lg font-bold text-gray-800 dark:text-gray-200 mt-4 leading-loose px-10 my-1">
           ImmersiX
          </p>
          <p className="text-lg text-gray-800 dark:text-gray-200 leading-loose px-10 mb-5">
            To solve the common problem of ill-fitting clothes and complicated
            returns. Our team of innovators and tech enthusiasts has created a
            state-of-the-art AI shopping assistant that understands your unique
            measurements and preferences.
          </p>
        </div>
      </div>
      <div className="bg-indigo-500 text-white">
        <div className="container mx-auto">
          <h1 className="text-4xl font-bold text-center py-8">
            <span className="line-middle"> OUR MISSION </span>
          </h1>
          <div className="grid grid-cols-2 grid-rows-4 gap-4">
            <div className="flex flex-col justify-center items-center">
              <img
                src=""
                alt="Mission Image"
                width="300px"
                className="drop-shadow-lg"
              />
            </div>
            <div className="flex flex-col justify-center">
              <p className="font-bold underline text-2xl leading-loose">
                Our Technology
              </p>
              <p className="text-xl leading-loose">
                Our advanced AI technology analyzes your measurements and
                shopping habits to provide personalized size recommendations,
                ensuring the best fit across brands and retailers.
              </p>
            </div>
            <div className="flex flex-col justify-center">
              <p className="font-bold underline text-2xl leading-loose">
                Why Choose Boopy?
              </p>
              <p className="text-xl leading-loose">
                With Boopy, enjoy a seamless integration of our Chrome extension
                with your favorite stores, real-time size suggestions, and a
                confident shopping experience.
              </p>
            </div>
            <div className="flex flex-col justify-center items-center">
              <img
                src=""
                alt="Why Choose Us Image"
                width="400px"
                className="drop-shadow-lg"
              />
            </div>
            <div className="flex flex-col justify-center items-center">
              <img
                src=""
                alt="Our Team Image"
                width="400px"
                className="drop-shadow-lg"
              />
            </div>
            <div className="flex flex-col justify-center">
              <p className="font-bold underline text-2xl leading-loose">
                Join Us
              </p>
              <p className="text-xl leading-loose">
                Become part of our community of happy shoppers. Sign up today
                and start enjoying a hassle-free, confident, and personalized
                online shopping experience.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="container mx-auto leading-loose h-1/2vh flex flex-col justify-center">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100 mt-8 leading-loose underline-start dark:underline-start relative">
          Contact Us
        </h1>
        <div className="my-10">
          <p className="text-lg text-gray-800 dark:text-gray-200 leading-loose mb-5">
            For any inquiries, feedback, or support, reach out to us at
            info@boopy.com. We’re here to assist you and ensure you have the
            best shopping experience possible.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-4 my-10">
          <div className="flex flex-col justify-center">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-8 leading-loose">
              Join Our Community
            </h1>
            <div className="my-2">
              <p className="text-lg text-gray-800 dark:text-gray-200 leading-loose mb-5">
                Become part of a community that values fit and fashion as much
                as you do. Sign up today and don’t miss out on exclusive offers
                and updates!
              </p>
              <div className="my-5">
                <Link
                  to="/signup"
                  className="py-2 px-10 bg-indigo-500 text-white text-sm font-semibold rounded-md focus:outline-none hover:border-b-2 border-indigo-500"
                >
                  Sign Up Now!
                </Link>
              </div>
            </div>
          </div>
          <div className="flex flex-col justify-center items-center">
            <img src="" alt="Join Us Image" width="450px" />
          </div>
        </div>
      </div>
    </>
  );
};

