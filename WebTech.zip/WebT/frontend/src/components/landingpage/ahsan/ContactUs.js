import React, { useState, useEffect } from "react";


export const ContactUs = () => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleUsernameChange = (e) => {
    setUsername(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className="App">
      <div className="main-content w-full ml-0 ">
        <div className="contact-section">
          <h2 className="text-center text-3xl font-bold mb-4">Contact Us</h2>
          <div className="contact-container">
            <form className="max-w-md mx-auto" onSubmit={handleSubmit}>
              <div className="mb-4">
                <label className="block text-lg mt-12 font-medium text-gray-800 dark:text-gray-200">Name</label>
                <input
                  className="form-input w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                  placeholder="Username"
                  type="text"
                  value={username}
                  onChange={handleUsernameChange}
                />
              </div>
              <div className="mb-4">
                <label className="block text-lg font-medium text-gray-800 dark:text-gray-200">Email</label>
                <input
                  className="form-input w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                  placeholder="Email"
                  type="email"
                  value={email}
                  onChange={handleEmailChange}
                />
              </div>
              <div className="mb-4">
                <label className="block text-lg font-medium text-gray-800 dark:text-gray-200">Message</label>
                <textarea
                  rows="4"
                  placeholder="Your Message"
                  className="form-textarea mt-1.5 w-full rounded-lg border border-slate-300 bg-transparent p-2.5 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                  value={message}
                  onChange={handleMessageChange}
                ></textarea>
              </div>
              <div className="flex justify-center">
                <button
                  type="submit"
                  className="flex items-center justify-center rounded-lg bg-primary/10 text-primary px-4 py-2 transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:bg-navy-600 dark:text-accent-light dark:hover:bg-navy-450 dark:focus:bg-navy-450 dark:active:bg-navy-450/90"
                >
                  Send Message
                </button>
              </div>
            </form>
            <img src="/7061403-removebg-preview.png" alt="Contact illustration" className="contact-illustration mx-auto mt-8" />
          </div>
        </div>
      </div>
    </div>
  );
};


