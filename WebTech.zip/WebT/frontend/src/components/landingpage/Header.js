import React, { useState, useEffect } from "react";
import logo from "../../../src/logo.png";
import { DarkModeBtn } from "../elements/DarkModeBtn";
import { NavLink, Link } from "react-router-dom";

export const Header = () => {
  return (
    <nav className="header" id="home_nav" style={{ width: "100%", height:"10%" }}>
      <div className="header-container relative flex w-full bg-white dark:bg-navy-700 print:hidden sm:flex-col">
        <div className="flex w-full items-center justify-between sm:h-16">
          <div className="hidden items-center space-x-2 sm:flex">
            <Link to="/" exact="true">
              <img
                className="h-8 w-8 transition-transform duration-500 ease-in-out hover:rotate-[360deg]"
                src={logo}
                alt="logo"
              />
            </Link>
            <span className="text-xl font-semibold uppercase text-slate-700 dark:text-navy-100">
              ImmersiX
            </span>
          </div>

          <div className="-mr-1.5 flex items-center space-x-2">
            <Link to="/admin" exact="true">AdminDashbord</Link>
            <Link to="/user" exact="true">UserDashbord</Link>
          <NavLink to="/" exact="true"
                className="py-2 px-5 rounded-md focus:outline-none hover:shadow-lg hover:border-b-2 border-indigo-500 "
              >
                Home
              </NavLink>
              <NavLink to="/aboutus"
                className="py-2 px-5 rounded-md focus:outline-none hover:shadow-lg hover:border-b-2 border-indigo-500"
              >
                About Us
              </NavLink>
              <NavLink to="/contactus"
                className="py-2 px-5 text-sm rounded-md focus:outline-none hover:shadow-lg hover:border-b-2 border-indigo-500"
              >
                Contact Us
              </NavLink>
              <NavLink to="/pricing"
                className="py-2 px-5 text-sm rounded-md focus:outline-none hover:shadow-lg hover:border-b-2 border-indigo-500"
              >
                Pricing
              </NavLink>
          <Link to="/login"
                className="py-2 px-8 bg-indigo-500 text-white text-sm font-semibold rounded-md focus:outline-none hover:border-b-2 border-indigo-500"
              >
                Login
              </Link>
            <DarkModeBtn />
          </div>
        </div>
      </div>
    </nav>
  );
};



