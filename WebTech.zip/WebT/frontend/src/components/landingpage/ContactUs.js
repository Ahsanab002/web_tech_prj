// import React, { useState } from "react";
// import contactus from "../../static/images/landpage/contactus.png";

// export const ContactUs = () => {
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [message, setMessage] = useState("");

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     // Handle form submission
//   };

//   const handleNameChange = (e) => {
//     setName(e.target.value);
//   };

//   const handleEmailChange = (e) => {
//     setEmail(e.target.value);
//   };

//   const handleMessageChange = (e) => {
//     setMessage(e.target.value);
//   };

//   return (
//     <div className="main-content min-h-80vh flex items-center justify-center mx-10">
//       <div className="contact-section w-full max-w-6xl mx-auto px-4 py-12">
//         <div className="contact-container grid grid-cols-1 lg:grid-cols-2 gap-8 items-center justify-center my-6">
//           <form className="w-full card p-4" onSubmit={handleSubmit}>
//             <p class="text-base font-medium ">
//               CONTACT US
//             </p>
//             <div className="mt-4 space-y-4">
//               <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
//               <label class="block">
//                 <span>Name</span>
//                 <span class="relative mt-1.5 flex">
//                   <input class="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent" 
//                   placeholder="Name" 
//                   type="text" 
//                   value={name}
//                   onChange={handleNameChange}
//                   />
//                   <span class="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
//                         <i class="far fa-user text-base"></i>
//                       </span>
//                 </span>
//               </label>
//               <label class="block">
//                 <span>Email</span>
//                 <span class="relative mt-1.5 flex">
//                   <input class="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent" 
//                   placeholder="someone@example.com" 
//                   type="email"
//                   value={email}
//                   onChange={handleEmailChange}
//                   />
//                   <span class="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
//                         <i class="fa-regular fa-envelope text-base"></i>
//                       </span>
//                 </span>
//               </label>
//               </div>
//               <label class="block">
//                   <span>Message</span>
//                   <textarea 
//                   rows="4"
//                   value={message}
//                   onChange={handleMessageChange}
//                    placeholder="Type your Mesasge..."
//                     class="form-textarea mt-1.5 w-full rounded-lg border border-slate-300 bg-transparent p-2.5 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"></textarea>
//                 </label>
//             </div>
//             <div className="mt-3">
//               <button
//                 type="submit"
//                 className="rounded-lg bg-primary/10 text-primary px-4 py-2 transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:bg-navy-600 dark:text-accent-light dark:hover:bg-navy-450 dark:focus:bg-navy-450 dark:active:bg-navy-450/90"
//               >
//                 Send Message
//               </button>
//             </div>
//           </form>
//           <div className=" flex flex-col justify-center items-center">
//             <img
//               src={contactus}
//               alt="Contact illustration"
//               className="contact-illustration max-w-full h-auto"
//               style={{ maxWidth: "400px" }}
//             />
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };


import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Check } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';


export const ContactUs = () => {
  const [formStatus, setFormStatus] = useState('idle'); // idle, sending, success, error
  
  const handleSubmit = (e) => {
    e.preventDefault();
    setFormStatus('sending');
    
    // Simulate form submission
    setTimeout(() => {
      setFormStatus('success');
      // Reset form after success
      setTimeout(() => setFormStatus('idle'), 3000);
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4">
      {/* Header */}
      <div className="text-center mb-16 mt-24">
        <h1 className="text-5xl font-bold text-black mb-6">Get in Touch</h1>
        <p className="text-xl text-gray-700 max-w-2xl mx-auto">
          Have a project in mind? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-12">
        {/* Contact Info Cards */}
        <div className="space-y-6">
          {[
            { icon: Mail, title: 'Email Us', content: 'contact@cgisolutions.com' },
            { icon: Phone, title: 'Call Us', content: '+1 (555) 123-4567' },
            { icon: MapPin, title: 'Visit Us', content: '123 Innovation Street, Tech City, TC 12345' }
          ].map(({ icon: Icon, title, content }) => (
            <div key={title} className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-start space-x-4">
                <div className="bg-gray-200 p-3 rounded-lg">
                  <Icon className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h3 className="font-semibold text-black mb-1">{title}</h3>
                  <p className="text-gray-600">{content}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Contact Form */}
        <div className="md:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white p-8 rounded-2xl shadow-lg">
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-gray-600 
                           focus:ring-2 focus:ring-gray-200 transition-all"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-gray-600 
                           focus:ring-2 focus:ring-gray-200 transition-all"
                  required
                />
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
              <input
                type="email"
                className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-gray-600 
                         focus:ring-2 focus:ring-gray-200 transition-all"
                required
              />
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
              <input
                type="text"
                className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-gray-600 
                         focus:ring-2 focus:ring-gray-200 transition-all"
                required
              />
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
              <textarea
                rows="6"
                className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-gray-600 
                         focus:ring-2 focus:ring-gray-200 transition-all resize-none"
                required
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={formStatus !== 'idle'}
              className={`w-full py-4 rounded-lg font-semibold text-white 
                       transition-all transform hover:scale-[1.02] 
                       ${formStatus === 'success' ? 
                         'bg-gray-600' : 
                         'bg-gradient-to-r from-gray-600 to-black'}`}
            >
              <div className="flex items-center justify-center space-x-2">
                {formStatus === 'idle' && (
                  <>
                    <Send className="w-5 h-5" />
                    <span>Send Message</span>
                  </>
                )}
                {formStatus === 'sending' && (
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                )}
                {formStatus === 'success' && (
                  <>
                    <Check className="w-5 h-5" />
                    <span>Message Sent!</span>
                  </>
                )}
              </div>
            </button>
          </form>
        </div>
      </div>

    </div>
  );
};

