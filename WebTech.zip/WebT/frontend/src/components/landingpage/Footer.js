import React from "react";
import fb_logo from "../../static/images/logos/facebook-round.svg";
import insta_logo from "../../static/images/logos/instagram-round.svg";
import twitter_logo from "../../static/images/logos/twitter-round.svg";
import { Link } from "react-router-dom";

export const Footer = () => {
  return (
    <div>
      <div className="translate-y-0.5">
        <svg
          className="w-full"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 1440 95"
          transform="matrix(-1, 0, 0, -1, 0, 0)"
        >
          <path
            fill="#6366F1"
            fillOpacity="1"
            d="M0,32L48,42.7C96,53,192,75,288,85.3C384,96,480,96,576,80C672,64,768,32,864,21.3C960,11,1056,21,1152,37.3C1248,53,1344,75,1392,85.3L1440,96L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"
          />
        </svg>
      </div>
      <div className="w-full bg-indigo-500 text-white">
        <div className="container mx-auto py-5 px-6">
          <h3 className="text-5xl font-mtcorsva col-span-12 my-4">ImmersiX</h3>
          <div className="grid grid-cols-12 gap-4">
            {/* <div className="col-span-4 leading-loose text-lg">
              akdkqkdlqkd
            </div> */}
            <div className="col-span-8 leading-10">
              <div className="flex justify-around">
                <div className="company-info">
                  <p className="underline text-xl">
                    Follow Us
                  </p>
                  <div className="social-icons mt-2">
                    <ul>
                      <li>
                        <a href="#" className="link-with-icon">
                          <img
                            src={insta_logo}
                            alt="Instagram"
                            className="h-5 w-5"
                          />
                          <span className="hover:underline">Instagram</span>
                        </a>
                      </li>
                      <li>
                        <a href="#" className="link-with-icon">
                          <img
                            src={fb_logo}
                            alt="Facebook"
                            className="h-5 w-5"
                          />
                          <span className="hover:underline">Facebook</span>
                        </a>
                      </li>
                      <li>
                        <a href="#" className="link-with-icon">
                          <img
                            src={twitter_logo}
                            alt="Twitter"
                            className="h-5 w-5"
                          />
                          <span className="hover:underline">Twitter</span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="useful-links">
                  <h3 className="text-xl underline">
                    Useful Links
                  </h3>
                  <ul>
                    <li>
                      <Link to="/" exact="true" className="hover:underline">
                        Homepage
                      </Link>
                    </li>
                    <li>
                      <Link to="/aboutus" className="hover:underline">
                        About Us
                      </Link>
                    </li>
                    <li>
                      <Link to="/contactus" className="hover:underline">
                        Contact Us
                      </Link>
                    </li>
                    <li>
                      <Link to="/pricing" className="hover:underline">
                        Pricing
                      </Link>
                    </li>
                  </ul>
                </div>
                <div className="contact-info">
                  <h3 className="text-xl underline">Contact Us</h3>
                  <p>Email: info@ImmersiX.com</p>
                  <p>Phone: +1234567890</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="py-2 bg-indigo-800">
            <p className="text-center">&copy; 2024 Copyright: ImmersiX | All Rights Reserved</p>
        </div>
      </div>
    </div>
  );
};
