import React from 'react'

export const Pricing = () => {
  return (
    <div>Pricing</div>
  )
}
