import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Star, Award, Users, Briefcase } from 'lucide-react';
import './index.css';
import { FAQsAdmin } from '../admin/FAQs';

// import home1 from "../../static/images/landpage/home1.png";
// import home2 from "../../static/images/landpage/home2.png";
// import home3 from "../../static/images/landpage/home3.png";
// import home4 from "../../static/images/landpage/home4.png";
// import home5 from "../../static/images/landpage/home5.png";
// import home6 from "../../static/images/landpage/home6.png";
import { Link } from "react-router-dom";

// export const Home = () => {
//   return (
//     <>
//       <div
//         style={{ height: "90vh" }}
//         className="bg-indigo-500 text-white relative"
//       >
//         <div className="container mx-auto h-full">
//           <div className="flex flex-col justify-center items-center h-full">
//             <div className="grid grid-cols-12 gap-4">
//               <div className="col-span-6 flex flex-col justify-center">
//                 <h1 className="text-4xl font-bold leading-normal">
//                 Welcome to the Future of CGI & VR Solutions!
                  
//                 </h1>
//                 <p className="text-lg leading-loose">
//                   {/* Anywhere  */}
//                 </p>
//               </div>
//               <div className="col-span-6 flex flex-col justify-center items-center">
//                 <img
//                   src={home1}
//                   alt="PIC1"
//                   width="400px"
//                   className="drop-shadow-lg"
//                 />
//               </div>
//             </div>
//           </div>
//         </div>
//         <div className="absolute bottom-0 w-full bg-lightmode dark:bg-darkmode">
//           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 96">
//             <path
//               fill="#6366F1"
//               fillOpacity="1"
//               d="M0,32L48,42.7C96,53,192,75,288,85.3C384,96,480,96,576,80C672,64,768,32,864,21.3C960,11,1056,21,1152,37.3C1248,53,1344,75,1392,85.3L1440,96L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"
//             />
//           </svg>
//         </div>
//       </div>
//       <div className="container mx-auto leading-loose h-1/2vh flex flex-col justify-center">
//         <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100 mt-8 leading-loose text-center underline-center dark:underline-center relative">
//           Welcome to the Future of CGI & VR!
//         </h1>
//         <div className="my-10">
//           <p className="text-lg font-bold text-gray-800 dark:text-gray-200 mt-4 leading-loose px-10 my-1">
//           Transforming Imagination into Reality with Cutting-Edge Technology
//           </p>
//           <p className="text-lg text-gray-800 dark:text-gray-200 leading-loose px-10 mb-5">
//           Experience the power of our advanced CGI and VR solutions that bring your creative visions to life. 
//           From interactive virtual environments to realistic 3D models,
//            we provide immersive experiences that engage and captivate.
//           </p>
//         </div>
//       </div>
//       <div className="bg-indigo-500 text-white">
//         <div className="container mx-auto">
//           <h1 className="text-4xl font-bold text-center py-8">
//             <span className="line-middle"> KEY BENEFITS </span>
//           </h1>
//           <div className="grid grid-cols-2 grid-rows-4 gap-4">
//             <div className="flex flex-col justify-center items-center">
//               <img
//                 src={home2}
//                 alt="PIC1"
//                 width="300px"
//                 className="drop-shadow-lg"
//               />
//             </div>
//             <div className="flex flex-col justify-center">
//               <p className="font-bold underline text-2xl leading-loose">
//               Immersive Virtual Experiences
//               </p>
//               <p className="text-xl leading-loose">
//               Our VR solutions allow you to step into fully immersive worlds 
//               that bring new levels of interactivity and realism to gaming, education, and professional training.
//               </p>
//             </div>
//             <div className="flex flex-col justify-center">
//               <p className="font-bold underline text-2xl leading-loose">
//               Cutting-Edge Technology Integration
//               </p>
//               <p className="text-xl leading-loose">
//               We integrate the latest VR technology with high-end CGI techniques 
//               to create experiences that push the boundaries of what’s possible in virtual environments.
//               </p>
//             </div>
//             <div className="flex flex-col justify-center items-center">
//               <img
//                 src={home3}
//                 alt="PIC1"
//                 width="400px"
//                 className="drop-shadow-lg"
//               />
//             </div>
//             <div className="flex flex-col justify-center items-center">
//               <img
//                 src={home4}
//                 alt="PIC1"
//                 width="400px"
//                 className="drop-shadow-lg"
//               />
//             </div>
//             <div className="flex flex-col justify-center">
//               <p className="font-bold underline text-2xl leading-loose">
//               Customized Solutions for Every Need
//               </p>
//               <p className="text-xl leading-loose">
//               Whether you need CGI for a marketing campaign or a VR simulation for training, 
//               we provide customized solutions tailored to your specific goals and requirements.
//               </p>
//             </div>
//             {/* <div className="flex flex-col justify-center">
//               <p className="font-bold underline text-2xl leading-loose">
//                 Confident Shopping
//               </p>
//               <p className="text-xl leading-loose">
//                 Enjoy a shopping experience tailored to your body shape and
//                 preferences. Our AI ensures that you always look and feel your
//                 best in every purchase.
//               </p>
//             </div> */}
//             <div className="flex flex-col justify-center items-center">
//               <img
//                 src={home5}
//                 alt="PIC1"
//                 width="400px"
//                 className="drop-shadow-lg"
//               />
//             </div>
//           </div>
//         </div>
//       </div>
//       <div className="container mx-auto leading-loose h-1/2vh flex flex-col justify-center">
//         <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100 mt-8 leading-loose underline-start dark:underline-start relative">
//         Join Our Creative Community Today!
//         </h1>
//         <div className="my-10">
//           <p className="text-lg text-gray-800 dark:text-gray-200 leading-loose mb-5">
//           Be part of a creative revolution where innovation meets technology. Sign up today to start 
//           your journey with groundbreaking CGI and VR experiences that will take your projects to the next level.
//           </p>
//         </div>
//         <div className="grid grid-cols-2 gap-4 my-10">
//           <div className="flex flex-col justify-center">
//             <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-8 leading-loose">
//             Ready to Create the Future with Us?
//             </h1>
//             <div className="my-2">
//               <p className="text-lg text-gray-800 dark:text-gray-200 leading-loose mb-5">
//               Join us today and start collaborating on the next big CGI or VR project. 
//               We’re excited to work with innovators 
//               who are ready to bring their ideas to life in exciting new ways!
//               </p>
//               <div className="my-5">
//               <Link to="/signup"
//                 className="py-2 px-10 bg-indigo-500 text-white text-sm font-semibold rounded-md focus:outline-none hover:border-b-2 border-indigo-500"
//               >
//                 Sign Up Now!
//               </Link>
//               </div>
//             </div>
//             </div>
//             <div className="flex flex-col justify-center items-center">
//               <img
//                 src={home6}
//                 alt="PIC1"
//                 width="450px"
//               />
//             </div>
//         </div>
//       </div>
//     </>
//   );
// };





export const Home = () => {




  const navigate = useNavigate();

  const handleGetStartedClick = () => {
    navigate('/signup');
  };
  const [currentProject, setCurrentProject] = useState(0);

  const projects = [
    {
      title: "Architectural Visualization",
      tags: ["3D Modeling", "VR Experience", "Real-time Rendering"],
      description: "Photorealistic architectural visualizations for luxury real estate"
    },
    {
      title: "Product Animation",
      tags: ["Animation", "Product Design", "Marketing"],
      description: "Dynamic product showcases for leading tech brands"
    },
    {
      title: "Virtual Reality Campus",
      tags: ["VR Development", "Interactive Design", "Education"],
      description: "Immersive educational environments for remote learning"
    }
  ];

  const stats = [
    { label: 'Completed Projects', value: '500+', icon: <Briefcase className="w-6 h-6" /> },
    { label: 'Happy Clients', value: '200+', icon: <Star className="w-6 h-6" /> },
    { label: 'Team Members', value: '50+', icon: <Users className="w-6 h-6" /> },
    { label: 'Awards Won', value: '25+', icon: <Award className="w-6 h-6" /> }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentProject((prev) => (prev + 1) % projects.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="relative min-h-[80vh] flex items-center bg-black">
        <div className="absolute inset-0 opacity-10">
          <div className="w-full h-full" 
               style={{
                 backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
                 backgroundSize: '20px 20px'
               }}>
          </div>
        </div>
        
        <div className="relative z-10 max-w-6xl mx-auto px-4 py-24">
          <div className="space-y-6">
            <h1 className="text-6xl font-bold text-white md:text-7xl">
              Next-Gen CGI
              <span className="block text-gray-300">Solutions</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl md:text-2xl">
              Transform your vision into reality with cutting-edge visualization technology
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="group bg-white text-black px-6 py-3 rounded-full font-bold text-lg hover:bg-gray-100 transition-all flex items-center"
              onClick={handleGetStartedClick}>
              
                Get Started Today
                <ArrowRight className="ml-2 transition-transform group-hover:translate-x-1" />
              </button>
              <button className="bg-transparent border-2 border-white text-white px-6 py-3 rounded-full font-bold text-lg hover:bg-white/10 transition-all">
                Watch Demo
              </button>
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute right-0 top-0 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute left-0 bottom-0 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
      </div>

      {/* Projects Section */}
      <div className="py-24 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-black text-center">Featured Projects</h2>
          <div className="overflow-hidden rounded-3xl shadow-lg">
            <div className="aspect-video bg-black relative">
              <img
                src="/api/placeholder/1200/600"
                alt={projects[currentProject].title}
                className="w-full h-full object-cover opacity-75 mix-blend-overlay"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent">
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <h3 className="text-3xl font-bold text-white mb-4">{projects[currentProject].title}</h3>
                  <p className="text-xl text-gray-300 mb-4">{projects[currentProject].description}</p>
                  <div className="flex flex-wrap gap-2">
                    {projects[currentProject].tags.map((tag, index) => (
                      <span key={index} className="px-4 py-2 bg-white/20 rounded-full text-white text-sm">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Offer Banner */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="bg-black p-12 rounded-3xl text-white relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <span className="inline-block px-4 py-2 bg-white/20 rounded-full text-sm mb-4">Limited Time Offer</span>
            <h2 className="text-4xl font-bold mb-4">Special Launch Offer!</h2>
            <p className="text-xl text-gray-300 mb-8">
              Get 30% off on all Enterprise 3D modeling services
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="group bg-white text-black px-6 py-3 rounded-full font-bold hover:bg-gray-100 transition-all flex items-center">
                Claim Offer
                <ArrowRight className="ml-2 transition-transform group-hover:translate-x-1" />
              </button>
              <button className="border-2 border-white text-white px-6 py-3 rounded-full font-bold hover:bg-white/10 transition-all">
                Learn More
              </button>
            </div>
          </div>

          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full -ml-32 -mb-32"></div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-24 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} 
                   className="group p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all border border-gray-100">
                <div className="flex flex-col items-center text-center">
                  <div className="mb-4 text-black transition-transform group-hover:scale-110">
                    {stat.icon}
                  </div>
                  <div className="text-4xl font-bold text-black mb-2">{stat.value}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              </div>
              
            ))}
            <div className="container col-span-4 mx-auto bg-white-700 p-8 rounded-3xl "> {/* Changed container color to gray-700 */}
                    <FAQsAdmin />
                  </div>
          </div>
        </div>
      </div>
    </div>
  );
};

