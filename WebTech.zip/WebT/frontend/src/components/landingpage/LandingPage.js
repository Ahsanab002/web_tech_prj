import React from "react";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { Outlet } from 'react-router-dom';

export const LandingPage = () => {
  return (
    <>
        <Header />
        <div className="mt-16" style={{ minHeight: "80vh" }}>
        <Outlet />
        </div>
        <Footer />
        
    </>
  );
};

export default LandingPage;
