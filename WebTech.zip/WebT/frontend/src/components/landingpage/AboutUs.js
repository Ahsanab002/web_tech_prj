import React from 'react';
import { ArrowRight, CheckCircle2, ChevronRight } from 'lucide-react';

export const AboutUs = () => {
  const services = [
    {
      name: 'VR Modeling',
      description: 'Immersive virtual reality experiences with photorealistic detail and interactive elements.',
      features: ['Real-time rendering', 'Interactive environments', 'Custom controls'],
      icon: '🎮',
      gradient: 'from-blue-500 to-purple-500'
    },
    {
      name: '3D Modeling',
      description: 'Professional 3D modeling services for product visualization, animation, and manufacturing.',
      features: ['High-poly modeling', 'Texture mapping', 'Animation ready'],
      icon: '🎨',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      name: 'GIS Maps',
      description: 'Advanced Geographic Information System mapping for analysis and visualization.',
      features: ['Real-time data', 'Custom overlays', 'Interactive layers'],
      icon: '🗺️',
      gradient: 'from-pink-500 to-orange-500'
    }
  ];

  const process = [
    { 
      step: '01',
      title: 'Consultation',
      desc: 'Initial discussion and requirements gathering',
      icon: '/api/placeholder/64'
    },
    {
      step: '02',
      title: 'Planning',
      desc: 'Detailed project planning and resource allocation',
      icon: '/api/placeholder/64'
    },
    {
      step: '03',
      title: 'Creation',
      desc: 'Development and iterative refinement',
      icon: '/api/placeholder/64'
    },
    {
      step: '04',
      title: 'Delivery',
      desc: 'Final delivery and client support',
      icon: '/api/placeholder/64'
    }
  ];

  return (
    <div className="space-y-24 mt-24 bg-"> {/* Changed background to black */}
      {/* Animated Background */}
      <div className="fixed inset-0 -z-50 overflow-hidden">
        {/* Gradient Orbs */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-black-500/30 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-white-500/30 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-0 left-1/2 w-96 h-96 bg-black-500/30 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
        
        {/* Animated Grid */}
        <div className="absolute inset-0 bg-grid-black/[0.02] bg-[size:50px_50px] animate-grid-movement"></div>
      </div>

      {/* Services Hero */}
      <div className="text-center relative">
        <div className="absolute inset-0 -z-10">
          <div className="w-64 h-64 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-3xl mx-auto animate-pulse"></div>
        </div>
        <span className="inline-block px-4 py-2 bg-gray-900/5 backdrop-blur-sm rounded-full text-sm font-medium mb-6">
          Our Services
        </span>
        <h1 className="text-6xl font-bold text-gray-900 mb-6">
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-500 animate-gradient">
            Transform your Vision <br></br> Into Reality
          </span>
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Discover our comprehensive range of CGI and visualization services
        </p>
      </div>

      {/* Main Services */}
      <div className="grid md:grid-cols-3 gap-8">
        {services.map((service) => (
          <div key={service.name} 
               className="group relative bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-lg hover:shadow-2xl transition-all 
                        transform hover:-translate-y-2 duration-300 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r opacity-0 group-hover:opacity-5 transition-opacity duration-300"
                 style={{ backgroundImage: `linear-gradient(to right, #6366f1, #a855f7)` }}>
            </div>
            
            <div className="relative z-10">
              <div className="text-4xl mb-6">{service.icon}</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.name}</h3>
              <p className="text-gray-600 mb-8">{service.description}</p>
              
              <ul className="space-y-4 mb-8">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-gray-700">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mr-3" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button className="group w-full bg-gray-900 text-white py-4 px-6 
                             rounded-xl font-semibold hover:bg-gray-800 transition-all
                             flex items-center justify-center">
                Learn More
                <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Process Section */}
      <div className="relative">
        <div className="absolute inset-0 -z-10">
          <div className="w-full h-full" 
               style={{
                 backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(99, 102, 241, 0.05) 0%, transparent 25%)',
                 backgroundSize: '60px 60px'
               }}>
          </div>
        </div>
        
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="inline-block px-4 py-2 bg-gray-900/5 backdrop-blur-sm rounded-full text-sm font-medium mb-6">
              How We Work
            </span>
            <h2 className="text-4xl font-bold mb-4">Our Process</h2>
            <p className="text-xl text-gray-600">Simple, transparent, and efficient workflow</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {process.map((item, index) => (
              <div key={item.step} className="relative group">
                <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all h-full">
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-500">
                      {item.step}
                    </span>
                    <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center group-hover:bg-gray-200 transition-colors">
                      <img src={item.icon} alt={item.title} className="w-6 h-6" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600">{item.desc}</p>
                </div>
                
                {index < process.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section
      <div className="relative overflow-hidden">
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-3xl p-16 text-white text-center relative z-10">
          <div className="absolute inset-0 bg-gradient-to-r from-black-500/10 to-white-500/10 backdrop-blur-3xl animate-pulse"></div>
          <div className="relative z-10">
            <span className="inline-block px-4 py-2 bg-white/10 rounded-full text-sm font-medium mb-6">
              Get Started
            </span>
            <h2 className="text-4xl font-bold mb-6">Ready to Start Your Project?</h2>
            <p className="text-xl mb-8 text-gray-300 max-w-2xl mx-auto">
              Let's bring your vision to life with our expert team of designers and developers
            </p>
            <button className="group bg-white text-gray-900 px-8 py-4 rounded-full font-bold text-lg 
                           hover:bg-gray-100 transition-all flex items-center mx-auto">
              Get Started Now
              <ChevronRight className="ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </div> */}
      
    </div>
  );
};

