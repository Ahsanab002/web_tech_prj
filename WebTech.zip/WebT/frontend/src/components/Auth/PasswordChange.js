import React, { useState } from "react";
import logo from "../../../src/logo.png";
import { Link } from "react-router-dom";
import PageTitle from "../elements/PageTitle";
import { useNavigate } from "react-router-dom";
import useAuthService from "../services/ApiService";
import Swal from "sweetalert2";

export const ChangePassword = () => {
  const api = useAuthService();
  const [form, setForm] = useState({
    newPassword: "",
    confirmNewPassword: "",
  });

  const handleFormChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    if (e.target.name === 'newPassword') {
        validatePassword(e.target.value);
    }
    if (message && e.target.name === 'newPassword') {
        setMessage('');
    }
};
  const navigate = useNavigate();

  const [message, setMessage] = useState('');
  const [passManage, setPassManage] = useState({
    length: false,
    specialChar: false,
    capitalLetter: false,
    number: false,
  });

  const validatePassword = (newPassword) => {
    const minLength = newPassword.length >= 12;
    const hasSpecialChar = /[&@#[\]()*^$?;:'"<>,.!]/.test(newPassword);
    const hasCapitalLetter = /[A-Z]/.test(newPassword);
    const hasNumber = /[0-9]/.test(newPassword);

    setPassManage({
        length: minLength,
        specialChar: hasSpecialChar,
        capitalLetter: hasCapitalLetter,
        number: hasNumber,
    });
};

const handlePasswordChange = async (e) => {
  e.preventDefault();
  if (form.newPassword !== form.confirmNewPassword) {
      setMessage('Passwords do not match');
      return;
  }
  if (!passManage.length || !passManage.specialChar || !passManage.capitalLetter || !passManage.number) {
      setMessage('Password does not meet the requirements');
      return;
  }
  const res = await api.changePassword(form.newPassword).then(
      (response) => {
        console.log(res);
          Swal.mixin({
            customClass: {
              popup: "bg-lightmode dark:bg-darkmode dark:text-navy-100",
            },
          }).fire({
              title: 'Success',
              text: 'Password changed successfully! Please login to continue.',
              timer: 2000,
              showConfirmButton: false,
              icon: 'success',
          }); 
          navigate('/login');               
      },
      (error) => {
        console.log(error);
          Swal.mixin({
            customClass: {
              confirmButton: "btn bg-indigo-500 text-white",
              popup: "bg-lightmode dark:bg-darkmode dark:text-navy-100",
            },
          }).fire({
              title: 'Error',
              icon: 'error',
          });
      }
  );
};

  return (
    <>
      <PageTitle title="ImmersiX | Change Password" />
      <main className="grid w-full grow grid-cols-1 place-items-center h-100vh">
        <div className="w-full max-w-[26rem] p-4 sm:px-5">
          <div className="text-center">
            <Link to="/" exact="true">
              <img
                className="mx-auto h-16 w-16 transition-transform duration-500 ease-in-out hover:rotate-[360deg]"
                src={logo}
                alt="logo"
              />
            </Link>
            <div className="mt-4">
              <h2 className="text-2xl font-semibold text-slate-600 dark:text-navy-100">
                Change Password
              </h2>
              <p className="text-slate-400 dark:text-navy-300">
                Enter your new password.
              </p>
            </div>
          </div>
          <div className="card mt-5 rounded-lg p-5 lg:p-7">
            <form onSubmit={handlePasswordChange}>
              <label className="block">
                <span>Password:</span>
                <span className="relative mt-1.5 flex">
                  <input
                    className="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:z-10 hover:border-slate-400 focus:z-10 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                    placeholder="Enter Password"
                    type="password"
                    name="newPassword"
                    onChange={handleFormChange}
                  />
                  <span class="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 transition-colors duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg></span>
                </span>
              </label>
              <label className="block mt-4">
                <span>Confirm Password:</span>
                <span className="relative mt-1.5 flex">
                  <input
                    className="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:z-10 hover:border-slate-400 focus:z-10 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                    placeholder="Confirm Password"
                    type="password"
                    name="confirmNewPassword"
                    onChange={handleFormChange}
                  />
                  <span class="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 transition-colors duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg></span>
                </span>
              </label>
              { message && <p className="text-red-500 text-xs mt-2 text-red-600">{message}</p>}
          <p className='text-xs mt-2'>
            Password must contain:
            <ul className="list-none">
              <li className={`${passManage.length ? 'text-green-600' : 'text-red-600'}`}>
              <i className={`fa-solid fa-${passManage.length ? 'check' : 'times'}`}></i>
              &#160;&#160;At least 12 characters
              </li>
              <li className={`${passManage.specialChar ? 'text-green-600' : 'text-red-600'}`}>
                <i className={`fa-solid fa-${passManage.specialChar ? 'check' : 'times'}`}></i>
              &#160;&#160;At least one special character
              </li>
              <li className={`${passManage.capitalLetter ? 'text-green-600' : 'text-red-600'}`}>
              <i className={`fa-solid fa-${passManage.capitalLetter ? 'check' : 'times'}`}></i>
              &#160;&#160;At least one capital letter
              </li>
              <li className={`${passManage.number ? 'text-green-600' : 'text-red-600'}`}>
              <i className={`fa-solid fa-${passManage.number ? 'check' : 'times'}`}></i>
              &#160;&#160;At least one number
              </li>
            </ul>
            </p>
              <button
                type="submit"
                className="btn mt-5 w-full bg-indigo-500 font-medium text-white"
              >
                Change Password
              </button>
            </form>
          </div>
        </div>
      </main>
    </>
  );
};
