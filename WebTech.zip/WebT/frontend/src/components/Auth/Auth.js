import React, { useContext, useEffect, useState } from "react";
import { ArrowRight, Eye, EyeOff, Mail, Github, Lock, Loader2 } from 'lucide-react';
import Swal from "sweetalert2";
import logo from "../../../src/logo.png";
import google_logo from "../../static/images/logos/google.svg";
import {Link, Navigate} from "react-router-dom";
import PageTitle from "../elements/PageTitle";
import useAuthService from "../services/ApiService";
import { useNavigate } from "react-router-dom";
import { LoadingScreen } from "../elements/LoadingScreen";
import { RouterContext } from "../services/ApiService";


const darkmodecheck = () => {
  const darkmode = localStorage.getItem("_x_darkMode_on");
  if (darkmode === "true") {
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
  }
}


export const Login = () => {
  // const api = useAuthService();
  const {login, isLoading,isLoggedIn, adminUser, regularUser} = useContext(RouterContext);
  const navigate = useNavigate();
  const [form, setForm] = useState({
    username: '',
    password: '',
  });
  const handleFormChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    if (isLoggedIn) {
      if (adminUser) {
        navigate('/admin/dashboard');
      } else {
        navigate('/user/profile');
      }
    }
  }, [adminUser, regularUser]);

  const handleLogin = async  (e) => {
    e.preventDefault();
    const res = await login(form.username, form.password);
    console.log(res);
    if (res.response && res.response.status === 200) {
      setTimeout(() => {
      }, 2000);
  }
  };

  useEffect(() => {
    darkmodecheck();
  }, []);
  
  return (
    <>
    {isLoading && <LoadingScreen />}
    <PageTitle title="ImmersiX | Login" />
    <div className="grid w-full grow grid-cols-1 place-items-center h-100vh">
      <div className="w-full max-w-[32rem] p-4 sm:px-5">
        <div className="text-center">
        <Link to="/" exact="true">
              <img
                className="mx-auto h-16 w-16 transition-transform duration-500 ease-in-out hover:rotate-[360deg]"
                src={logo}
                alt="logo"
              />
            </Link>
          <div className="mt-4">
          <h1 className="text-5xl lg:text-7xl font-semibold text-black mb-6 tracking-tight">
              Welcome to
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
                CGI Solutions
              </span>
            </h1>
            {/* <h2 className="text-2xl font-semibold text-slate-600 dark:text-navy-100">
              Welcome Back
            </h2> */}
            <p className="text-3xl dark:text-navy-300">
              Please sign in to continue
            </p>
          </div>
        </div>
        <div className="card mt-5 rounded-lg p-5 lg:p-7">
          <label className="block">
            <span>Username:</span>
            <span className="relative mt-1.5 flex">
              <input
                className="form-input peer w-full rounded-lg border border-slate-600 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:z-10 hover:border-slate-400 focus:z-10 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                placeholder="Enter Username"
                name="username"
                onChange={handleFormChange}
                type="text"
              />
              <span className="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-600 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                <i className="fa-regular fa-user"></i>
              </span>
            </span>
          </label>
          <label className="mt-4 block">
            <span>Password:</span>
            <span className="relative mt-1.5 flex">
              <input
                className="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:z-10 hover:border-slate-400 focus:z-10 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                placeholder="Enter Password"
                name="password"
                onChange={handleFormChange}
                type="password"
              />
              <span className="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 transition-colors duration-200"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.5"
                    d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                  />
                </svg>
              </span>
            </span>
          </label>
          <div className="mt-4 flex items-center justify-between space-x-2">
            <label className="inline-flex items-center space-x-2">
              <input
                className="form-checkbox is-basic h-5 w-5 rounded border-slate-400/70 checked:border-primary checked:bg-primary hover:border-primary focus:border-primary dark:border-navy-400 dark:checked:border-accent dark:checked:bg-accent dark:hover:border-accent dark:focus:border-accent"
                type="checkbox"
              />
              <span className="line-clamp-1">Remember me</span>
            </label>
            <Link
              to="/reset-password"
              className="text-xs text-slate-400 transition-colors line-clamp-1 hover:text-slate-800 focus:text-slate-800 dark:text-navy-300 dark:hover:text-navy-100 dark:focus:text-navy-100"
            >
              Forgot Password?
            </Link>
          </div>
          <button
          type="submit"
          onClick={handleLogin}
          className="btn mt-5 w-full bg-primary font-medium text-white hover:bg-primary-focus focus:bg-primary-focus active:bg-primary-focus/90 dark:bg-accent dark:hover:bg-accent-focus dark:focus:bg-accent-focus dark:active:bg-accent/90">
            Sign In
          </button>
          <div className="mt-4 text-center text-xs+">
            <p className="line-clamp-1">
              <span>Don't have Account? </span>

              <Link
                className="text-primary transition-colors hover:text-primary-focus dark:text-accent-light dark:hover:text-accent"
                to="/signup"
              >
                Create account
              </Link>
            </p>
          </div>
          {/* <div className="my-7 flex items-center space-x-3">
            <div className="h-px flex-1 bg-slate-200 dark:bg-navy-500"></div>
            <p>OR</p>
            <div className="h-px flex-1 bg-slate-200 dark:bg-navy-500"></div>
          </div> */}
          {/* <div className="flex space-x-4">
            <button className="btn w-full space-x-3 border border-slate-300 font-medium text-slate-800 hover:bg-slate-150 focus:bg-slate-150 active:bg-slate-150/80 dark:border-navy-450 dark:text-navy-50 dark:hover:bg-navy-500 dark:focus:bg-navy-500 dark:active:bg-navy-500/90">
              <img className="h-5.5 w-5.5" src={google_logo} alt="logo" />
              <span>Google</span>
            </button>
          </div> */}
        </div>
        {/* <div className="mt-8 flex justify-center text-xs text-slate-400 dark:text-navy-300">
            <Link to="#">Privacy Notice</Link>
            <div className="mx-3 my-1 w-px bg-slate-200 dark:bg-navy-500"></div>
            <Link to="#">Term of service</Link>
          </div> */}
      </div>
    </div>
    </>
  );
};
export const SignUp = () => {
  const {register, isLoading, isLoggedIn, adminUser, regularUser} = useContext(RouterContext);
  const navigate = useNavigate();
    const [form, setForm] = useState({
        username: '',
        email: '',
        password: '',
        password2: '',
    });
    const handleFormChange = (e) => {
      setForm({ ...form, [e.target.name]: e.target.value });
      if (e.target.name === 'password') {
          validatePassword(e.target.value);
      }
      if (message && e.target.name === 'password') {
          setMessage('');
      }
  };

  useEffect(() => {
    if (isLoggedIn) {
      if (adminUser) {
        navigate('/admin/dashboard');
      } else {
        navigate('/user/profile');
      }
    }
  }, [adminUser, regularUser]);

    const [message, setMessage] = useState('');
    const [passManage, setPassManage] = useState({
      length: false,
      specialChar: false,
      capitalLetter: false,
      number: false,
    });

    const validatePassword = (password) => {
      const minLength = password.length >= 12;
      const hasSpecialChar = /[&@#[\]()*^$?;:'"<>,.!]/.test(password);
      const hasCapitalLetter = /[A-Z]/.test(password);
      const hasNumber = /[0-9]/.test(password);
  
      setPassManage({
          length: minLength,
          specialChar: hasSpecialChar,
          capitalLetter: hasCapitalLetter,
          number: hasNumber,
      });
  };

    const handleRegister = async (e) => {
        e.preventDefault();
        if (form.password !== form.password2) {
            setMessage('Passwords do not match');
            return;
        }
        if (!passManage.length || !passManage.specialChar || !passManage.capitalLetter || !passManage.number) {
            setMessage('Password does not meet the requirements');
            return;
        }
        const res = await register(form.username, form.email, form.password);
        console.log('res', res);
        if (res && res.status === 201) {
            setTimeout(() => {
                navigate('/login');
            }, 2000);
        }
    };

    useEffect(() => {
      darkmodecheck();
    }, []);
  return (
    <>
    {isLoading && <LoadingScreen />}
    <PageTitle title="ImmersiX | SignUP" />
    <form className="grid w-full grow grid-cols-1 place-items-center h-100vh" autocomplete="off">
      <div className="w-full max-w-[32rem] p-4 sm:px-5">
        <div className="text-center">
        <Link to="/" exact="true">
              <img
                className="mx-auto h-16 w-16 transition-transform duration-500 ease-in-out hover:rotate-[360deg]"
                src={logo}
                alt="logo"
              />
            </Link>
            <div className="max-w-md">
            <h1 className="text-2xl lg:text-3xl font-bold text-black mb-6">
              Create an Account
              <span className="block text-gray-300">Join CGI Solutions</span>
            </h1>
            <p className="text-xl text-gray-400 mb-8">
              Sign up and start transforming your vision with cutting-edge visualization technology.
            </p>
          </div>
        </div>
        <div className="card mt-5 rounded-lg p-5 lg:p-7">
        <label className="relative flex">
            <input
              className="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:z-10 hover:border-slate-400 focus:z-10 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
              placeholder="Email"
              onChange={handleFormChange}
              name="email"
              type="email"
            />
            <span className="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
            <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 transition-colors duration-200"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                  d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                />
              </svg>
            </span>
          </label>
          <label className="relative mt-4 flex">
            <input
              className="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:z-10 hover:border-slate-400 focus:z-10 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
              placeholder="Username"
              name="username"
              onChange={handleFormChange}
              autoComplete="off"
              type="text"
            />
            <span className="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
              <i className="fa-regular fa-user"></i>
            </span>
          </label>
          <label className="relative mt-4 flex">
            <input
              className="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:z-10 hover:border-slate-400 focus:z-10 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
              placeholder="Password"
              name="password"
              autoComplete="off"
              onChange={handleFormChange}
              type="password"
            />
            <span className="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 transition-colors duration-200"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
            </span>
          </label>
          <label className="relative mt-4 flex">
            <input
              className="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:z-10 hover:border-slate-400 focus:z-10 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
              placeholder="Repeat Password"
              name="password2"
              onChange={handleFormChange}
              type="password"
            />
            <span className="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 transition-colors duration-200"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
            </span>
          </label>
          { message && <p className="text-red-500 text-xs mt-2 text-red-600">{message}</p>}
          <p className='text-xs mt-4'>
            Password must contain:
            <ul className="list-none">
              <li className={`${passManage.length ? 'text-green-600' : 'text-red-600'}`}>
              <i className={`fa-solid fa-${passManage.length ? 'check' : 'times'}`}></i>
              &#160;&#160;At least 12 characters
              </li>
              <li className={`${passManage.specialChar ? 'text-green-600' : 'text-red-600'}`}>
                <i className={`fa-solid fa-${passManage.specialChar ? 'check' : 'times'}`}></i>
              &#160;&#160;At least one special character
              </li>
              <li className={`${passManage.capitalLetter ? 'text-green-600' : 'text-red-600'}`}>
              <i className={`fa-solid fa-${passManage.capitalLetter ? 'check' : 'times'}`}></i>
              &#160;&#160;At least one capital letter
              </li>
              <li className={`${passManage.number ? 'text-green-600' : 'text-red-600'}`}>
              <i className={`fa-solid fa-${passManage.number ? 'check' : 'times'}`}></i>
              &#160;&#160;At least one number
              </li>
            </ul>
            </p>
          {/* <div className="mt-4 flex items-center space-x-2">
            <input
              className="form-checkbox is-basic h-5 w-5 rounded border-slate-400/70 checked:border-primary checked:bg-primary hover:border-primary focus:border-primary dark:border-navy-400 dark:checked:border-accent dark:checked:bg-accent dark:hover:border-accent dark:focus:border-accent"
              type="checkbox"
            />
            <p className="line-clamp-1">
              I agree with
              <Link
                to="#"
                className="text-slate-400 hover:underline dark:text-navy-300"
              >
                privacy policy
              </Link>
            </p>
          </div> */}
          <button
          type="submit"
          onClick={handleRegister}
          className="btn mt-5 w-full bg-primary font-medium text-white hover:bg-primary-focus focus:bg-primary-focus active:bg-primary-focus/90 dark:bg-accent dark:hover:bg-accent-focus dark:focus:bg-accent-focus dark:active:bg-accent/90">
            Sign Up
          </button>
          <div className="mt-4 text-center text-xs+">
            <p className="line-clamp-1">
              <span>Already have an account? </span>
              <Link
                className="text-primary transition-colors hover:text-primary-focus dark:text-accent-light dark:hover:text-accent"
                to="/login"
              >
                Sign In
              </Link>
            </p>
          </div>
          <div className="my-7 flex items-center space-x-3">
            <div className="h-px flex-1 bg-slate-200 dark:bg-navy-500"></div>
            <p className="text-tiny+ uppercase">or sign up with email</p>
            <div className="h-px flex-1 bg-slate-200 dark:bg-navy-500"></div>
          </div>
          <div className="flex space-x-4">
            <button className="btn w-full space-x-3 border border-slate-300 font-medium text-slate-800 hover:bg-slate-150 focus:bg-slate-150 active:bg-slate-150/80 dark:border-navy-450 dark:text-navy-50 dark:hover:bg-navy-500 dark:focus:bg-navy-500 dark:active:bg-navy-500/90">
              <img className="h-5.5 w-5.5" src={google_logo} alt="logo" />
              <span>Google</span>
            </button>
          </div>
        </div>
      </div>
    </form>
    </>
  );
};
