import React, { useContext, useEffect } from "react";
import { Route, Navigate } from "react-router-dom";
import { RouterContext } from "./ApiService";

export const ProtectedRoute = ({children}) => {
    const {isLoggedIn} = useContext(RouterContext);
    return isLoggedIn ? children : <Navigate to="/login" />;
};

export const UserRoute = ({children}) => {
    const {isLoggedIn, regularUser} = useContext(RouterContext);
    return (isLoggedIn && regularUser) ? children : <Navigate to="/login" />;
};

export const AdminRoute = ({children}) => {
    const {isLoggedIn, adminUser} = useContext(RouterContext);
    return (isLoggedIn && adminUser) ? children : <Navigate to="/login" />;
};
