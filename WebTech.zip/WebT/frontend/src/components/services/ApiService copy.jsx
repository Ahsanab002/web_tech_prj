// src/services/authService.js
// /* global chrome */

import axios from 'axios';
import { useState, useCallback, useEffect } from 'react';
import Swal from 'sweetalert2';
const API_URL = 'http://127.0.0.1:8000/api/';


const useAuthService = () => {
    const [isLoading, setIsLoading] = useState(false);

    const [isLoggedIn, setIsLoggedIn] = useState(false);

    const [adminUser, setAdminUser] = useState(false);
    const [regularUser, setRegularUser] = useState(false);
  
    const register = async (username, email, password) => {
        setIsLoading(true);
        try {
            const res = await axios.post(API_URL + 'register/', { username, email, password });
            Swal.fire({
                title: 'Success',
                text: 'Account created successfully',
                timer: 2000,
                showConfirmButton: false,
                icon: 'success',
                customClass: {
                    popup: "bg-lightmode dark:bg-darkmode dark:text-navy-100",
                },
            });
            return res;
        } catch (error) {
            console.log(error);
            const errorEmail = error.response?.data?.email?.[0] || '';
            const errorUsername = error.response?.data?.username?.[0] || '';
            const errorPassword = error.response?.data?.password?.[0] || '';
            Swal.fire({
                title: 'Error',
                text: `${errorEmail} ${errorUsername} ${errorPassword}`,
                icon: 'error',
                customClass: {
                    confirmButton: "btn bg-indigo-500 text-white",
                    popup: "bg-lightmode dark:bg-darkmode dark:text-navy-100",
                },
            });
            return error.response;
        } finally {
            setIsLoading(false);
        }
    };

    const login = useCallback(async (username, password) => {
        setIsLoading(true);
        try {
            const response = await axios.post(API_URL + 'login/', { username, password });
            if (response.data.access) {
                localStorage.setItem('user', JSON.stringify(response.data));
            }
            // Store the token in Chrome's local storage
            // if (chrome && chrome.storage) {
            //     // chrome.storage.local.set({ userToken: JSON.stringify(response.data) }, () => {
            //     //     console.log('User token stored in Chrome storage.');
            //     // });
            //     chrome.runtime.sendMessage({ type: 'USER_LOGGED_IN', token: response.data });
            // }
            setIsLoggedIn(true);
            Swal.fire({
                title: 'Success',
                text: 'Login successful',
                timer: 2000,
                showConfirmButton: false,
                icon: 'success',
                customClass: {
                    popup: "bg-lightmode dark:bg-darkmode dark:text-navy-100",
                },
            });
            const user = await getUser();
            console.log(user, 'user');
            if (user.is_superuser) {
                setAdminUser(true);
            } else {
                setRegularUser(true);
            }
            return {
                response: response,
                user: user,
            }
        } catch (error) {
            console.error("Login error: ", error);
            const errorUsername = error.response?.data?.username?.[0] || '';
            const errorPassword = error.response?.data?.password?.[0] || '';
            const nonFieldError = error.response?.data?.non_field_errors?.[0] || '';
            Swal.fire({
                title: 'Error',
                text: `${errorUsername} ${errorPassword} ${nonFieldError}`,
                icon: 'error',
                customClass: {
                    confirmButton: "btn bg-indigo-500 text-white",
                    popup: "bg-lightmode dark:bg-darkmode dark:text-navy-100",
                },
            });
            return error.response;
        } finally {
            setIsLoading(false);
        }
    }, []);

    const logout = useCallback(() => {
        localStorage.removeItem('user');
        // if (chrome && chrome.storage) {
        //     chrome.runtime.sendMessage({ type: 'USER_LOGGED_OUT' });
        // }
        setIsLoggedIn(false);
    }, []);

    const refreshToken = useCallback(async () => {
        setIsLoading(true);
        const token = JSON.parse(localStorage.getItem('user'));
        if (token && token.refresh) {
            try {
                const response = await axios.post(API_URL + 'token/refresh/', { refresh: token.refresh });
                localStorage.setItem('user', JSON.stringify(response.data));
                return response.data.access;
            } catch (error) {
                console.error('Error refreshing token:', error);
            } finally {
                setIsLoading(false);
            }
        }
        setIsLoading(false);
        return null;
    }, []);

    const changePassword = useCallback(async (newPassword) => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;

        if (!accessToken) {
            setIsLoading(false);
            return Promise.reject('No access token available');
        }

        try {
            const response = await axios.put(API_URL + 'change-password/', { new_password: newPassword }, {
                headers: {
                    Authorization: 'Bearer ' + accessToken,
                }
            });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return changePassword(newPassword);
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    }, [refreshToken]);

    const getAuthHeaders = () => {
        const token = JSON.parse(localStorage.getItem('user'));
        return token && token.access ? { Authorization: 'Bearer ' + token.access } : {};
    };

    // User API Calls
    const getUser = async () => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.get(API_URL + 'user/', { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            console.error('Error getting user:', error);
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return getUser();
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    // Profile
    const getProfile = async () => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.get(API_URL + 'profiles/', { headers: getAuthHeaders() });
            console.log(response.data, '1');
            return response.data;
        } catch (error) {
            console.error('Error getting profile:', error);
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    console.log('2');
                    return getProfile();
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const updateProfile = async (profileData) => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.put(API_URL + 'profiles/' + profileData.id + '/', profileData, { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return updateProfile(profileData);
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    // Measurements API Calls
    const getMeasurements = async () => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.get(API_URL + 'measurements/', { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return getMeasurements();
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const updateMeasurements = async (measurementsData) => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.put(API_URL + 'measurements/', measurementsData, { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return updateMeasurements(measurementsData);
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    // Notifications API Calls
    const getNotifications = async () => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.get(API_URL + 'notifications/', { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return getNotifications();
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const createNotification = async (notificationData) => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.post(API_URL + 'notifications/', notificationData, { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return createNotification(notificationData);
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const deleteNotification = async (id) => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.delete(API_URL + 'notifications/' + id + '/', { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return deleteNotification(id);
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    // Favourites API Calls
    const getFavourites = async () => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.get(API_URL + 'favourites/', { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return getFavourites();
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const createFavourite = async (favouriteData) => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.post(API_URL + 'favourites/', favouriteData, { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return createFavourite(favouriteData);
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const deleteFavourite = async (id) => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.delete(API_URL + 'favourites/' + id + '/', { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return deleteFavourite(id);
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    // StockWatch API Calls
    const getStockWatch = async () => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.get(API_URL + 'stockwatch/', { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return getStockWatch();
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const createStockWatch = async (stockWatchData) => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.post(API_URL + 'stockwatch/', stockWatchData, { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return createStockWatch(stockWatchData);
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const deleteStockWatch = async (id) => {
        setIsLoading(true);
        let token = JSON.parse(localStorage.getItem('user'));
        let accessToken = token ? token.access : null;
        try {
            const response = await axios.delete(API_URL + 'stockwatch/' + id + '/', { headers: getAuthHeaders() });
            return response.data;
        } catch (error) {
            if (error.response && error.response.data.code === 'token_not_valid') {
                accessToken = await refreshToken();
                if (accessToken) {
                    return deleteStockWatch(id);
                } else {
                    return Promise.reject('Unable to refresh token');
                }
            } else {
                return Promise.reject(error);
            }
        } finally {
            setIsLoading(false);
        }
    };

    return {
        isLoading,
        register,
        login,
        logout,
        isLoggedIn,
        changePassword,
        getProfile,
        updateProfile,
        getMeasurements,
        updateMeasurements,
        getNotifications,
        createNotification,
        deleteNotification,
        getFavourites,
        createFavourite,
        deleteFavourite,
        getStockWatch,
        createStockWatch,
        deleteStockWatch,
        adminUser,
        regularUser,
    };
};

export default useAuthService;
