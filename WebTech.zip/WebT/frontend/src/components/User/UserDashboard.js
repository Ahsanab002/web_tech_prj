import React, { useEffect, useContext } from 'react';
import { Header } from '../elements/Header';
import { SidebarUser } from './Sidebar';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { UserContext } from './UserContext';
import { LoadingScreen } from '../elements/LoadingScreen';
// import DashboardOverview from './DashboardOverview';



export const UserDashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { isLoading, notifications, markNotificationRead } = useContext(UserContext);


  useEffect(() => {
    if (location.pathname === '/user') {
      navigate('/user/profile');
    }
  }, [location, navigate]);

  return (
    
      <>
      {isLoading && <LoadingScreen /> }
      <Header notifications={notifications} markNotificationRead={markNotificationRead} />
      <SidebarUser />
      {/* <DashboardOverview /> */}
      <main className='main-content pb-8'>
        <Outlet />
      </main>
      </>
  );
};
