import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/admin/components/ui/Card';
import { Bell, Briefcase, Clock, CheckCircle, ChevronRight, ArrowUpRight, ArrowDownRight } from 'lucide-react';
// import { useNavigate } from "react-router-dom";

const DashboardOverview = ({ user = { name: 'User' } }) => {
  const stats = [
    {
      title: "Total Projects",
      value: "12",
      icon: <Briefcase className="h-6 w-6 text-blue-500" />,
      trend: "+2 this month",
      trendUp: true
    },
    {
      title: "Active Services",
      value: "4",
      icon: <CheckCircle className="h-6 w-6 text-green-500" />,
      trend: "All running smoothly",
      trendUp: true
    },
    {
      title: "Pending Tasks",
      value: "8",
      icon: <Clock className="h-6 w-6 text-orange-500" />,
      trend: "3 due today",
      trendUp: false
    }
  ];

  const recentActivities = [
    { id: 1, title: "3D Model Updated", project: "City Plaza", time: "2 hours ago", type: "update" },
    { id: 2, title: "GIS Map Exported", project: "Park Layout", time: "5 hours ago", type: "export" },
    { id: 3, title: "New Comment", project: "Tower Design", time: "1 day ago", type: "comment" }
  ];

  return (
    <div className="p-6 space-y-8">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 rounded-xl p-8 text-white shadow-lg">
        <div className="relative z-10">
          <h1 className="text-4xl font-bold mb-2">Welcome back, {user?.name || 'User'} 👋</h1>
          <p className="text-blue-100 text-lg">Here's what's happening with your projects today</p>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500 rounded-full filter blur-3xl opacity-50 transform translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-400 rounded-full filter blur-3xl opacity-30 transform -translate-x-1/2 translate-y-1/2"></div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="bg-gray-50 p-3 rounded-lg">{stat.icon}</div>
                {stat.trendUp ? (
                  <div className="flex items-center text-green-500 text-sm">
                    <ArrowUpRight className="h-4 w-4 mr-1" />
                    {stat.trend}
                  </div>
                ) : (
                  <div className="flex items-center text-red-500 text-sm">
                    <ArrowDownRight className="h-4 w-4 mr-1" />
                    {stat.trend}
                  </div>
                )}
              </div>
              <div className="mt-4">
                <p className="text-4xl font-bold mb-1">{stat.value}</p>
                <p className="text-gray-600">{stat.title}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Activities */}
      <Card className="overflow-hidden">
        <CardHeader className="border-b bg-gray-50">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-blue-500" />
              Recent Activities
            </div>
            <button className="text-sm text-blue-500 hover:text-blue-600 flex items-center">
              View All <ChevronRight className="h-4 w-4 ml-1" />
            </button>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y">
            {recentActivities.map((activity) => (
              <div 
                key={activity.id} 
                className="p-4 hover:bg-gray-50 transition-colors flex items-center justify-between group"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    activity.type === 'update' ? 'bg-blue-100 text-blue-500' :
                    activity.type === 'export' ? 'bg-green-100 text-green-500' :
                    'bg-purple-100 text-purple-500'
                  }`}>
                    {activity.type === 'update' ? '🔄' : activity.type === 'export' ? '📤' : '💬'}
                  </div>
                  <div>
                    <p className="font-medium">{activity.title}</p>
                    <p className="text-sm text-gray-500">Project: {activity.project}</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500 group-hover:text-blue-500 transition-colors">
                  {activity.time}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader className="border-b bg-gray-50">
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-blue-500" />
            Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="space-y-4">
            <div className="group cursor-pointer p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200 hover:shadow-md transition-all duration-300">
              <div className="flex items-center gap-4">
                <div className="bg-blue-500 text-white p-3 rounded-lg">
                  <Bell className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium text-blue-900">Service Update Available</p>
                  <p className="text-sm text-blue-700">New features available in the 3D Model Viewer</p>
                </div>
              </div>
            </div>
            <div className="group cursor-pointer p-4 bg-gradient-to-r from-orange-50 to-orange-100 rounded-xl border border-orange-200 hover:shadow-md transition-all duration-300">
              <div className="flex items-center gap-4">
                <div className="bg-orange-500 text-white p-3 rounded-lg">
                  <Clock className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium text-orange-900">Project Deadline Approaching</p>
                  <p className="text-sm text-orange-700">Tower Design project due in 3 days</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardOverview;