import useAuthService from "../services/ApiService";
import { createContext, useContext, useEffect, useState } from "react";
// import { getProfiles, createProfile, updateProfile, deleteProfile } from '../../services/api';

export const UserContext = createContext();

export const UserProvider = ({ children }) => {
    const api = useAuthService();
    const [isLoading, setIsLoading] = useState(false);
    const [userData, setUserData] = useState([]);
    const [profileData, setProfileData] = useState({});
    const [measurementData, setMeasurementData] = useState({});
    const [notifications, setNotifications] = useState([]);
    const [favourites, setFavourites] = useState([]);
    const [stockwatch, setStockwatch] = useState([]);

    const fetchUserData = async () => {
        const response = await api.getUser();
        setUserData(response);
    }

    const fetchProfileData = async () => {
        const response = await api.getProfile();
        setProfileData(response['0']);
    }
    const fetchMeasurementData = async () => {
        const response = await api.getMeasurements();
        setMeasurementData(response['0']);
    }
    const fetchNotifications = async () => {
        const response = await api.getNotifications();
        setNotifications(response);
    }
    const fetchFavourites = async () => {
        const response = await api.getFavourites();
        setFavourites(response);
    }
    const fetchStockwatch = async () => {
        const response = await api.getStockWatch();
        setStockwatch(response);
    }
    const updateProfileData = async (data) => {
        setIsLoading(true);
        const response = await api.updateProfile(data);
        setProfileData(response);
        setIsLoading(false);
    }

    const updateMeasurementData = async (data) => {
        setIsLoading(true);
        const response = await api.updateMeasurements(data);
        setMeasurementData(response);
        setIsLoading(false);
    }
    const markNotificationRead = async () => {
        // setIsLoading(true);
        const response = await api.markedNotificationAsRead();
        // update notification data and set the read status to true by looping through the notifications current
        const updatedNotifications = notifications.map((notification) => {
            if (!notification.read) {
                return { ...notification, read: true };
            }
            return notification;
        });
        setNotifications(updatedNotifications);
        // setIsLoading(false);
    }
    const deleteFavourite = async (id) => {
        setIsLoading(true);
        await api.deleteFavourite(id);
        const response = await api.getFavourites();
        setFavourites(response);
        setIsLoading(false);
    }

    const deleteStockWatch = async (id) => {
        setIsLoading(true);
        await api.deleteStockWatch(id);
        const response = await api.getStockWatch();
        setStockwatch(response);
        setIsLoading(false);
    }

    useEffect(() => {
        setIsLoading(true);
        fetchUserData();
        fetchProfileData();
        fetchMeasurementData();
        fetchNotifications();
        fetchFavourites();
        fetchStockwatch();
        setIsLoading(false);
    }, []);

const contextData = {
        isLoading,
        userData,
        setUserData,
        profileData,
        setProfileData,
        updateProfileData,
        measurementData,
        setMeasurementData,
        updateMeasurementData,
        notifications,
        setNotifications,
        markNotificationRead,
        favourites,
        setFavourites,
        deleteFavourite,
        stockwatch,
        setStockwatch,
        deleteStockWatch,
    };
    return (
        <UserContext.Provider value={contextData}>
            {children}
        </UserContext.Provider>
    );
}
