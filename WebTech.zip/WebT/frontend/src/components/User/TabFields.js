export const TabFieldsContent = {
    'tab1' : [
        {
            'title': 'Neck',
            'name': 'neck',
            'type': 'number',
            'placeholder': 'Neck',
        },
        {
            'title': 'Shoulder',
            'name': 'shoulder',
            'type': 'number',
            'placeholder': 'Shoulder',
        },
        {
            'title': 'Chest',
            'name': 'chest',
            'type': 'number',
            'placeholder': 'Chest',
        },
        {
            'title': 'Bust',
            'name': 'bust',
            'type': 'number',
            'placeholder': 'Bust',
        },
        {
            'title': 'Waist',
            'name': 'waist',
            'type': 'number',
            'placeholder': 'Waist',
        },
        {
            'title': 'Sleeve',
            'name': 'sleeve',
            'type': 'number',
            'placeholder': 'Sleeve',
        },
        {
            'title': 'Wrist',
            'name': 'wrist',
            'type': 'number',
            'placeholder': 'Wrist',
        },
    ],
    'tab2' : [
        {
            'title': 'Hip',
            'name': 'hip',
            'type': 'number',
            'placeholder': 'Hip',
        },
        {
            'title': 'Inseam',
            'name': 'inseam',
            'type': 'number',
            'placeholder': 'Inseam',
        },
        {
            'title': 'Thigh',
            'name': 'thigh',
            'type': 'number',
            'placeholder': 'Thigh',
        },
        {
            'title': 'Calf',
            'name': 'calf',
            'type': 'number',
            'placeholder': 'Calf',
        },
        {
            'title': 'Ankle',
            'name': 'ankle',
            'type': 'number',
            'placeholder': 'Ankle',
        },
    ],
    'tab3' : [
        {
            'title': 'Foot Length',
            'name': 'foot_len',
            'type': 'number',
            'placeholder': 'Foot Length',
        },
        {
            'title': 'Foot Width',
            'name': 'foot_width',
            'type': 'number',
            'placeholder': 'Foot Width',
        },
        {
            'title': 'Foot Shape',
            'name': 'foot_shape',
            'type': 'select',
            'options': [
                {
                    'value': 'roman',
                    'label': 'Roman',
                },
                {
                    'value': 'square',
                    'label': 'Square',
                },
                {
                    'value': 'greek',
                    'label': 'Greek',
                },
                {
                    'value': 'egyptian',
                    'label': 'Egyptian',
                },
            ],
        },
        {
            'title': 'Foot Type',
            'name': 'foot_type',
            'type': 'select',
            'options': [
                {
                    'value': 'normal',
                    'label': 'Normal',
                },
                {
                    'value': 'flat',
                    'label': 'Flat',
                },
                {
                    'value': 'high_arch',
                    'label': 'High Arch',
                },
            ],
        },
    ],
    'tab4' : [
        {
            'title': 'Height',
            'name': 'height',
            'type': 'number',
            'placeholder': 'Height',
        },
        {
            'title': 'Weight',
            'name': 'weight',
            'type': 'number',
            'placeholder': 'Weight',
        },
        {
            'title': 'Body Type',
            'name': 'body_type',
            'type': 'select',
            'options': [
                {
                    'value': 'ectomorph',
                    'label': 'Ectomorph',
                },
                {
                    'value': 'mesomorph',
                    'label': 'Mesomorph',
                },
                {
                    'value': 'endomorph',
                    'label': 'Endomorph',
                },
            ],
        },
        {
            'title': 'Fit Preference',
            'name': 'fit_preference',
            'type': 'select',
            'options': [
                {
                    'value': 'fit',
                    'label': 'Fit',
                },
                {
                    'value': 'normal',
                    'label': 'Normal',
                },
                {
                    'value': 'loose',
                    'label': 'Loose',
                },
            ],
        },
    ],
};
