import React, { useState, useEffect, useContext } from "react";
import avatar from "./avatar.png";
import AvatarModal from "../elements/AvatarModal";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import useAuthService from "../services/ApiService";
import { UserContext } from "./UserContext";
import { LoadingScreen } from "../elements/LoadingScreen";
import { avatars } from "../../static/images/avater/avatar";

export const ProfileUser = () => {
  const { profileData, userData, setProfileData, setUserData, updateProfileData } = useContext(UserContext);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [profileAvatar, setProfileAvatar] = useState(avatars['B']);
  const api = useAuthService();
  
  const [profile, setProfile] = useState({
    id: '',
    user: '',
    first_name: '',
    last_name: '',
    profile_pic: '',
    gender: '',
    plan_type: ''
  });

  const [user, setUser] = useState({
    id: '',
    username: '',
    email: ''
  });

  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleAvatarClick = () => {
    setIsModalOpen(true);
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
  };

  const handleSaveAvatar = (newAvatar) => {
    setProfileAvatar(newAvatar.src);
    setProfile((prevProfile) => ({
      ...prevProfile,
      'profile_pic': newAvatar.alt,
    }));
  };

  const [editMode, setEditMode] = useState(false);
  
  const handleeditMode = (e) => {
    e.preventDefault();
    setEditMode(!editMode);
  };

  useEffect(() => {
    const { id, user, first_name, last_name, profile_pic, gender, plan_type } = profileData || {};
    setProfile({ id, user, first_name, last_name, profile_pic, gender, plan_type });

    if (profile_pic && gender && avatars[gender]) {
      const selectedAvatar = avatars[gender][profile_pic];
      if (selectedAvatar) {
        setProfileAvatar(selectedAvatar.src);
      }
    }
  }, [profileData]);

  useEffect(() => {
    setUser(userData);
  }, [userData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    updateProfileData(profile);
    setEditMode(false);
  };

  const handleCancel = (e) => {
    e.preventDefault();
    setProfile(profileData);
    setEditMode(false);
  };

  return (
    <>
      {api.isLoading && <LoadingScreen />}
      <div className="container-fluid px-4">
        <div className="row">
          <div className="col-md-8 offset-md-2 col-lg-6 offset-lg-3 mt-5">
            <div className="card shadow-sm">
              <div className="card-header">
                <div className="relative z-10 flex w-full shrink-0 items-center justify-between border-b border-slate-150 bg-white p-6 shadow-sm transition-[padding,width] duration-[.25s] dark:border-navy-700 dark:bg-navy-800 rounded-t-2xl">
                  <div className="flex items-center space-x-4 font-inter">
                    <div className="avatar h-32 w-32 realtive avatar-container">
                      <img
                        className="rounded-full"
                        src={profileAvatar}
                        alt="avatar"
                        onClick={editMode ? handleAvatarClick : null}
                        style={{ cursor: editMode ? "pointer" : "default" }}
                      />
                      <div
                        style={{ display: editMode ? "flex" : "none" }}
                        className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 opacity-0 hover:opacity-100 rounded-full transition-opacity duration-300 cursor-pointer overlay"
                        onClick={handleAvatarClick}
                      >
                        <i className="fa fa-edit text-white text-2xl"></i>
                      </div>
                      {profile.gender &&
                        <AvatarModal
                          isOpen={isModalOpen}
                          onClose={handleModalClose}
                          onSave={handleSaveAvatar}
                          gender={profile.gender}
                        />
                      }
                    </div>
                    <div>
                      <h1 className="font-medium text-slate-700 line-clamp-1 dark:text-navy-100 text-4xl relative">
                        {profile.first_name} {profile.last_name}
                        <span className={"badge text-xs align-super ml-2 " + (profile.plan_type === 'premium' ? 'bg-secondary/10 text-secondary dark:bg-secondary-light/15 dark:text-secondary-light' : 'bg-info/10 text-info dark:bg-info/15')}>
                          {profile?.plan_type ? profile.plan_type.charAt(0).toUpperCase() + profile.plan_type.slice(1) : ''}
                        </span>
                      </h1>
                      <h1 className="mt-0.5 text-xl">{user.username}</h1>
                    </div>
                  </div>
                  <div style={{ display: editMode ? 'none' : 'block' }} className="self-baseline">
                    <button
                      onClick={handleeditMode}
                      className="btn space-x-2 bg-primary font-medium text-white hover:bg-primary-focus focus:bg-primary-focus active:bg-primary-focus/90 dark:bg-accent dark:hover:bg-accent-focus dark:focus:bg-accent-focus dark:active:bg-accent/90">
                      <i className="fa fa-edit text-white"></i>
                      <span>Edit</span>
                    </button>
                  </div>
                </div>
              </div>
              <div className="card-body">
                <form className="p-6">
                  <div className="grid grid-cols-2 gap-6">
                    <label className="block">
                      <span>First Name</span>
                      <input
                        disabled={!editMode}
                        className="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2"
                        name="first_name"
                        value={profile.first_name}
                        onChange={handleChange}
                        type="text"
                      />
                    </label>

                    <label className="block">
                      <span>Last Name</span>
                      <input
                        disabled={!editMode}
                        className="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2"
                        name="last_name"
                        value={profile.last_name}
                        onChange={handleChange}
                        type="text"
                      />
                    </label>

                    <label className="block">
                      <span>Gender</span>
                      <select
                        disabled={!editMode}
                        className="form-select peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2"
                        name="gender"
                        value={profile.gender}
                        onChange={handleChange}
                      >
                        <option disabled value="">Select...</option>
                        <option value="M">Male</option>
                        <option value="F">Female</option>
                      </select>
                    </label>

                    <label className="block">
                      <span>Plan Type</span>
                      <select
                        disabled={!editMode}
                        className="form-select peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2"
                        name="plan_type"
                        value={profile.plan_type}
                        onChange={handleChange}
                      >
                        <option disabled value="">Select...</option>
                        <option value="basic">Basic</option>
                        <option value="premium">Premium</option>
                      </select>
                    </label>
                  </div>

                  <div className="flex justify-end space-x-2 mt-4">
                    {editMode && (
                      <div className="flex space-x-2">
                        <button onClick={handleCancel} className="btn bg-slate-150">
                          Cancel
                        </button>
                        <button onClick={handleSubmit} className="btn bg-primary text-white">
                          Save
                        </button>
                      </div>
                    )}
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProfileUser;