import React, { useState } from 'react';
// import vectorImage from './Vector/11 1.png'; // Adjust the path as needed
// import icon1 from './Vector/ai web app project 1.png'; // Adjust the path as needed
// import icon2 from './Vector/ai web app project 2.png'; // Adjust the path as needed
// import icon3 from './Vector/image 1.png'; // Adjust the path as needed
// import icon4 from './Vector/image 3.png'; // Adjust the path as needed

// import logo from "./Vector/B.png";
// import avatar from "./Vector/3d_avatar_21.png";
//import { NavLink, Link } from "react-router-dom";



const icon1 = ""
const icon2= ""
const icon3= ""
const icon4= ""
const vectorImage= ""
const userData = {
  neck: { label: 'Neck' },
  shoulders: { label: 'Shoulders' },
  chest: { label: 'Chest' },
  stomach: { label: 'Stomach' },
  armsLength: { label: 'Arms Length' },
};

const getErrorMessage = (value, validate) => {
  if (validate && (value < 1 || value > 100)) {
    return 'Value must be between 1 and 100';
  }
  return '';
};

export const UserComponent = () => {
  const [measurements, setMeasurements] = useState({
    neck: { value: '', blurred: false, errorMessage: '', validate: false },
    shoulders: { value: '', blurred: false, errorMessage: '', validate: false },
    chest: { value: '', blurred: false, errorMessage: '', validate: false },
    stomach: { value: '', blurred: false, errorMessage: '', validate: false },
    armsLength: { value: '', blurred: false, errorMessage: '', validate: false },
  });

  const handleBlur = (key) => {
    setMeasurements((prevState) => ({
      ...prevState,
      [key]: {
        ...prevState[key],
        blurred: true,
        validate: true,
        errorMessage: getErrorMessage(prevState[key].value, true),
      }
    }));
  };

  const handleChange = (key, e) => {
    const { value } = e.target;
    setMeasurements((prevState) => ({
      ...prevState,
      [key]: {
        ...prevState[key],
        value: value,
        errorMessage: getErrorMessage(value, prevState[key].validate),
      }
    }));
  };

  return (
    <div className="my-4 mx-auto max-w-full flex justify-center items-center">
      <div className="flex-grow max-w-md mr-8">
        <div className="flex justify-start mb-12 space-x-4">
          <button className="w-8 h-12 bg-gray-500 rounded-lg flex items-center justify-center">
            <img src={icon1} alt="Icon 1" className="w-6 h-6" />
          </button>
          <button className="w-8 h-12 bg-gray-500 rounded-lg flex items-center justify-center">
            <img src={icon2} alt="Icon 2" className="w-6 h-6" />
          </button>
          <button className="w-8 h-12 bg-gray-500 rounded-lg flex items-center justify-center">
            <img src={icon3} alt="Icon 3" className="w-6 h-6" />
          </button>
          <button className="w-8 h-12 bg-gray-500 rounded-lg flex items-center justify-center">
            <img src={icon4} alt="Icon 4" className="w-6 h-6" />
          </button>
        </div>
        <ul className="space-y-4">
          {Object.keys(userData).map((key) => (
            <li key={key} className="flex flex-col items-start relative">
              <label className="absolute -top-2.5 left-3 bg-white px-1 text-xl font-bold">{userData[key].label}</label>
              <div className="w-1/4-full mt-4">
                <input
                  className={`form-input mt-12 w-full rounded-lg border bg-transparent px-3 py-2 placeholder:text-slate-400/70 ${measurements[key].blurred
                      ? measurements[key].errorMessage
                        ? 'border-error'
                        : 'border-success'
                      : 'border-slate-300 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent'
                    }`}
                  placeholder={`Number between 1 - 100 for ${userData[key].label}`}
                  type="text"
                  value={measurements[key].value}
                  onChange={(e) => handleChange(key, e)}
                  onBlur={() => handleBlur(key)}
                />
                {measurements[key].blurred && measurements[key].errorMessage && (
                  <span className="text-tiny+ text-error">{measurements[key].errorMessage}</span>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>
      <div className="w-128 h-128 bg-blue-500 rounded-lg flex items-center justify-center overflow-hidden">
        <img src={vectorImage} alt="Vector" className="w-full h-full object-cover" />
      </div>
    </div>
  );
};
