import React, { useState } from 'react';
import vectorImage from './Vector/11 1.png'; // Adjust the path as needed
import icon1 from './Vector/ai web app project 1.png'; // Adjust the path as needed
import icon2 from './Vector/ai web app project 2.png'; // Adjust the path as needed
import icon3 from './Vector/image 1.png'; // Adjust the path as needed
import icon4 from './Vector/image 3.png'; // Adjust the path as needed

const userData = {
    Unit: { label: 'Measurement Unit' },
    Style: { label: 'Style' },
};

const getErrorMessage = (value, validate) => {
  if (validate && (value < 1 || value > 100)) {
    return 'Value must be between 1 and 100';
  }
  return '';
};

const UserComponent = () => {
  const [measurements, setMeasurements] = useState({
    Unit: { value: '', blurred: false, errorMessage: '', validate: false },
    Style: { value: '', blurred: false, errorMessage: '', validate: false },
  });

  const handleBlur = (key) => {
    setMeasurements((prevState) => ({
      ...prevState,
      [key]: {
        ...prevState[key],
        blurred: true,
        validate: true,
        errorMessage: getErrorMessage(prevState[key].value, true),
      }
    }));
  };

  const handleChange = (key, e) => {
    const { value } = e.target;
    setMeasurements((prevState) => ({
      ...prevState,
      [key]: {
        ...prevState[key],
        value: value,
        errorMessage: getErrorMessage(value, prevState[key].validate),
      }
    }));
  };

  return (
    <div className="my-4 mx-auto max-w-full flex justify-center items-center">
      <div className="flex-grow max-w-md mr-8 mb-8">
        <div className="flex justify-center mb-12 space-x-4">
          <button className="w-24 h-16 bg-gray-500 rounded-lg flex items-center justify-center">
            <img src={icon1} alt="Icon 1" className="w-6 h-6" />
          </button>
          <button className="w-24 h-16 bg-gray-500 rounded-lg flex items-center justify-center">
            <img src={icon2} alt="Icon 2" className="w-6 h-6" />
          </button>
          <button className="w-24 h-16 bg-gray-500 rounded-lg flex items-center justify-center">
            <img src={icon3} alt="Icon 3" className="w-6 h-6" />
          </button>
          <button className="w-24 h-16 bg-gray-500 rounded-lg flex items-center justify-center">
            <img src={icon4} alt="Icon 4" className="w-6 h-6" />
          </button>
        </div>
        <ul className="space-y-4">
          {Object.keys(userData).map((key) => (
            <li key={key} className="flex flex-col items-start relative">
              <label className="absolute -top-2.5 left-3 bg-white px-1 text-xl font-bold">{userData[key].label}</label>
              <div className="w-full mt-12">
                <input
                  className={`form-input mt-1 w-full rounded-lg border bg-transparent px-3 py-2 placeholder:text-slate-400/70 ${
                    measurements[key].blurred
                      ? measurements[key].errorMessage
                        ? 'border-error'
                        : 'border-success'
                      : 'border-slate-300 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent'
                  }`}
                  placeholder={` ${userData[key].label}`}
                  type="text"
                  value={measurements[key].value}
                  onChange={(e) => handleChange(key, e)}
                  onBlur={() => handleBlur(key)}
                />
                {measurements[key].blurred && measurements[key].errorMessage && (
                  <span className="text-tiny+ text-error">{measurements[key].errorMessage}</span>
                )}
              </div>
            </li>
          ))}
        </ul>
        <div className="flex justify-center space-x-4 w-full mt-12">
          <button className="bg-red-500 text-black px-4 py-2 rounded-lg">
            Cancel
          </button>
          <button className="bg-green-500 text-black px-4 py-2 rounded-lg">
            Save
          </button>
        </div>
      </div>
      <div className="w-128 h-128 bg-blue-500 rounded-lg flex items-center justify-center overflow-hidden">
        <img src={vectorImage} alt="Vector" className="w-full h-full object-cover" />
      </div>
    </div>
  );
};

export { userData, UserComponent };
