import React, { useContext,useState,useEffect } from "react";
import logo from "../../../src/logo.png";
import { NavLink, Link } from "react-router-dom";
import { UserContext } from "./UserContext";
import { avatars } from "../../static/images/avater/avatar";

export const SidebarUser = () => {
  const {profileData} = useContext(UserContext);
  const [profileavatar, setProfileAvatar] = useState(avatars['B']);

  useEffect(() => {
    if (profileData && profileData.profile_pic && avatars[profileData.gender]) {
        const selectedAvatar = avatars[profileData.gender][profileData.profile_pic];
        if (selectedAvatar) {
            setProfileAvatar(selectedAvatar.src);
        } 
    //     else {
    //         console.error("Invalid profile_pic:", profileData.profile_pic);
    //     }
    // } else {
    //     console.error("Invalid profile data or gender:", profileData);
    }
}, [profileData]);
  return (
    <div className="main-sidebar">
      <div className=" rounded-lg flex h-full w-full flex-col items-center border-r border-slate-150 bg-white dark:border-navy-700 dark:bg-navy-800">
        <div className="flex pt-4">
          <Link to="/" exact="true">
            <img
              className="h-8 w-8 transition-transform duration-500 ease-in-out hover:rotate-[360deg]"
              src={logo}
              alt="logo"
            />
          </Link>
        </div>

        <div id="admin_nav" className="flex grow flex-col space-y-4 pt-6">
          <NavLink
            exact="true"
            to="/user/profile"
            className="flex h-11 w-11 items-center justify-center rounded-lg outline-none transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25"
          >
            <svg
              className="h-7 w-7"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
              <g
                id="SVGRepo_tracerCarrier"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></g>
              <g id="SVGRepo_iconCarrier">
                {" "}
                <circle cx="12" cy="6" r="4" fill="currentcolor"></circle>{" "}
                <path
                  opacity="0.5"
                  d="M20 17.5C20 19.9853 20 22 12 22C4 22 4 19.9853 4 17.5C4 15.0147 7.58172 13 12 13C16.4183 13 20 15.0147 20 17.5Z"
                  fill="currentcolor"
                ></path>{" "}
              </g>
            </svg>
          </NavLink>

          <NavLink
            exact="true"
            to="/user/dashboard-overview"
            className="flex h-11 w-11 items-center justify-center rounded-lg outline-none transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25"
          >
            <svg
              className="h-6 w-6"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 512 512"
              fill="currentcolor"
            >
              <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
              <g
                id="SVGRepo_tracerCarrier"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></g>
              <g id="SVGRepo_iconCarrier">
                {" "}
                <style type="text/css"> </style>{" "}
                <g>
                  {" "}
                  <path
                    className="st0"
                    d="M180.365,271.776c-39.859-0.008-76.916-5.275-107.957-14.441c-31.032-9.206-56.113-22.114-72.078-38.516 L0,218.456v112.696c0.008,8.671,3.948,17.392,12.463,26.235c8.473,8.779,21.405,17.219,37.774,24.356 c19.056,8.34,42.794,14.852,69.309,18.89v-70.001h16.88v72.178c12.008,1.286,24.463,2.044,37.28,2.242v-40.239h16.88v40.388h37.271 v-74.568h16.88v74.568h37.271v-40.388h16.88v40.388h37.28v-74.568h16.88v74.568h37.28v-40.388h16.88v40.388h37.271v-74.568h16.88 v74.568H512V271.776H180.365z"
                  ></path>{" "}
                  <path
                    className="st0"
                    d="M295.774,254.896h64.948v-36.439l-0.33,0.362c-10.64,10.963-25.353,20.292-43.148,28.082 C310.56,249.818,303.298,252.438,295.774,254.896z"
                  ></path>{" "}
                  <path
                    className="st0"
                    d="M50.237,231.438c32.738,14.324,78.993,23.474,130.128,23.458c38.352,0,73.942-5.11,103.169-13.748 c29.235-8.58,52.033-20.87,64.726-34.066c8.514-8.843,12.454-17.564,12.462-26.235c-0.008-8.679-3.948-17.391-12.462-26.235 c-8.473-8.778-21.405-17.218-37.774-24.356c-32.738-14.334-78.993-23.482-130.12-23.457c-38.351-0.008-73.949,5.11-103.176,13.74 c-29.234,8.58-52.033,20.87-64.726,34.073C3.948,163.456,0.008,172.168,0,180.847c0.008,8.671,3.948,17.392,12.463,26.235 C20.936,215.86,33.868,224.3,50.237,231.438z M121.879,174.814c3.684-3.898,11.431-8.258,21.71-11.242 c10.27-3.034,23.021-4.888,36.776-4.88c18.331-0.024,34.898,3.314,46.149,8.258c5.621,2.44,9.866,5.292,12.322,7.864 c2.505,2.629,3.124,4.516,3.132,6.033c-0.008,1.508-0.627,3.404-3.132,6.034c-3.676,3.89-11.424,8.259-21.702,11.242 c-10.27,3.033-23.013,4.879-36.769,4.879c-18.338,0.017-34.906-3.314-46.156-8.259c-5.621-2.44-9.866-5.291-12.33-7.863 c-2.506-2.63-3.116-4.526-3.125-6.034C118.763,179.33,119.373,177.443,121.879,174.814z"
                  ></path>{" "}
                </g>{" "}
              </g>
            </svg>
          </NavLink>

          <NavLink
            exact="true"
            to="/user/chat"
            className="flex h-11 w-11 items-center justify-center rounded-lg outline-none transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25"
          >
            <svg
              className="h-5 w-5"
              viewBox="0 0 512 512"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillOpacity="0.4"
                d="M499.884 479.3c-20.4-5-35.8-19.9-46.6-34.7 37.5-29.4 58.8-69.9 58.8-113 0-36-15-69.2-40.1-95.7-28.7 92.2-129.1 161-247.9 161-15.9 0-31.6-1.2-46.9-3.6-8.9 4.3-18.2 8.4-26.7 11.8 32.3 49.6 96.2 83.4 169.6 83.4 15 0 29.6-1.4 43.4-4.1 45.9 23.4 87.8 27.7 112.4 27.7 13.5 0 21.8-1.3 22.8-1.4 7.5-1.2 13.1-7.6 13.4-15.1.3-7.8-4.8-14.5-12.2-16.3z"
                fill="currentcolor"
              ></path>
              <path
                d="M224.084 0c-123.5 0-224 81.8-224 182.4 0 50.9 25.6 98.7 70.8 133.1-14.9 23.3-34.3 46.9-58.7 53-7.7 1.9-12.9 9.2-12.1 17.1s7.3 14 15.3 14.4c.4 0 1.7.1 4 .1 16.5 0 80.4-2.7 152.9-40.3 16.6 3.4 34 5 51.7 5 123.5 0 224-81.8 224-182.4S347.584 0 224.084 0z"
                fill="currentcolor"
              ></path>
            </svg>
          </NavLink>

          <NavLink
            exact="true"
            to="/user/project-management"
            className="flex h-11 w-11 items-center justify-center rounded-lg outline-none transition-colors duration-200 hover:bg-primary/20 focus:bg-primary/20 active:bg-primary/25 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25"
          >
            <svg
            className="h-6 w-6"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
              <g
                id="SVGRepo_tracerCarrier"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></g>
              <g id="SVGRepo_iconCarrier">
                {" "}
                <path
                  d="M18.5 18.8637V8.07579C18.5 5.99472 17.0378 4.20351 15.0077 3.7977C13.022 3.40077 10.978 3.40077 8.99225 3.7977C6.96219 4.20351 5.5 5.99472 5.5 8.07579V18.8637C5.5 20.1258 6.8627 20.9113 7.94601 20.2737L10.9053 18.5317C11.5814 18.1337 12.4186 18.1337 13.0947 18.5317L16.054 20.2737C17.1373 20.9113 18.5 20.1258 18.5 18.8637Z"
                  fill="currentcolor"
                  stroke="currentcolor"
                ></path>{" "}
              </g>
            </svg>
          </NavLink>
        </div>

        <div className="flex flex-col items-center space-y-3 py-3">
          <div
            x-data="usePopper({placement:'right-end',offset:12})"
            className="flex"
          >
            <button x-ref="popperRef" className="avatar h-12 w-12">
              <img className="rounded-full" src={
                profileavatar
              } alt="avatar" />
              <span className="absolute right-0 h-3.5 w-3.5 rounded-full border-2 border-white bg-success dark:border-navy-700"></span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
