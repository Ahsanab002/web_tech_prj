import React, { createContext, useState, useEffect } from 'react';

export const UserChatContext = createContext();

const UserChatProvider = ({ children }) => {
  const [userMessages, setUserMessages] = useState([]); // State to hold user messages
  const [loading, setLoading] = useState(true); // State to manage loading status
  const [error, setError] = useState(null); // State to manage error status

  const fetchUserMessages = async () => {
    try {
      const response = await fetch('http://localhost:3000/boopy/api/chat/user');
      if (!response.ok) {
        throw new Error('Failed to fetch messages');
      }
      const data = await response.json();
      setUserMessages(data); // Update user messages state
    } catch (error) {
      setError(error.message); // Set error message on failure
    } finally {
      setLoading(false); // Set loading to false regardless of success or failure
    }
  };

  useEffect(() => {
    fetchUserMessages(); // Fetch messages when component mounts
  }, []);

  return (
    <UserChatContext.Provider value={{ userMessages, loading, error, setUserMessages }}>
      {children}
    </UserChatContext.Provider>
  );
};

export default UserChatProvider;
