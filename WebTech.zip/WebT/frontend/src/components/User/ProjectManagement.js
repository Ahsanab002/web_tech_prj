// import React, { useState } from 'react';
// import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
// import 'leaflet/dist/leaflet.css';

// const ProjectManagement = () => {
//   const [selectedOption, setSelectedOption] = useState('');

//   const handleOptionChange = (option) => {
//     setSelectedOption(option);
//   };

//   return (
//     <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white-800 px-6 py-10">
//       <h1 className="text-5xl font-extrabold mb-12 shadow-lg p-6 rounded-xl bg-opacity-90 bg-white text-gray-900">
//         Services
//       </h1>

//       <div className="w-full max-w-md mb-8">
//         <select
//           className="w-full bg-gray-100 text-gray-800 px-4 py-3 rounded-lg shadow-md focus:outline-none focus:ring-4 focus:ring-purple-500 transition-all"
//           onChange={(e) => handleOptionChange(e.target.value)}
//           defaultValue=""
//         >
//           <option value="" disabled>
//             Select a Service
//           </option>
//           <option value="3D Modelling">3D Modelling</option>
//           <option value="VR & AR">VR & AR</option>
//           <option value="CGI Ads">CGI Ads</option>
//           <option value="GIS Maps">GIS Maps</option>
//         </select>
//       </div>

//       <div className="mt-10 w-full max-w-2xl bg-white p-8 rounded-lg shadow-2xl">
// {selectedOption === "3D Modelling" && (
//   <div className="bg-gradient-to-br from-purple-50 to-indigo-50 p-8 rounded-2xl shadow-xl">
//     <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent animate-fade-in">3D Modelling</h2>
//     <form className="space-y-8">
//       <div className="transform transition-all duration-200 hover:scale-102">
//         <label className="block font-semibold mb-2 text-purple-800">Model Type:</label>
//         <select 
//           className="w-full px-4 py-3 rounded-lg bg-white border-2 border-purple-100 focus:border-purple-500 focus:ring-4 focus:ring-purple-200 outline-none transition-all duration-200 hover:border-purple-300"
//         >
//           <option value="">Select Model Type</option>
//           <option value="polygonal">Polygonal Modeling</option>
//           <option value="nurbs">NURBS Modeling</option>
//           <option value="subdivision">Subdivision Surface Modeling</option>
//           <option value="procedural">Procedural Modeling</option>
//           <option value="digital">Digital Sculpting</option>
//           <option value="parametric">Parametric Modeling</option>
//           <option value="primitive">Primitive Modeling</option>
//           <option value="cad">CAD Modeling</option>
//         </select>
//       </div>

//       <div className="transform transition-all duration-200 hover:scale-102">
//         <label className="block font-semibold mb-2 text-purple-800">Textures:</label>
//         <select 
//           className="w-full px-4 py-3 rounded-lg bg-white border-2 border-purple-100 focus:border-purple-500 focus:ring-4 focus:ring-purple-200 outline-none transition-all duration-200 hover:border-purple-300"
//         >
//           <option value="">Select Texture Type</option>
//           <option value="materials">Materials Library</option>
//           <option value="hatch">Hatch Patterns</option>
//           <option value="realistic">Realistic Materials</option>
//           <option value="procedural">Procedural Textures</option>
//           <option value="custom">Custom Materials</option>
//           <option value="render">Render Materials</option>
//           <option value="architectural">Architectural Materials</option>
//           <option value="mechanical">Mechanical Finishes</option>
//         </select>
//       </div>

//       <div className="transform transition-all duration-200 hover:scale-102">
//         <label className="block font-semibold mb-2 text-purple-800">Dimensions:</label>
//         <input
//           type="text"
//           placeholder="Enter Dimensions"
//           className="w-full px-4 py-3 rounded-lg bg-white border-2 border-purple-100 focus:border-purple-500 focus:ring-4 focus:ring-purple-200 outline-none transition-all duration-200 hover:border-purple-300"
//         />
//       </div>

//       <div className="transform transition-all duration-200 hover:scale-102">
//         <label className="block font-semibold mb-2 text-purple-800">File Format:</label>
//         <input
//           type="text"
//           placeholder="Enter File Format"
//           className="w-full px-4 py-3 rounded-lg bg-white border-2 border-purple-100 focus:border-purple-500 focus:ring-4 focus:ring-purple-200 outline-none transition-all duration-200 hover:border-purple-300"
//         />
//       </div>

//       <button
//         type="submit"
//         className="w-full py-4 mt-8 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 rounded-lg text-white font-bold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
//       >
//         Place Order
//       </button>
//     </form>
//   </div>
// )}

//         {selectedOption === "VR & AR" && (
//           <div>
//             <h2 className="text-4xl font-bold mb-6">VR & AR</h2>
//             <form className="space-y-6">
//               <div>
//                 <label className="block font-semibold mb-2">Platform:</label>
//                 <input
//                   type="text"
//                   placeholder="Enter Platform"
//                   className="w-full px-4 py-3 rounded-lg bg-gray-100 focus:ring-4 focus:ring-purple-500 outline-none"
//                 />
//               </div>
//               <div>
//                 <label className="block font-semibold mb-2">Content Type:</label>
//                 <input
//                   type="text"
//                   placeholder="Enter Content Type"
//                   className="w-full px-4 py-3 rounded-lg bg-gray-100 focus:ring-4 focus:ring-purple-500 outline-none"
//                 />
//               </div>
//               <div>
//                 <h3 className="font-semibold text-lg mb-4">Nearest Locations:</h3>
//                 <MapContainer
//                   center={[51.505, -0.09]}
//                   zoom={13}
//                   style={{ height: "300px", width: "100%" }}
//                   className="rounded-lg overflow-hidden"
//                 >
//                   {/* <TileLayer
//                     url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
//                     attribution="&copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors"
//                   /> */}
//                   <Marker position={[51.505, -0.09]}>
//                     <Popup>Nearest Location</Popup>
//                   </Marker>
//                 </MapContainer>
//               </div>
//               <button
//                 type="submit"
//                 className="w-full py-3 mt-6 bg-purple-700 hover:bg-purple-800 rounded-lg text-white font-bold transition-all shadow-lg"
//               >
//                 Place Order
//               </button>
//             </form>
//           </div>
//         )}

//         {selectedOption === "CGI Ads" && (
//           <div>
//             <h2 className="text-4xl font-bold mb-6">CGI Ads</h2>
//             <form className="space-y-6">
//               <div>
//                 <label className="block font-semibold mb-2">Ad Type:</label>
//                 <input
//                   type="text"
//                   placeholder="Enter Ad Type"
//                   className="w-full px-4 py-3 rounded-lg bg-gray-100 focus:ring-4 focus:ring-purple-500 outline-none"
//                 />
//               </div>
//               <div>
//                 <label className="block font-semibold mb-2">Duration:</label>
//                 <input
//                   type="text"
//                   placeholder="Enter Duration"
//                   className="w-full px-4 py-3 rounded-lg bg-gray-100 focus:ring-4 focus:ring-purple-500 outline-none"
//                 />
//               </div>
//               <div>
//                 <label className="block font-semibold mb-2">Resolution:</label>
//                 <input
//                   type="text"
//                   placeholder="Enter Resolution"
//                   className="w-full px-4 py-3 rounded-lg bg-gray-100 focus:ring-4 focus:ring-purple-500 outline-none"
//                 />
//               </div>
//               <button
//                 type="submit"
//                 className="w-full py-3 mt-6 bg-purple-700 hover:bg-purple-800 rounded-lg text-white font-bold transition-all shadow-lg"
//               >
//                 Place Order
//               </button>
//             </form>
//           </div>
//         )}

//         {selectedOption === "GIS Maps" && (
//           <div>
//             <h2 className="text-4xl font-bold mb-6">GIS Maps</h2>
//             <form className="space-y-6">
//               <div>
//                 <label className="block font-semibold mb-2">Map Type:</label>
//                 <input
//                   type="text"
//                   placeholder="Enter Map Type"
//                   className="w-full px-4 py-3 rounded-lg bg-gray-100 focus:ring-4 focus:ring-purple-500 outline-none"
//                 />
//               </div>
//               <div>
//                 <label className="block font-semibold mb-2">Layer Details:</label>
//                 <input
//                   type="text"
//                   placeholder="Enter Layer Details"
//                   className="w-full px-4 py-3 rounded-lg bg-gray-100 focus:ring-4 focus:ring-purple-500 outline-none"
//                 />
//               </div>
//               <div>
//                 <label className="block font-semibold mb-2">Output Format:</label>
//                 <input
//                   type="text"
//                   placeholder="Enter Output Format"
//                   className="w-full px-4 py-3 rounded-lg bg-gray-100 focus:ring-4 focus:ring-purple-500 outline-none"
//                 />
//               </div>
//               <button
//                 type="submit"
//                 className="w-full py-3 mt-6 bg-purple-700 hover:bg-purple-800 rounded-lg text-white font-bold transition-all shadow-lg"
//               >
//                 Place Order
//               </button>
//             </form>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default ProjectManagement;


import React, { useState } from 'react';
import { Map } from 'lucide-react';
// import {}

const ProjectManagement = () => {
  const [selectedOption, setSelectedOption] = useState('');

  const handleOptionChange = (option) => {
    setSelectedOption(option);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 bg-white text-white px-6 py-10 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
        <div className="absolute w-96 h-96 bg-indigo-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000 top-24 right-48"></div>
        <div className="absolute w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-4000 bottom-24 left-48"></div>
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center">
        <h1 className="text-6xl font-black mb-12 bg-clip-text text-transparent bg-gradient-to-r from-violet-400 to-pink-300 animate-fade-in">
          Our Services
        </h1>

        <div className="w-full max-w-md mb-8 transform hover:scale-105 transition-all duration-300">
          <select
            className="w-full bg-white/10 backdrop-blur-lg text-white px-4 py-3 rounded-lg border border-white/20 focus:outline-none focus:ring-4 focus:ring-violet-500/50 transition-all"
            onChange={(e) => handleOptionChange(e.target.value)}
            defaultValue=""
          >
            <option value="" disabled className="text-gray-800">Select a Service</option>
            <option value="3D Modelling" className="text-gray-800">3D Modelling</option>
            <option value="VR & AR" className="text-gray-800">VR & AR</option>
            <option value="CGI Ads" className="text-gray-800">CGI Ads</option>
            <option value="GIS Maps" className="text-gray-800">GIS Maps</option>
          </select>
        </div>

        <div className="mt-10 w-full max-w-2xl">
          <div className="bg-white/10 backdrop-blur-lg p-8 rounded-2xl border border-white/20 shadow-2xl transform transition-all duration-500 hover:scale-102">
            {selectedOption === "3D Modelling" && (
              <div className="space-y-8 animate-fade-in">
                <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-pink-400 to-violet-400 bg-clip-text text-transparent">3D Modelling</h2>
                <form className="space-y-8">
                  <div className="transform transition-all duration-200 hover:scale-102">
                    <label className="block font-semibold mb-2 text-violet-300">Model Type:</label>
                    <select 
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 outline-none transition-all duration-200 text-white"
                    >
                      <option value="" className="text-gray-800">Select Model Type</option>
                      <option value="polygonal" className="text-gray-800">Polygonal Modeling</option>
                      <option value="nurbs" className="text-gray-800">NURBS Modeling</option>
                      <option value="subdivision" className="text-gray-800">Subdivision Surface Modeling</option>
                      <option value="digital" className="text-gray-800">Digital Sculpting</option>
                      <option value="parametric" className="text-gray-800">Parametric Modeling</option>
                    </select>
                  </div>

                  <div className="transform transition-all duration-200 hover:scale-102">
                    <label className="block font-semibold mb-2 text-violet-300">Textures:</label>
                    <select 
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 outline-none transition-all duration-200 text-white"
                    >
                      <option value="" className="text-gray-800">Select Texture Type</option>
                      <option value="materials" className="text-gray-800">Materials Library</option>
                      <option value="realistic" className="text-gray-800">Realistic Materials</option>
                      <option value="procedural" className="text-gray-800">Procedural Textures</option>
                      <option value="custom" className="text-gray-800">Custom Materials</option>
                    </select>
                  </div>

                  {["Dimensions", "File Format"].map((label) => (
                    <div key={label} className="transform transition-all duration-200 hover:scale-102">
                      <label className="block font-semibold mb-2 text-violet-300">{label}:</label>
                      <input
                        type="text"
                        placeholder={`Enter ${label}`}
                        className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 outline-none transition-all duration-200 text-white"
                      />
                    </div>
                  ))}
                  <button
                    type="submit"
                    className="w-full py-4 mt-8 bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-700 hover:to-pink-700 rounded-lg font-bold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                  >
                    Place Order
                  </button>
                </form>
              </div>
            )}

            {selectedOption === "VR & AR" && (
              <div className="animate-fade-in">
                <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-pink-400 to-violet-400 bg-clip-text text-transparent">
                  VR & AR
                </h2>
                <form className="space-y-6">
                  <div className="transform transition-all duration-200 hover:scale-102">
                    <label className="block font-semibold mb-2 text-violet-300">Platform:</label>
                    <select 
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 outline-none transition-all duration-200 text-white"
                    >
                      <option value="" className="text-gray-800">Select Platform</option>
                      <option value="oculus" className="text-gray-800">Oculus</option>
                      <option value="vive" className="text-gray-800">HTC Vive</option>
                      <option value="arkit" className="text-gray-800">ARKit</option>
                      <option value="arcore" className="text-gray-800">ARCore</option>
                    </select>
                  </div>

                  <div className="transform transition-all duration-200 hover:scale-102">
                    <label className="block font-semibold mb-2 text-violet-300">Content Type:</label>
                    <select 
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 outline-none transition-all duration-200 text-white"
                    >
                      <option value="" className="text-gray-800">Select Content Type</option>
                      <option value="game" className="text-gray-800">Interactive Game</option>
                      <option value="experience" className="text-gray-800">Virtual Experience</option>
                      <option value="training" className="text-gray-800">Training Simulation</option>
                      <option value="visualization" className="text-gray-800">Data Visualization</option>
                    </select>
                  </div>

                  <div className="mt-6 p-6 bg-white/5 rounded-lg border border-white/10">
                    <div className="flex items-center justify-center space-x-4">
                      <Map size={24} className="text-violet-300" />
                      <span className="text-violet-300 font-semibold">Location Services Available</span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 mt-8 bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-700 hover:to-pink-700 rounded-lg font-bold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                  >
                    Place Order
                  </button>
                </form>
              </div>
            )}

            {selectedOption === "CGI Ads" && (
              <div className="animate-fade-in">
                <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-pink-400 to-violet-400 bg-clip-text text-transparent">
                  CGI Ads
                </h2>
                <form className="space-y-6">
                  {["Ad Type", "Duration", "Resolution"].map((label) => (
                    <div key={label} className="transform transition-all duration-200 hover:scale-102">
                      <label className="block font-semibold mb-2 text-violet-300">{label}:</label>
                      <input
                        type="text"
                        placeholder={`Enter ${label}`}
                        className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 outline-none transition-all duration-200 text-white"
                      />
                    </div>
                  ))}
                  <button
                    type="submit"
                    className="w-full py-4 mt-8 bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-700 hover:to-pink-700 rounded-lg font-bold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                  >
                    Place Order
                  </button>
                </form>
              </div>
            )}

            {selectedOption === "GIS Maps" && (
              <div className="animate-fade-in">
                <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-pink-400 to-violet-400 bg-clip-text text-transparent">
                  GIS Maps
                </h2>
                <form className="space-y-6">
                  <div className="transform transition-all duration-200 hover:scale-102">
                    <label className="block font-semibold mb-2 text-violet-300">Map Type:</label>
                    <select 
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 outline-none transition-all duration-200 text-white"
                    >
                      <option value="" className="text-gray-800">Select Map Type</option>
                      <option value="topographic" className="text-gray-800">Topographic</option>
                      <option value="demographic" className="text-gray-800">Demographic</option>
                      <option value="satellite" className="text-gray-800">Satellite</option>
                      <option value="thematic" className="text-gray-800">Thematic</option>
                    </select>
                  </div>

                  {["Layer Details", "Output Format"].map((label) => (
                    <div key={label} className="transform transition-all duration-200 hover:scale-102">
                      <label className="block font-semibold mb-2 text-violet-300">{label}:</label>
                      <input
                        type="text"
                        placeholder={`Enter ${label}`}
                        className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 outline-none transition-all duration-200 text-white"
                      />
                    </div>
                  ))}
                  <button
                    type="submit"
                    className="w-full py-4 mt-8 bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-700 hover:to-pink-700 rounded-lg font-bold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                  >
                    Place Order
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectManagement;


