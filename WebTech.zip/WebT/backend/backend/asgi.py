# asgi.py
import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from chatbox.routing import websocket_urlpatterns  # Update with your actual app name
from chatbox.middleware import TokenAuthMiddleware
import socketio

# sio = socketio.AsyncServer()

# os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')

application = ProtocolTypeRouter({
    "http": get_asgi_application(),  # Handle HTTP requests
    "websocket": AuthMiddlewareStack(  # Handle WebSocket requests
        URLRouter(
             websocket_urlpatterns
         )
     ),
 })

# application = ProtocolTypeRouter({
#     "http": get_asgi_application(),  # Handle HTTP requests
#     "websocket": TokenAuthMiddleware(  # Handle WebSocket requests
#         URLRouter(
#             websocket_urlpatterns
#         )
#     ),
#     "socket.io": socketio.ASGIApp(sio),  # Adding Socket.IO route
# })


