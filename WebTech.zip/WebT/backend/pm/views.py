from django.core.mail import send_mail
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt
def place_order(request):
    if request.method == 'POST':
        try:
            # Parse the request data
            data = json.loads(request.body)
            map_type = data.get('mapType')
            layer_details = data.get('layerDetails')
            output_format = data.get('outputFormat')

            # Send the email notification
            send_mail(
                'New GIS Map Order',
                f'Order Details:\nMap Type: {map_type}\nLayer Details: {layer_details}\nOutput Format: {output_format}',
                'your-email@example.com',  # Replace with your sender email address
                ['admin-email@example.com'],  # Replace with your recipient email address
                fail_silently=False,
            )

            return JsonResponse({'message': 'Order placed successfully'}, status=200)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

    return JsonResponse({'error': 'Invalid request'}, status=400)
