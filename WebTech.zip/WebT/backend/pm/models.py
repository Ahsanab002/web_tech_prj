from django.db import models

class GISOrder(models.Model):
    MAP_TYPES = [
        ('topographic', 'Topographic'),
        ('demographic', 'Demographic'),
        ('satellite', 'Satellite'),
        ('thematic', 'Thematic'),
    ]

    map_type = models.CharField(max_length=20, choices=MAP_TYPES)
    layer_details = models.TextField()
    output_format = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.map_type} - {self.layer_details[:30]}"
