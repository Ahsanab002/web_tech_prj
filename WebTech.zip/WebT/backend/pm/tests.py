from django.test import TestCase
from .models import GISOrder

class GISOrderTestCase(TestCase):
    def setUp(self):
        GISOrder.objects.create(
            map_type="topographic",
            layer_details="Layer details example",
            output_format="PDF"
        )

    def test_order_creation(self):
        order = GISOrder.objects.get(map_type="topographic")
        self.assertEqual(order.output_format, "PDF")
