from django.contrib import admin
from .models import GISOrder

@admin.register(GISOrder)
class GISOrderAdmin(admin.ModelAdmin):
    list_display = ('map_type', 'layer_details', 'output_format', 'created_at')
    search_fields = ('map_type', 'layer_details', 'output_format')
