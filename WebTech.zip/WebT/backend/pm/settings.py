EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'huxain69@gmail.com'  # Replace with your Gmail account
EMAIL_HOST_PASSWORD = '12345678asdfghjkl'  # Replace with your Gmail password or use an app password
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER
