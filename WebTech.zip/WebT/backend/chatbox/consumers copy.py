import json
import logging
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import ChatMessage
from django.contrib.auth import get_user_model
from channels.db import database_sync_to_async

User = get_user_model()
logger = logging.getLogger(__name__)

class ChatConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        self.user = self.scope['user']
        
        # Check if the user is authenticated
        if self.user.is_anonymous:
            logger.warning("Anonymous user tried to connect.")
            await self.close()  # Reject the connection if not authenticated
            return

        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f"chat_{self.room_name}"

        # Join the chat room
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()
        logger.info(f"User {self.user.username} connected to room {self.room_name}.")

    async def disconnect(self, close_code):
        # Leave the chat room
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)
        logger.info(f"User {self.user.username} disconnected from room {self.room_name}.")

    async def receive(self, text_data):
        logger.debug(f"Received data: {text_data}")  # Log the incoming data
        try:
            data = json.loads(text_data)
            message = data['message']
            receiver_id = data['receiver_id']
            receiver = await self.get_user(receiver_id)

            if receiver is None:
                await self.send_error_message("Receiver not found")
                return

            # Get the actual sender user instance
            sender = self.user  # Use the authenticated user from scope directly

            if sender is None:
                await self.send_error_message("Sender not found")
                return

            # Save the message using actual user instances
            chat_message = await self.save_message(sender, receiver, message)

            # Broadcast the message to the group
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'chat_message',
                    'message': message,
                    'sender': sender.username,
                }
            )

        except json.JSONDecodeError as e:
            logger.error(f"JSON Decode Error: {e}")  # Log the error
            await self.send_error_message("Invalid JSON data")
        except Exception as e:
            logger.error(f"Unexpected error: {e}")  # Log any unexpected error
            await self.send_error_message("An unexpected error occurred.")

    async def chat_message(self, event):
        message = event['message']
        sender = event['sender']

        # Send the message to the WebSocket
        await self.send(text_data=json.dumps({
            'message': message,
            'sender': sender,
        }))

    @database_sync_to_async
    def get_user(self, user_id):
        try:
            return User.objects.get(id=user_id)
        except User.DoesNotExist:
            logger.error(f"User with ID {user_id} does not exist.")
            return None

    @database_sync_to_async
    def save_message(self, sender, receiver, message):
        try:
            return ChatMessage.objects.create(
                sender=sender,  # Now this is an actual User instance
                receiver=receiver,
                message=message
            )
        except Exception as e:
            logger.error(f"Error saving message: {e}")  # Log if user not found
            return None

    async def send_error_message(self, error_message):
        # Send an error message back to the client
        await self.send(text_data=json.dumps({
            'error': error_message
        }))
