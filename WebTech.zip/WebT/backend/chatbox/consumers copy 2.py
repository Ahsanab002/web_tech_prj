import json
import logging
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import ChatMessage
from django.contrib.auth import get_user_model
from channels.db import database_sync_to_async
from django.conf import settings
import pdb

User = get_user_model()
logger = logging.getLogger(__name__)

class ChatConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        self.user = self.scope['user']
        logger.debug(f"User connected: {self.user}")

        if self.user.is_anonymous:
            logger.error("Anonymous user tried to connect")
            await self.close()
            return

        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f"chat_{self.room_name}"

        # Join the chat room
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)

        # Accept the WebSocket connection
        await self.accept()

        # Load the last 50 or 30 messages
        last_messages = await self.get_last_messages()

        # Send the messages to the client
        for message in last_messages:
            await self.send(text_data=json.dumps({
                'message': message.message,
                'sender': message.sender.username,
            }))

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

    async def receive(self, text_data):
        logger.debug(f"Received data: {text_data}")
        try:
            data = json.loads(text_data)
            message = data['message']
            receiver_id = data['receiver_id']
            receiver = await self.get_user(receiver_id)

            if receiver is None:
                await self.send_error_message("Receiver not found")
                return

            sender = self.user

            chat_message = await self.save_message(sender, receiver, message)

            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'chat_message',
                    'message': message,
                    'sender': sender.username,
                }
            )

        except json.JSONDecodeError as e:
            logger.error(f"JSON Decode Error: {e}")
            await self.send_error_message("Invalid JSON data")

    async def chat_message(self, event):
        message = event['message']
        sender = event['sender']

        await self.send(text_data=json.dumps({
            'message': message,
            'sender': sender,
        }))

    @database_sync_to_async
    def get_user(self, user_id):
        try:
            return User.objects.get(id=user_id)
        except User.DoesNotExist:
            return None

    @database_sync_to_async
    def save_message(self, sender, receiver, message):
        return ChatMessage.objects.create(sender=sender, receiver=receiver, message=message)

    @database_sync_to_async
    def get_last_messages(self, limit=50):
        return ChatMessage.objects.filter(room_name=self.room_name).order_by('-timestamp')[:limit]

    async def send_error_message(self, error_message):
        await self.send(text_data=json.dumps({'error': error_message}))
