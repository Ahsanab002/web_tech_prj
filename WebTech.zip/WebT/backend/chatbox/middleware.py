# middleware.py
from django.contrib.auth.models import AnonymousUser
from channels.middleware import BaseMiddleware
from django.db import close_old_connections
from rest_framework_simplejwt.tokens import UntypedToken
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from django.contrib.auth import get_user_model
from channels.db import database_sync_to_async
import pdb

User = get_user_model()

class TokenAuthMiddleware(BaseMiddleware):
    async def __call__(self, scope, receive, send):
        # Extract token from the query string
        token = None
        query_string = scope.get('query_string', b'').decode()
        if query_string:
            params = dict(param.split('=') for param in query_string.split('&'))
            token = params.get('token')

        scope['user'] = AnonymousUser()

        if token:
            try:
                # Decode and verify token
                UntypedToken(token)
                # Fetch the user associated with the token
                user = await self.get_user_from_token(token)
                if user:
                    scope['user'] = user
            except (InvalidToken, TokenError):
                pass

        # Close any old database connections before handling request
        close_old_connections()

        return await super().__call__(scope, receive, send)

    @database_sync_to_async
    def get_user_from_token(self, token):
        try:
            # Decode the token and retrieve the user
            user_id = UntypedToken(token).payload.get('user_id')
            return User.objects.get(id=user_id)
        except User.DoesNotExist:
            return None
