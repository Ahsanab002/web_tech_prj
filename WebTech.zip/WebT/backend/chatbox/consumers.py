import json
import logging
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import ChatMessage
from django.contrib.auth import get_user_model
from channels.db import database_sync_to_async
from rest_framework_simplejwt.tokens import UntypedToken
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from django.db.models import Q
import pdb

User = get_user_model()
logger = logging.getLogger(__name__)

class ChatConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        # Extract token from headers
        # token = self.get_token_from_headers()
        token = self.scope['query_string'].decode('utf-8').split('=')[1]  # Extract token from ?token=...

        if not token:
            logger.error("No token found in headers")
            await self.close()
            return

        # Authenticate the user
        try:
            self.user = await self.authenticate_user(token)
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            await self.close()
            return

        if not self.user:
            logger.error("Authentication failed. Closing connection.")
            await self.close()
            return

        # logger.info(f"User {self.user.username} connected.")

        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f"chat_{self.room_name}"

        # Join the room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        await self.accept()

        # Send previous messages
        await self.send_last_messages()

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            # Leave the room group
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )
        # logger.info(f"User {self.user.username if self.user else 'unknown'} disconnected.")

    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
            message = data['message']
            receiver_name = data['receiver_name']
            sender_name = data['sender_name']

            # Fetch sender and receiver asynchronously
            sender = await self.get_user_by_username(sender_name)
            receiver = await self.get_user_by_username(receiver_name)

            if not receiver:
                await self.send_error_message("Receiver not found")
                return

            # Save chat message asynchronously
            await self.save_message(sender, receiver, message)

            # Send message to the room
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'chat_message',
                    'message': message,
                    'sender': sender.username,
                }
            )
        except json.JSONDecodeError:
            await self.send_error_message("Invalid JSON data")
        except Exception as e:
            logger.error(f"Error processing received data: {str(e)}")
            await self.send_error_message("An error occurred")

    async def chat_message(self, event):
        message = event['message']
        sender = event['sender']

        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'message': message,
            'sender': sender,
        }))

    @database_sync_to_async
    def get_user_by_username(self, username):
        """Fetch a user by username."""
        try:
            return User.objects.get(username=username)
        except User.DoesNotExist:
            return None

    @database_sync_to_async
    def save_message(self, sender, receiver, message):
        """Save chat message."""
        return ChatMessage.objects.create(
            sender=sender,
            receiver=receiver,
            message=message,
            is_read_by_admin=(sender.username == 'admin'),
            is_read_by_user=(sender.username != 'admin'),
        )

    async def get_messages_for_room(self, limit=50):
        """Fetch last 50 messages for the room."""
        admin_user = await self.get_user_by_username('admin')  # Correctly await here
        other_user = self.user

        # Evaluate the QuerySet within the async context
        messages = await self.get_messages_list(admin_user, other_user, limit)

        return messages

    @database_sync_to_async
    def get_messages_list(self, admin_user, other_user, limit):
        """Fetch messages asynchronously."""
        return list(ChatMessage.objects.filter(
            Q(sender=admin_user, receiver=other_user) |
            Q(sender=other_user, receiver=admin_user)
        ).order_by('-timestamp')[:limit])  # Convert to a list

    @database_sync_to_async
    def get_sender_username(self, sender_id):
        """Fetch sender's username."""
        try:
            return User.objects.get(id=sender_id).username  # Return the username directly
        except User.DoesNotExist:
            return "Unknown"

    async def send_last_messages(self):
        """Load and send the last 50 messages to the client."""
        last_messages = await self.get_messages_for_room()

        # for message in last_messages:
        #     sender_username = await self.get_sender_username(message.sender.id)
        #     await self.send(text_data=json.dumps({
        #         'message': message.message,
        #         'sender': ,
        #     }))

    async def send_error_message(self, error_message):
        """Send an error message to the WebSocket client."""
        await self.send(text_data=json.dumps({
            'error': error_message
        }))

    def get_token_from_headers(self):
        """Extract Bearer token from headers."""
        headers = dict(self.scope['headers'])
        auth_header = headers.get(b'authorization', None)

        if auth_header is None:
            return None

        try:
            auth_header_str = auth_header.decode('utf-8')
            if auth_header_str.startswith('Bearer '):
                return auth_header_str.split('Bearer ')[1]
        except Exception as e:
            logger.error(f"Token extraction error: {str(e)}")
            return None
        return None

    @database_sync_to_async
    def authenticate_user(self, token):
        """Authenticate the user using the provided JWT token."""
        try:
            untoken = UntypedToken(token)  # Ensure correct token type
            user_id = untoken.payload.get('user_id')
            return User.objects.get(id=user_id)
        except (InvalidToken, TokenError, User.DoesNotExist) as e:
            logger.error(f"Token authentication failed: {str(e)}")
            return None
