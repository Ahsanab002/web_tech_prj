from django.contrib import admin
from .models import ChatMessage 

# Register the ChatMessage model
admin.site.register(ChatMessage)
