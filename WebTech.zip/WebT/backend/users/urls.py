# users/urls.py

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import RegisterView, LoginView, UserView, RequestPasswordResetEmail, PasswordTokenCheckAPI, SetNewPasswordAPIView
from .views import ChangePasswordView, ProfileViewSet, NotificationsViewSet, MeasurementsViewSet, FavouritesViewSet, StockWatchViewSet
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import AdminProfileViewSet, AdminNotificationsViewSet, AdminMeasurementsViewSet, AdminFavouritesViewSet, AdminStockWatchViewSet
from .views import FavViewSetChromeExtension


router = DefaultRouter()
# Regular user routes
router.register(r'profiles', ProfileViewSet, basename='user-profile')
router.register(r'notifications', NotificationsViewSet, basename='user-notifications')
router.register(r'measurements', MeasurementsViewSet, basename='user-measurements')
router.register(r'favourites', FavouritesViewSet, basename='user-favourites')
router.register(r'stockwatch', StockWatchViewSet, basename='user-stockwatch')

# Admin routes
router.register(r'admin/profiles', AdminProfileViewSet, basename='admin-profile')
router.register(r'admin/notifications', AdminNotificationsViewSet, basename='admin-notifications')
router.register(r'admin/measurements', AdminMeasurementsViewSet, basename='admin-measurements')
router.register(r'admin/favourites', AdminFavouritesViewSet, basename='admin-favourites')
router.register(r'admin/stockwatch', AdminStockWatchViewSet, basename='admin-stockwatch')

# Chrome extension routes
router.register(r'chrome/favourites', FavViewSetChromeExtension, basename='chrome-favourites')

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('user/', UserView.as_view(), name='user'),
    path('request-reset-email/', RequestPasswordResetEmail.as_view(), name='request-reset-email'),
    path('password-reset/<uidb64>/<token>/', PasswordTokenCheckAPI.as_view(), name='password-reset-confirm'),
    path('password-reset-complete/', SetNewPasswordAPIView.as_view(), name='password-reset-complete'),
    path('change-password/', ChangePasswordView.as_view(), name='change-password'),
    # path('token/obtain/', TokenObtainPairView.as_view(), name='token_create'),  # override sjwt stock token
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    # path('profile/', UserDetailView.as_view(), name='user-detail'),
    path('', include(router.urls)),
    

]
