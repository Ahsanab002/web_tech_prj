from django.db import models
from django.contrib.auth.models import User
from datetime import date

# from django.utils.translation import gettext_lazy as _
from django.core.validators import MinValueValidator


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=100, blank=True, default="")
    last_name = models.CharField(max_length=100, blank=True, default="")
    profile_pic = models.CharField(max_length=100, blank=True, default="")

    GENDER_CHOICES = [
        ("M", "Male"),
        ("F", "Female"),
        ("O", "Other"),
    ]
    gender = models.CharField(
        max_length=1, choices=GENDER_CHOICES, blank=True, default="M"
    )

    country = models.CharField(max_length=100, blank=True, default="")
    birthday = models.DateField(null=True, blank=True)
    measurement_unit = models.CharField(
        max_length=20,
        choices=[("inches", "Inches"), ("centimeters", "Centimeters")],
        blank=True,
        default="inches",
    )

    PLAN_CHOICES = [
        ("free", "Free"),
        ("basic", "Basic"),
        ("yearly", "Yearly"),
        ("family", "Family"),
    ]
    plan = models.CharField(max_length=10, choices=PLAN_CHOICES, default="free")
    plan_type = models.CharField(max_length=10, choices=PLAN_CHOICES, default="free")
    expiry_plan = models.DateField(null=True, blank=True)
    family_members_usernames = models.JSONField(default=list, blank=True, null=True)
    rating = models.IntegerField(default=0)
    last_rated = models.DateField(null=True, blank=True)
    age = models.IntegerField(default=0)
    
    @property
    def username(self):
        return self.user.username

    def __str__(self):
        return self.user.username


class Notifications(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    read = models.BooleanField(default=False)

    def __str__(self):
        return f'Notification for {self.user.username}'

class Measurements(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    
    # Upper body
    neck = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    shoulder = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    chest = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    bust = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    waist = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    sleeve = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    wrist = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    
    # Lower body
    hip = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    inseam = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    thigh = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    calf = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    ankle = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    
    # Foot
    foot_len = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    foot_width = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    foot_shape = models.CharField(max_length=100, blank=True, null=True)
    foot_type = models.CharField(max_length=100, blank=True, null=True)
    
    # Other
    height = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    weight = models.FloatField(validators=[MinValueValidator(0)], blank=True, null=True)
    body_type = models.CharField(max_length=100, blank=True, null=True)
    fit_preference = models.CharField(max_length=100, blank=True, null=True)
    
    
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'Measurements for {self.user.username}'

class Favourites(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    added_at = models.DateTimeField(auto_now_add=True)
    item = models.CharField(max_length=250)
    url_link = models.URLField(max_length=1000)
    price = models.CharField(max_length=10)

    def __str__(self):
        return f'Favourite item for {self.user.username}'

class StockWatch(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    added_at = models.DateTimeField(auto_now_add=True)
    item = models.CharField(max_length=250)
    url_link = models.URLField(max_length=1000)
    price = models.CharField(max_length=10)
    status = models.CharField(max_length=100, default='Pending')

    def __str__(self):
        return f'Stock watch for {self.user.username}'
