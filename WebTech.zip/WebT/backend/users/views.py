# users/views.py

from rest_framework import generics, status
from rest_framework.response import Response
from django.contrib.auth.models import User
from .serializers import RegisterSerializer, LoginSerializer, UserSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import AllowAny, IsAuthenticated, IsAdminUser

from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.utils.encoding import smart_bytes, smart_str, DjangoUnicodeDecodeError
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.urls import reverse
from django.core.mail import send_mail
from django.conf import settings
from .serializers import ResetPasswordEmailRequestSerializer, SetNewPasswordSerializer, ChangePasswordSerializer
from django.contrib.sites.shortcuts import get_current_site
from .serializers import NotificationsSerializer, MeasurementsSerializer, FavouritesSerializer, StockWatchSerializer, ProfileSerializer
from .models import Notifications, Measurements, Favourites, StockWatch, Profile
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import NotFound
from rest_framework.decorators import api_view, permission_classes



class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = RegisterSerializer

class LoginView(generics.GenericAPIView):
    permission_classes = (AllowAny,)
    serializer_class = LoginSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data
        refresh = RefreshToken.for_user(user)
        return Response({
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        })

class UserView(generics.RetrieveAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = UserSerializer

    def get_object(self):
        return self.request.user
    
class RequestPasswordResetEmail(generics.GenericAPIView):
    permission_classes = [AllowAny]
    serializer_class = ResetPasswordEmailRequestSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = request.data['email']
        user = User.objects.get(email=email)
        uidb64 = urlsafe_base64_encode(smart_bytes(user.id))
        token = PasswordResetTokenGenerator().make_token(user)
        current_site = get_current_site(request=request).domain
        relativeLink = reverse('password-reset-confirm', kwargs={'uidb64': uidb64, 'token': token})
        absurl = 'http://' + current_site + relativeLink
        email_body = 'Hello, \n Use link below to reset your password  \n' + absurl
        data = {'email_body': email_body, 'to_email': user.email, 'email_subject': 'Reset your password'}
        send_mail(data['email_subject'], data['email_body'], settings.EMAIL_HOST_USER, [data['to_email']])
        return Response({'success': 'We have sent you a link to reset your password'}, status=status.HTTP_200_OK)

class PasswordTokenCheckAPI(generics.GenericAPIView):
    def get(self, request, uidb64, token):
        try:
            id = smart_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(id=id)

            if not PasswordResetTokenGenerator().check_token(user, token):
                return Response({'error': 'Token is not valid, please request a new one'}, status=status.HTTP_401_UNAUTHORIZED)

            return Response({'success': True, 'message': 'Credentials Valid', 'uidb64': uidb64, 'token': token}, status=status.HTTP_200_OK)

        except DjangoUnicodeDecodeError as identifier:
            return Response({'error': 'Token is not valid, please request a new one'}, status=status.HTTP_401_UNAUTHORIZED)

class SetNewPasswordAPIView(generics.UpdateAPIView):
    serializer_class = SetNewPasswordSerializer

    def patch(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response({'success': True, 'message': 'Password reset success'}, status=status.HTTP_200_OK)
    
class ChangePasswordView(generics.UpdateAPIView):
    serializer_class = ChangePasswordSerializer
    model = User
    permission_classes = [IsAuthenticated,]

    def get_object(self, queryset=None):
        return self.request.user

    def update(self, request, *args, **kwargs):
        self.object = self.get_object()
        serializer = self.get_serializer(data=request.data)

        if serializer.is_valid():
            self.object.set_password(serializer.validated_data['new_password'])
            self.object.save()
            return Response({'status': 'password set'}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# class UserDetailView(generics.RetrieveUpdateAPIView):
#     queryset = User.objects.all()
#     serializer_class = UserSerializer
#     permission_classes = [IsAuthenticated]

#     def get_object(self):
#         return self.request.user

class ProfileViewSet(viewsets.ModelViewSet):
    queryset = Profile.objects.all()
    serializer_class = ProfileSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return self.queryset.filter(user=self.request.user)

class NotificationsViewSet(viewsets.ModelViewSet):
    queryset = Notifications.objects.all()
    serializer_class = NotificationsSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return self.queryset.filter(user=self.request.user).order_by('-created_at')
    
    @action(detail=False, methods=['post'], permission_classes=[IsAuthenticated])
    def mark_read(self, request):
        Notifications.objects.filter(user=request.user, read=False).update(read=True)
        return Response({"message": "Notifications marked as read"}, status=status.HTTP_200_OK)
    
# @login_required
# @api_view(['POST'])
# @permission_classes([IsAuthenticated])
# def mark_notifications_as_read(request):
    # if request.method == "POST":
        # Update all unread notifications for the logged-in user
    # Notifications.objects.filter(user=request.user, read=False).update(read=True)
    # return Response({"message": "Notifications marked as read"}, status=status.HTTP_200_OK)

    # return Response({"error": "Invalid request method"}, status=status.HTTP_400_BAD_REQUEST)

class MeasurementsViewSet(viewsets.ModelViewSet):
    queryset = Measurements.objects.all()
    serializer_class = MeasurementsSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return self.queryset.filter(user=self.request.user)

class FavouritesViewSet(viewsets.ModelViewSet):
    queryset = Favourites.objects.all()
    serializer_class = FavouritesSerializer
    permission_classes = [IsAuthenticated]
    

    def get_queryset(self):
        return self.queryset.filter(user=self.request.user).order_by('-added_at')
    
    # def destroy(self, request, *args, **kwargs):
    #     print("destroy")
    #     try:
    #         instance = self.get_object() 
    #     except self.queryset.model.DoesNotExist:
    #         raise NotFound(detail="Object not found", code=status.HTTP_404_NOT_FOUND)
        
    #     self.perform_destroy(instance)
    #     return Response(status=status.HTTP_204_NO_CONTENT)

class FavViewSetChromeExtension(viewsets.ModelViewSet):
    queryset = Favourites.objects.all()
    serializer_class = FavouritesSerializer
    permission_classes = [AllowAny]

    # def get_queryset(self):
    #     return self.queryset.filter(user=self.request.query_params.get('user')).order_by('-added_at')

    def create(self, request, *args, **kwargs):
        user_id = request.data.get('user')
        user = User.objects.get(id=user_id)
        request.data['user'] = user.id
        return super().create(request, *args, **kwargs)
    
    # def destroy(self, request, *args, **kwargs):
    #     print("destroy")
    #     try:
    #         instance = self.get_object() 
    #     except self.queryset.model.DoesNotExist:
    #         raise NotFound(detail="Object not found", code=status.HTTP_404_NOT_FOUND)
        
    #     self.perform_destroy(instance)
    #     return Response(status=status.HTTP_204_NO_CONTENT)
    # def destroy(self, request, *args, **kwargs):
    #     favourite_id = kwargs.get('pk')
    #     print(f"Attempting to delete favourite with ID: {favourite_id}")
    #     try:
    #         instance = self.get_object()
    #         print(f"Found instance: {instance}")
    #         self.perform_destroy(instance)
    #         return Response(status=status.HTTP_204_NO_CONTENT)
    #     except Favourites.DoesNotExist:
    #         print(f"Favourite with ID {favourite_id} not found")
    #         return Response({"error": "Favourite not found"}, status=status.HTTP_404_NOT_FOUND)

    

class StockWatchViewSet(viewsets.ModelViewSet):
    queryset = StockWatch.objects.all()
    serializer_class = StockWatchSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return self.queryset.filter(user=self.request.user).order_by('-added_at')
    
    
class AdminProfileViewSet(viewsets.ModelViewSet):
    queryset = Profile.objects.all()
    serializer_class = ProfileSerializer
    # permission_classes = [IsAdminUser]
    
    # for testing purposes
    permission_classes = [AllowAny]
    
    # there is only one profile per user
    @action(detail=False, methods=['get'], url_path='user/(?P<user_id>[^/.]+)')
    def get_user_profile(self, request, user_id=None):
        user_profile = self.queryset.get(user__id=user_id)
        serializer = self.get_serializer(user_profile)
        return Response(serializer.data)
    

class AdminNotificationsViewSet(viewsets.ModelViewSet):
    queryset = Notifications.objects.all()
    serializer_class = NotificationsSerializer
    # permission_classes = [IsAdminUser]
    
    # for testing purposes
    permission_classes = [AllowAny]

class AdminMeasurementsViewSet(viewsets.ModelViewSet):
    queryset = Measurements.objects.all()
    serializer_class = MeasurementsSerializer
    # permission_classes = [IsAdminUser]
    
    # for testing purposes
    permission_classes = [AllowAny]


class AdminFavouritesViewSet(viewsets.ModelViewSet):
    queryset = Favourites.objects.all()
    serializer_class = FavouritesSerializer
    # permission_classes = [IsAdminUser]
    
    # for testing purposes
    permission_classes = [AllowAny]

class AdminStockWatchViewSet(viewsets.ModelViewSet):
    queryset = StockWatch.objects.all()
    serializer_class = StockWatchSerializer
    # permission_classes = [IsAdminUser]
    
    # for testing purposes
    permission_classes = [AllowAny]
    
    @action(detail=False, methods=['get'], url_path='user/(?P<user_id>[^/.]+)')
    def list_user_favourites(self, request, user_id=None):
        # Filter Favourites by user_id
        user_favourites = self.queryset.filter(user__id=user_id)
        serializer = self.get_serializer(user_favourites, many=True)
        return Response(serializer.data)
